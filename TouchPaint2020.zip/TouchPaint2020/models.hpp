#ifndef MODELS
#define MODELS

/*
Copyright © 2015  AGAPI SIMON
Email: mittisimone@gmail.com
*/

#include <QtGui>
#include <QtOpenGL>
#include <QGLWidget>
#include <vector>
#include <GL/glu.h>
#include <time.h>
//#include <omp.h>

#include<widgets.hpp>
#include<geometry.hpp>
#include<globals.hpp>

//#include<particles.hpp>
//#include<libObj/wavefrontObjectWrapper.h>

#define GL_MULTISAMPLE  0x809D


enum QPerspectiveMode
{
    FRUSTRUM,
    ORTHO,
    PERSPECTIVE,
    ORTHO2D,
};

enum QSpaceTransform
{
    GLOBAL_SPACE,
    LOCAL_SPACE,
    SCREEN_SPACE,
};

enum QOutlineMode
{
    OUTLINE,
    OUTLINE_ONLY,
    SILHOUETTE,
    SILHOUETTE_ONLY,
    NO_OUTLINE,
    DEFAULT_OUTLINE,
};

// Edit mode
enum EDITSTATE
{
    NOEDIT,
    SELECTOBJECT,
    ROTATEOBJECT,
    MOVEOBJECT,
    SCALEOBJECT,
    SELROTATEOBJECT,
    SELMOVEOBJECT,
};

// Edit Level
enum EDITLEVEL
{
    OBJ,
    MODEL,
    MESH,
    TRIANGLE,
    POLYGON,
    EDGE,
    VERTEX,
    ATCH_POINTS, //Auran Jet specific: Attachment points
    BONES,
    CAMERAS,
    LIGHTS
};

// object manipulation mode
enum EditMode
{
    //All features are off
    Off = 0,
    Select = 1,
    Rotate = 2,
    SelectAndMove = 3,
    SelectFromList = 4,
};

enum QModelTypes
{
    MODEL_BASE,
    MODEL_CUBE,
    MODEL_CYLINDER,
    MODEL_PIPE,
    MODEL_TUBE,
    MODEL_SPHERE,
    MODEL_QUAD,
    MODEL_GRID,
    MODEL_PLANE,
    MODEL_TRIANGLES,
    MODEL_DONUT,
    MODEL_CONE,
    MODEL_DISK,
    MODEL_LINE,
    MODEL_CIRCLE,
    MODEL_PIE,
    MODEL_TEXT,
    MODEL_SPLINE,
    MODEL_CABEL,
    MODEL_ICOSPHERE,
    MODEL_PYRAMID,
    MODEL_MESH,
    MODEL_LIGHT,
    MODEL_CAMERA,
    MODEL_SPIRAL,
    MODEL_IVY,
    MODEL_GROUP,
    MODEL_PARTICLES,
};



class QGroupModel;

class QBaseModel : public QObject
{
    Q_OBJECT

protected:

    QWidget * widget;
    QWidget * transformWidget;

    bool visible;
    bool freeze;

    QString name;

    QDoubleWidget posx;
    QDoubleWidget posy;
    QDoubleWidget posz;

    QDoubleWidget rotx;
    QDoubleWidget roty;
    QDoubleWidget rotz;

    QDoubleWidget scalex;
    QDoubleWidget scaley;
    QDoubleWidget scalez;

    QVector<QVector3D> m_points;
    QVector<QVector3D> m_normals;
    QVector<QVector2D> m_texcoords;

    QVector <int> m_edgeIndices;
    QVector <int> m_pointIndices;

public:

    enum QDrawMode
    {
        FLAT,
        SMOOTH,
        WIREFRAME,
        FILL,
        VERTS,
        FACEANDEGE
    };


    QDrawMode drawmode;

    enum { Type = MODEL_BASE};

    virtual int type() const  { return Type; }


    int getFacesCount()  const { return m_pointIndices.size() / 3; }
    int getEdgesCount()  const { return m_edgeIndices.size() / 2; }
    int getPointsCount() const { return m_points.size(); }
    int getUvsCount()    const { return m_texcoords.size();}


    QVector<QVector3D> getVertices()  const { return m_points; }
    QVector<QVector3D> getNormals()   const { return m_normals; }
    QVector<QVector2D> getTexcoords() const { return m_texcoords; }

    QVector<int> getEdgeIndices()   const { return m_edgeIndices; }
    QVector<int> getVertexIndices() const { return m_pointIndices; }


    QList<QGroupModel*> memberOfGroups;

    QList<QBaseModel*> children;

    QBaseModel * parent;

    QBoundSphere  boundingSphere;

    QAabb  boundingAabbox;

    float scalevalue;

    int ID;

    QVector3D selectedColor;

    QColor _selectedColor;
    QColor edgesColor;
    QColor pointsColor;


    QMatrix4x4 localMatrix;
    QMatrix4x4 worldMatrix;

    QVector3D position;
    QVector3D scale;
    QVector3D rotation;

    QVector3D colorId;



    QWidget * getWidget()
    {
        return widget;
    }

    QString getName()
    {
        return name;
    }

    void setName(QString name)
    {
        this->name  =  name;
    }


    class VisibilityAttir
    {
    public:
        VisibilityAttir()
        {
            // use this class for ui setting

            m_showWireframe     = true;
            m_showFacesNormals  = false;
            m_showPointsNormals = false;
            m_showSurface       = false;
            m_showPoints        = false;
            m_showCenter        = true;
        }

        bool m_showWireframe;
        bool m_showPointsNormals;
        bool m_showFacesNormals;
        bool m_showSurface;
        bool m_showPoints;
        bool m_showCenter;
        bool m_showBoundingBox;
    };

    bool showWireframe;
    bool showPointsNormals;
    bool showFacesNormals;
    bool showSurface;
    bool showPoints;
    bool showCenter;
    bool showBoundingBox;

    bool Selected;
    bool isTransforming;


    QBaseModel(QObject * parent =0) : QObject(parent)
    {
        showWireframe     = true;
        showFacesNormals  = false;
        showPointsNormals = false;
        showSurface       = false;
        showPoints        = false;
        showCenter        = true;
        showBoundingBox   = false;

        visible           = true;
        Selected          = false;

        Globals::ModelID++;

        ID =  Globals::ModelID;

        m_points.append(position);

        colorId        = QVector3D(Globals::frandom(100),Globals::frandom(100),Globals::frandom(100));

        selectedColor  = QVector3D((float)222/255,(float)97/255,(float)123/255);

        _selectedColor = QColor((float)222/255,(float)97/255,(float)123/255);
        pointsColor    = QColor(Qt::green);
        edgesColor     = QColor(Qt::green);

        position = QVector3D(0,0,0);
        rotation = QVector3D(0,0,0);
        scale    = QVector3D(1,1,1);

        widget = new QWidget;
        transformWidget = new QWidget();

        boundingSphere.radius = 0.4;

        name =  QString("Base Object");

        addTransformWidget();

        setTheme();
    }

    ~QBaseModel()
    {
        //delete widget;
    }

    //------------------------------------------------------------------------------------------------------

    virtual void drawToolTip()
    {
        QString tipstr("<b>QToolTip Example:</b>\n"
                       "Create N points on a sphere\n "
                       "aproximately equi-distant from each other\n"
                       "Basically, N points are randomly\n "
                       "placed on the sphere and then moved\n"
                       "around until then moved around \n"
                       "until the minimal distance between the\n"
                       "closed two points is minimaised.\n");

         QPoint p = QCursor::pos();


        QToolTip::showText(p,tipstr,widget,QRect(p,QSize(100,120)));

    }

    virtual void addTransformWidget()
    {


        posx.setMinMaxValue(-1000,1000,0,.01);posx.setText(QString("Position X:"));
        posy.setMinMaxValue(-1000,1000,0,.01);posy.setText(QString("Position Y:"));
        posz.setMinMaxValue(-1000,1000,0,.01);posz.setText(QString("Position Z:"));

        rotx.setMinMaxValue(-1000,1000,0,.01);rotx.setText(QString("Rotation X:"));
        roty.setMinMaxValue(-1000,1000,0,.01);roty.setText(QString("Rotation Y:"));
        rotz.setMinMaxValue(-1000,1000,0,.01);rotz.setText(QString("Rotation Z:"));

        scalex.setMinMaxValue(-1000,1000,1,.01);scalex.setText(QString("Scale X:"));
        scaley.setMinMaxValue(-1000,1000,1,.01);scaley.setText(QString("Scale Y:"));
        scalez.setMinMaxValue(-1000,1000,1,.01);scalez.setText(QString("Scale Z:"));

        QVBoxLayout * layout = new QVBoxLayout;

        layout->addWidget(&posx);
        layout->addWidget(&posy);
        layout->addWidget(&posz);

        layout->addWidget(&rotx);
        layout->addWidget(&roty);
        layout->addWidget(&rotz);

        layout->addWidget(&scalex);
        layout->addWidget(&scaley);
        layout->addWidget(&scalez);

        transformWidget->setLayout(layout);

        transformWidget->show();

        connect(&posx,SIGNAL(valueChanged(double)),this,SLOT(setPos()));
        connect(&posy,SIGNAL(valueChanged(double)),this,SLOT(setPos()));
        connect(&posz,SIGNAL(valueChanged(double)),this,SLOT(setPos()));

        connect(&scalex,SIGNAL(valueChanged(double)),this,SLOT(setScale()));
        connect(&scaley,SIGNAL(valueChanged(double)),this,SLOT(setScale()));
        connect(&scalez,SIGNAL(valueChanged(double)),this,SLOT(setScale()));

        connect(&rotx,SIGNAL(valueChanged(double)),this,SLOT(setRotation()));
        connect(&roty,SIGNAL(valueChanged(double)),this,SLOT(setRotation()));
        connect(&rotz,SIGNAL(valueChanged(double)),this,SLOT(setRotation()));


    }


    virtual void setTheme()
    {
        //using menu to switch styles

        //qDebug()<<"Loading Styles";

        QFile file(":/icons/glowBlue.stylesheet");

        //QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            QByteArray st =file.readAll();

            widget->setStyleSheet(st);

            transformWidget->setStyleSheet(st);
        }

        file.close();

        qDebug()<<"Styles Loaded";
    }

    virtual void addWidgets()
    {

    }


    //------------------------------------------------------------------------------------------------------


    virtual  void drawSurface()
    {

        glEnable(GL_DEPTH_TEST);
        glEnableClientState(GL_VERTEX_ARRAY);


        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_COLOR_MATERIAL);


        //glColor3f(.2,.2,.2);
        //glShadeModel(GL_SMOOTH);
        //glShadeModel(GL_FLAT);

        glEnableClientState(GL_NORMAL_ARRAY);

        glVertexPointer(3, GL_FLOAT, 0, (float*)m_points.constData());


        if(m_texcoords.size()>0)
        {
            //glEnableClientState(GL_TEXTURE_COORD_ARRAY);
            //glTexCoordPointer(2, GL_FLOAT, 0, (float*)m_texcoords.constData() );
        }

        glNormalPointer(GL_FLOAT, 0, (float *)m_normals.constData());
        glDrawElements(GL_QUADS, m_pointIndices.size(), GL_UNSIGNED_INT, m_pointIndices.constData());

        glDisableClientState(GL_NORMAL_ARRAY);
        //glDisableClientState(GL_TEXTURE_COORD_ARRAY);

        glDisable(GL_COLOR_MATERIAL);
        glDisable(GL_LIGHT0);
        glDisable(GL_LIGHTING);

        bool edgefaces = true;

            if(edgefaces)
            {
                //glEnable(GL_CULL_FACE);
                glEnable(GL_COLOR_MATERIAL);
                glColor3f(.1,.1,.1);
                glLineWidth(2.0f);


                glVertexPointer(3, GL_FLOAT, 0, (float *)m_points.constData());
                glDrawElements(GL_LINES, m_edgeIndices.size(), GL_UNSIGNED_INT, m_edgeIndices.constData());

                //-----------use these below----------------
                //glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
                //glPolygonMode( GL_FRONT_AND_BACK, GL_LINES );
                //glDrawElements(GL_QUADS, m_pointIndices.size(), GL_UNSIGNED_INT, m_pointIndices.constData());

                glDisable(GL_COLOR_MATERIAL);
            }




        glDisableClientState(GL_VERTEX_ARRAY);
        glDisable(GL_DEPTH_TEST);
    }

    virtual  void drawEdges()
    {
        glDisable(GL_LIGHTING);
        glEnable(GL_DEPTH_TEST);
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnable(GL_COLOR_MATERIAL);

        glVertexPointer(3, GL_FLOAT, 0, (float *)m_points.constData());
        glDrawElements(GL_LINES, m_edgeIndices.size(), GL_UNSIGNED_INT, m_edgeIndices.constData());

        glDisable(GL_COLOR_MATERIAL);
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }

    virtual  void drawPoints()
    {
        glEnable(GL_POINT_SMOOTH);

        glDisable(GL_LIGHTING);
        glEnable(GL_DEPTH_TEST);
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnable(GL_COLOR_MATERIAL);

        glVertexPointer(3, GL_FLOAT, 0, (float *)m_points.constData());
        glDrawElements(GL_POINTS, m_pointIndices.size(), GL_UNSIGNED_INT, m_pointIndices.constData());

        glDisable(GL_COLOR_MATERIAL);
        glDisableClientState(GL_VERTEX_ARRAY);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

        glDisable(GL_POINT_SMOOTH);

    }

    virtual  void drawPointsNormals()
    {
        // This function needs to be sped up
        glEnable(GL_DEPTH_TEST);

        glEnableClientState(GL_VERTEX_ARRAY);

        // Consider caching this normals

        QVector<QVector3D> normals;

        for (int i = 0; i < m_normals.size(); ++i)
        {
            // N = point + normal * scalar

            // Draw line from point to N

            normals << m_points.at(i) << (m_points.at(i) + m_normals.at(i) * 0.02f);
        }

        glVertexPointer(3, GL_FLOAT, 0, (float *)normals.constData());

        glDrawArrays(GL_LINES, 0, normals.size());


        glDisableClientState(GL_VERTEX_ARRAY);

        glDisable(GL_DEPTH_TEST);

    }

    virtual  void drawFacesNormals()
    {

    }

    virtual void drawCenter()
    {
        if(visible)
        {
            glPointSize(5);

            glBegin(GL_POINTS);

            if(Selected)
            {
                //glColor3f( .5, .25, .79);
                glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
            }
            else
            {
                //glColor3f( .5, .5, .1);
                glColor3f( colorId.x(), colorId.y(), colorId.z());
            }

            glVertex3f(position.x(),position.y(),position.z());
            glEnd();
        }
    }

    virtual void drawBoundingBox()
    {
        if(boundingAabbox.min.y() == boundingAabbox.max.y())
        {
            boundingAabbox.min -= QVector3D(0,0.05,0);
            boundingAabbox.max += QVector3D(0,0.05,0);
        }

        QAabb b;

        b = boundingAabbox;

        b.translate(position);

        QColor color;


        if(Selected)
        {
            color.setRedF(selectedColor.x());
            color.setGreenF(selectedColor.y());
            color.setBlueF(selectedColor.z());
            //glColor3f( .5, .25, .79);
            //glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
        }
        else
        {
            //glColor3f( .5, .5, .1);
            //glColor3f( colorId.x(), colorId.y(), colorId.z());
            color.setRedF(colorId.x());
            color.setGreenF(colorId.y());
            color.setBlueF(colorId.z());
        }

       // QColor(Qt::blue);

         b.draw(color);
    }

    virtual void drawModel()
    {

        //glEnable(GL_MULTISAMPLE);

        glPushMatrix();
        //printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());
        glTranslatef(position.x(),position.y(),position.z());

        glRotatef(rotation.x(),1,0,0);
        glRotatef(rotation.y(),0,1,0);
        glRotatef(rotation.z(),0,0,1);

        glScalef(scale.x(),scale.y(),scale.z());


        if(showSurface)
        {
            drawSurface();
        }

        if(showWireframe)
        {
            drawEdges();
        }

        glPopMatrix();

        if(showPoints)
        {
            drawPoints();
        }

        if(showPointsNormals)
        {
            drawPointsNormals();
        }

        if(showFacesNormals)
        {
            drawFacesNormals();
        }

        if(showCenter)
        {
            drawCenter();
        }

        if(showBoundingBox)
        {
            drawBoundingBox();
        }

        //glDisable(GL_MULTISAMPLE);

    }




    //------------------------------------------------------------------------------------------------------



    /*

    virtual void setDrawMode(QDrawMode mode = GL_SMOOTH)
    {
        switch(mode)
        {
            case WIREFRAME:
            {
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

                break;
            }
            case FLAT:
            {
                glShadeModel(GL_FLAT);
                break;
            }
            case SMOOTH:
            {
                glShadeModel(GL_SMOOTH);
                break;
            }
            case FILL:
            {
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
                break;
            }
            case VERTS:
            {
                glPointSize(5.0f);
                glPolygonMode( GL_FRONT_AND_BACK, GL_POINT );
                break;
            }
        }
    }



    virtual void draw()
    {

    }

    */



    virtual void computeFaceNormals()
    {
        /*
        facesNormals.clear();
        normals.clear();

        for(int i=0;i<faces.size();i++)
        {
            QVector4D face  =  faces[i];

            QVector3D v1 =  vertices[(int)face.x()];
            QVector3D v2 =  vertices[(int)face.y()];
            QVector3D v3 =  vertices[(int)face.z()];
            QVector3D v4 =  vertices[(int)face.w()];

            QVector3D vec1 = v2 - v1;
            QVector3D vec2 = v3 - v1;

            vec1.normalize();
            vec2.normalize();

            QVector3D normal =  QVector3D::crossProduct(vec1,vec2);

            normal.normalize();

            facesNormals.append(normal);
        }

        QList<QVector3D> neighborFaceNormals;

        for(int i=0;i<vertices.size();i++)
        {
            for( int j =0;j<faces.size();j++)
            {
                QVector4D face = faces[j];

                if((int)face.x() == i)
                {
                   neighborFaceNormals.append(facesNormals[j]);
                }

                if((int)face.y() == i)
                {
                   neighborFaceNormals.append(facesNormals[j]);
                }
                if((int)face.z() == i)
                {
                   neighborFaceNormals.append(facesNormals[j]);
                }
                if((int)face.w() == i)
                {
                   neighborFaceNormals.append(facesNormals[j]);
                }
           }

            QVector3D ve;

            if(neighborFaceNormals.size()==4)
            {
                ve += neighborFaceNormals[0];
                ve += neighborFaceNormals[1];
                ve += neighborFaceNormals[2];
                ve += neighborFaceNormals[3];

                ve/= 4;
            }

            if(neighborFaceNormals.size()==3)
            {
                ve += neighborFaceNormals[0];
                ve += neighborFaceNormals[1];
                ve += neighborFaceNormals[2];
                //ve += neighborFaceNormals[3];

                ve/= 3;
            }

            ve.normalize();

            normals.append(ve);
        }

        */
    }

    virtual void computeNormals()
    {
        m_normals.clear();
        m_normals.resize(m_points.size());

        for (int i = 0; i < m_pointIndices.size(); i += 4)
        {
            const QVector3D a = m_points.at(m_pointIndices.at(i));
            const QVector3D b = m_points.at(m_pointIndices.at(i+1));
            const QVector3D c = m_points.at(m_pointIndices.at(i+2));

            const QVector3D normal = QVector3D::crossProduct(b - a, c - a).normalized();

            for (int j = 0; j < 4; ++j)
            {
                m_normals[m_pointIndices.at(i + j)] += normal;
            }
        }

        for (int i = 0; i < m_normals.size(); ++i)
        {
            m_normals[i] = m_normals[i].normalized()*-1;
        }


    }

    virtual void computeUvCoordinates(){}

    virtual void computeBounds()
    {
        boundingSphere = QBoundSphere(0,QVector3D(0,0,0));
        boundingAabbox =  QAabb(QVector3D(0,0,0),QVector3D(0,0,0));

        boundingSphere.radius =0;
        boundingAabbox.radius = 0;


        if(m_points.size()>0)
        {
            for(int i=0;i<m_points.size();i++)
            {
                boundingSphere.center += m_points[i];
                boundingAabbox.expand(m_points[i]);
            }

            boundingSphere.center /= m_points.size();
            boundingAabbox.center = boundingAabbox.getCenter();


            QList<float> distances;

            for(int i=0;i<m_points.size();i++)
            {
                QVector3D d  = boundingSphere.center - m_points[i];

                distances.append(fabs(d.length()));
            }

            qSort(distances);

            boundingSphere.radius = distances.last();

            if(boundingSphere.radius==0)
            {
                boundingSphere.radius = 1;
            }

            boundingAabbox.radius = boundingSphere.radius;
        }
    }



    //------------------------------------------------------------------------------------------------------




    virtual QMatrix4x4 getTransform()
    {
        QVector3D axis;
        float angle;
        localMatrix.setToIdentity();

        QMatrix4x4 scalem;
        scalem.scale(scale);

        QMatrix4x4 translatem;
        translatem.translate(position);

        QMatrix4x4 rotatem;
        rotatem.rotate(angle,axis);

        localMatrix  = scalem * translatem * rotatem;

        return localMatrix;

    }

    virtual void  TransformModel()
    {
        //transformedVertices.clear();
        //transformedNormals.clear();

        for(int i=0;i<m_points.size();i++)
        {
            QVector3D p = m_points[i];
            QVector3D n = m_normals[i];

            QVector3D co = getTransform() * p;
            QVector3D N =  getTransform() * n;

            //transformedVertices.append(co);
            //transformedNormals.append(N);
        }
    }

    virtual void setParent(QBaseModel* model)
    {
        parent = model;
    }
    virtual void addChild(QBaseModel* model)
    {
        children.append(model);
    }
    virtual void removeChild(QBaseModel* model)
    {
        children.removeAt(children.indexOf(model));
    }

    virtual void setModel(QBaseModel* model)
    {

    }

    virtual int getChildCount()
    {
        return children.size();
    }

    virtual const QList<QBaseModel*>  & getChildren(){return children;}

    virtual QBaseModel * getParent(){return parent;}
    virtual QBaseModel * getInstance(){return this;}

    //virtual QBaseModel * getReference(){}

    //virtual QBaseModel  getDuplicate()
    //{
    //QBaseModel m;
    //m.position = this->position;
    //m.rotation = this->rotation;
    //m.scale    = this->scale;
    //m.boundingAabbox = this->boundingAabbox;
    //m.boundingSphere = this->boundingSphere;

    //m.faces    = this->faces;
    //m.vertices = this->vertices;
    //m.setName(this->getName());
    //m.colorId  = QVector3D(Globals::frandom(1000),Globals::frandom(1000),Globals::frandom(1000));

    //return m;
    //}


signals:

    virtual void valueChanged();

public slots:

    void setPos()
    {
        position.setX(posx.getValue());
        position.setY(posy.getValue());
        position.setZ(posz.getValue());

        emit valueChanged();
    }
    void setScale()
    {
        scale.setX(scalex.getValue());
        scale.setY(scaley.getValue());
        scale.setZ(scalez.getValue());
        emit valueChanged();

    }
    void setRotation()
    {
        rotation.setX(rotx.getValue());
        rotation.setY(roty.getValue());
        rotation.setZ(rotz.getValue());
        emit valueChanged();
    }

    void hideModel()
    {
        if(visible)
            visible = false;
        else
            visible = true;
    }

    void freezeModel()
    {
        if(freeze)
            freeze = false;
        else
            freeze = true;
    }
};

class QGroupModel : public QBaseModel
{
public:
    int ID;

    QList<QBaseModel*> group;

    enum { Type = MODEL_GROUP};

    int type() const  { return Type; }

    ~QGroupModel()
    {
        delete widget;
    }

    QGroupModel(QObject * parent =0) : QBaseModel(parent)
    {
        m_points.clear();
        name = QString("Group Model");

        Globals::GroupModelID+=1;

        ID = Globals::GroupModelID;
    }

    void addModel(QBaseModel * model)
    {
        group.append(model);
    }

    void removeModel(QBaseModel * model)
    {
        group.removeAt(group.indexOf(model));
    }

    int getModelCount()
    {
        return group.size();
    }

    void draw()
    {
        drawBoundingBox();
    }

    void drawBoundingBox()
    {
        QAabb b = boundingAabbox;

        for(int i=0;i<group.size();i++)
        {
            QBaseModel * m =  group[i];

            b.merge(m->boundingAabbox);
        }

        QColor col =  QColor(Qt::cyan);

        b.draw(col);
    }
};

class QQuadModel: public QBaseModel
{
    Q_OBJECT

public:

    enum { Type = MODEL_QUAD};

    int type() const  { return Type; }


    QQuadModel(QObject * parent =0) : QBaseModel(parent)
    {
        m_points.clear();

        name = QString("Quad Polygon");

        generateQuad();
    }

    ~QQuadModel()
    {
        delete widget;
    }

    void generateQuad()
    {
        m_points.clear();
        m_pointIndices.clear();
        m_normals.clear();
        m_edgeIndices.clear();

        position = QVector3D(0,0,0);

        QVector3D normal(0,1,0);

        float n = 1;

        QVector3D v0(-n, 0,  n );
        QVector3D v1(-n, 0, -n );
        QVector3D v2( n, 0, -n );
        QVector3D v3( n, 0,  n );

        m_points.append(v0);
        m_points.append(v1);
        m_points.append(v2);
        m_points.append(v3);

        m_normals.append(normal);
        m_normals.append(normal);
        m_normals.append(normal);
        m_normals.append(normal);

        int index_0 =0;
        int index_1 =1;
        int index_2 =2;
        int index_3 =3;


        m_pointIndices.append(index_0);
        m_pointIndices.append(index_1);
        m_pointIndices.append(index_2);
        m_pointIndices.append(index_3);


        m_edgeIndices.append(index_0);
        m_edgeIndices.append(index_1);

        m_edgeIndices.append(index_1);
        m_edgeIndices.append(index_2);

        m_edgeIndices.append(index_2);
        m_edgeIndices.append(index_3);

        m_edgeIndices.append(index_3);
        m_edgeIndices.append(index_0);

        computeBounds();
    }
};

class QPlaneModel: public QBaseModel
{
    Q_OBJECT

    int usteps;
    int vsteps;

    float width;
    float length;

    QSlider * uslider;
    QSlider * vslider;

    QDoubleSlider * wslider;
    QDoubleSlider * lslider;

    QSpinBox * uspinBox;
    QSpinBox * vspinBox;

    QDoubleSpinBox * wspinBox;
    QDoubleSpinBox * lspinBox;

public:
    enum { Type = MODEL_PLANE};

    int type() const  { return Type; }


    QPlaneModel(QObject * parent =0) : QBaseModel(parent)
    {
        usteps = 4;
        vsteps = 4;

        width  = 1;
        length = 1;

        name = QString("Plane Model");

        n_grid(width,length,usteps,vsteps);

        addWidgets();
    }

    ~QPlaneModel()
    {
        delete widget;
    }



    void addWidgets()
    {
        uslider = new QSlider(Qt::Horizontal);
        vslider = new QSlider(Qt::Horizontal);

        uspinBox = new QSpinBox;
        vspinBox = new QSpinBox;

        wslider  = new QDoubleSlider(Qt::Horizontal);
        lslider  = new QDoubleSlider(Qt::Horizontal);

        wspinBox = new QDoubleSpinBox;
        lspinBox = new QDoubleSpinBox;


        uslider->setMinimum(0);
        uslider->setMaximum(100);
        uslider->setSingleStep(1);


        vslider->setMinimum(0);
        vslider->setMaximum(100);
        vslider->setSingleStep(1);


        wslider->setMinimum(0);
        wslider->setMaximum(100);
        wslider->setSingleStep(.01);

        lslider->setMinimum(0);
        lslider->setMaximum(100);
        lslider->setSingleStep(.01);

        vslider->setValue(vsteps);
        uslider->setValue(usteps);

        wslider->setValue(width);
        lslider->setValue(length);

        uspinBox->setMinimum(0);
        uspinBox->setMaximum(100);
        uspinBox->setSingleStep(1);


        vspinBox->setMinimum(0);
        vspinBox->setMaximum(100);
        vspinBox->setSingleStep(1);

        lspinBox->setMinimum(0);
        lspinBox->setMaximum(100);
        lspinBox->setSingleStep(.01);


        wspinBox->setMinimum(0);
        wspinBox->setMaximum(100);
        wspinBox->setSingleStep(.01);


        uspinBox->setValue(usteps);
        vspinBox->setValue(vsteps);
        lspinBox->setValue(length);
        wspinBox->setValue(width);

        widget = new QWidget;
        widget->setWindowTitle(QString(name));

        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("Width:")));
        hlayout1->addWidget(wslider);
        hlayout1->addWidget(wspinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);



        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("u steps:")));
        hlayout2->addWidget(uslider);
        hlayout2->addWidget(uspinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("v steps:")));
        hlayout3->addWidget(vslider);
        hlayout3->addWidget(vspinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        QHBoxLayout * hlayout4 = new QHBoxLayout;
        hlayout4->addWidget(new QLabel(QString("Length:")));
        hlayout4->addWidget(lslider);
        hlayout4->addWidget(lspinBox);
        QFrame * qf4 =  new QFrame;
        qf4->setLayout(hlayout4);

        layout->addWidget(qf1);
        layout->addWidget(qf4);
        layout->addWidget(qf2);
        layout->addWidget(qf3);


        widget->setLayout(layout);

        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(vspinBox,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));

        connect(wspinBox,SIGNAL(valueChanged(double)),this,SLOT(setWidth()));
        connect(lspinBox,SIGNAL(valueChanged(double)),this,SLOT(setLength()));



        connect(uslider,SIGNAL(valueChanged(int)),uspinBox,SLOT(setValue(int)));
        connect(vslider,SIGNAL(valueChanged(int)),vspinBox,SLOT(setValue(int)));

        connect(wslider,SIGNAL(valueChanged(double)),wspinBox,SLOT(setValue(double)));
        connect(lslider,SIGNAL(valueChanged(double)),lspinBox,SLOT(setValue(double)));



        connect(uspinBox,SIGNAL(valueChanged(int)),uslider,SLOT(setValue(int)));
        connect(vspinBox,SIGNAL(valueChanged(int)),vslider,SLOT(setValue(int)));

        connect(lspinBox,SIGNAL(valueChanged(double)),lslider,SLOT(setValue(double)));
        connect(wspinBox,SIGNAL(valueChanged(double)),wslider,SLOT(setValue(double)));

        connect(this,SIGNAL(valueChanged()),this,SLOT(updateGrid()));

        setTheme();

        widget->show();
    }

    /*

    void draw()
    {


        if(Selected)
        {
            //glColor3f( .5, .25, .79);
            glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
        }
        else
        {
            //glColor3f( .5, .5, .1);
            glColor3f( colorId.x(), colorId.y(), colorId.z());
        }



        //qDebug()<<"Quad Polygon Model drawn";
    }

    */


    void n_grid(int width,int length, int u_steps,int v_steps)
    {
        QList< QPair<int,int> > tuples;

        m_points.clear();
        m_pointIndices.clear();
        m_normals.clear();
        m_edgeIndices.clear();


        if(width<0){ width = 0;  }
        if(length<0){ length = 0; }

        if(u_steps<1){u_steps = 1;}
        if(v_steps<1){v_steps = 1;}

        QVector3D normal(0,1,0);

        float step_u = (float)width / u_steps;

        float step_v = (float)length / v_steps;

        for( int i=0;i<(u_steps + 1);i++)
        {
            //#pragma omp parallel for
            for(int j=0; j<(v_steps + 1);j++)
            {
                float x = i * step_u;

                float z = j * step_v;

                float y = 0;

                QVector3D p = QVector3D(x , y , z );

                tuples.append(QPair<int,int>(i, j));

                m_points.append(p);

                m_normals.append(normal);

            }
        }

        //#pragma omp parallel for
        for(int i=0;i<u_steps;i++)
        {
            //#pragma omp parallel for
            for(int j =0;j<v_steps;j++)
            {
                int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));

                m_pointIndices.append(index_0);
                m_pointIndices.append(index_1);
                m_pointIndices.append(index_2);
                m_pointIndices.append(index_3);

                //---latitude--rings----
                m_edgeIndices.append(index_0);
                m_edgeIndices.append(index_1);

                //---longitude--rings-------
                m_edgeIndices.append(index_1);
                m_edgeIndices.append(index_2);

                //m_edgeIndices.append(index_2);
                //m_edgeIndices.append(index_3);
                //m_edgeIndices.append(index_3);
                //m_edgeIndices.append(index_0);
            }
        }

        computeNormals();

        computeBounds();
    }

signals:

    void valueChanged();


private slots:

    void updateGrid()
    {
        n_grid(width,length,usteps,vsteps);
    }

    void setWidth()
    {
        width = wspinBox->value();
        emit valueChanged();
    }

    void setLength()
    {
        length = lspinBox->value();
        emit valueChanged();
    }

    void setUsteps()
    {
        usteps = uspinBox->value();
        emit valueChanged();
    }

    void setVsteps()
    {
        vsteps = vspinBox->value();
        emit valueChanged();
    }
};

class QCubeModel : public QBaseModel
{
    Q_OBJECT
public:
    enum { Type = MODEL_CUBE};

    int type() const  { return Type; }


    QCubeModel(QObject * parent =0) : QBaseModel(parent)
    {
        m_points.clear();

        name = QString("Cube Model");

        n_cube();
    }
    ~QCubeModel()
    {
        delete widget;
    }

    void n_cube()
    {
        m_points.clear();
        m_pointIndices.clear();
        m_normals.clear();
        m_edgeIndices.clear();

        //QList< QPair<int,int> > tuples;


        m_points.append(QVector3D(-1,1,1));
        m_points.append(QVector3D(1,1,1));
        m_points.append(QVector3D(1,1,-1));
        m_points.append(QVector3D(-1,1,-1));

        m_points.append(QVector3D(-1,-1,1));
        m_points.append(QVector3D(1,-1,1));
        m_points.append(QVector3D(1,-1,-1));
        m_points.append(QVector3D(-1,-1,-1));

        int index_0 = 0;
        int index_1 = 1;
        int index_2 = 2;
        int index_3 = 3;
        int index_4 = 4;
        int index_5 = 5;
        int index_6 = 6;
        int index_7 = 7;


        m_pointIndices.append(index_0);
        m_pointIndices.append(index_1);
        m_pointIndices.append(index_2);
        m_pointIndices.append(index_3);

        m_pointIndices.append(index_4);
        m_pointIndices.append(index_5);
        m_pointIndices.append(index_6);
        m_pointIndices.append(index_7);

        m_pointIndices.append(index_0);
        m_pointIndices.append(index_4);
        m_pointIndices.append(index_5);
        m_pointIndices.append(index_1);

        m_pointIndices.append(index_2);
        m_pointIndices.append(index_3);
        m_pointIndices.append(index_7);
        m_pointIndices.append(index_6);

        m_pointIndices.append(index_0);
        m_pointIndices.append(index_3);
        m_pointIndices.append(index_7);
        m_pointIndices.append(index_4);

        m_pointIndices.append(index_1);
        m_pointIndices.append(index_2);
        m_pointIndices.append(index_6);
        m_pointIndices.append(index_5);

        for(int i =0;i<6;i+=4)
        {
           m_edgeIndices.append(m_pointIndices[i]);
           m_edgeIndices.append(m_pointIndices[i+1]);

           m_edgeIndices.append(m_pointIndices[i+1]);
           m_edgeIndices.append(m_pointIndices[i+2]);

           m_edgeIndices.append(m_pointIndices[i+2]);
           m_edgeIndices.append(m_pointIndices[i+3]);

           m_edgeIndices.append(m_pointIndices[i+3]);
           m_edgeIndices.append(m_pointIndices[i]);

        }


        computeNormals();
        computeBounds();


    }

};

class QCylinderModel : public QBaseModel
{
    Q_OBJECT

    int usteps;
    int vsteps;
    float cylinderRadius;
    float cylinderHeight;


    QSlider * uslider;
    QSlider * vslider;
    QDoubleSlider * rslider;
    QDoubleSlider * hslider;

    QSpinBox * uspinBox;
    QSpinBox * vspinBox;
    QDoubleSpinBox * rspinBox;
    QDoubleSpinBox * hspinBox;

public:

    enum { Type = MODEL_CYLINDER};

    int type() const  { return Type; }


    QCylinderModel(QObject * parent =0) : QBaseModel(parent)
    {
        usteps = 10;
        vsteps = 10;
        //boundingSphereRadius =  1;
        cylinderRadius = 0.2f;
        cylinderHeight = 1;

        m_points.clear();

        name = QString("Cylinder Model");

        uv_cylinder(cylinderHeight,cylinderRadius,usteps,vsteps);



        addWidgets();

        setTheme();
    }

    ~QCylinderModel()
    {
        //delete widget;
    }

    void addWidgets()
    {
        widget = new QWidget;
        widget->setWindowTitle(QString(name));
        uslider = new QSlider(Qt::Horizontal);
        uslider->setValue(usteps);
        uslider->setMinimum(0);
        uslider->setMaximum(200);
        uslider->setSingleStep(1);

        vslider = new QSlider(Qt::Horizontal);
        vslider->setValue(vsteps);
        vslider->setMinimum(0);
        vslider->setMaximum(200);
        vslider->setSingleStep(1);

        rslider = new QDoubleSlider(Qt::Horizontal);
        rslider->setValue(cylinderRadius);
        rslider->setMinimum(0);
        rslider->setMaximum(200);
        rslider->setSingleStep(1);

        hslider = new QDoubleSlider(Qt::Horizontal);
        hslider->setValue(cylinderHeight);
        hslider->setMinimum(0);
        hslider->setMaximum(200);
        hslider->setSingleStep(.01);


        uspinBox = new QSpinBox;
        vspinBox = new QSpinBox;
        rspinBox = new QDoubleSpinBox;
        hspinBox = new QDoubleSpinBox;


        uspinBox->setMinimum(0);
        uspinBox->setMaximum(200);
        uspinBox->setSingleStep(1);


        vspinBox->setMinimum(0);
        vspinBox->setMaximum(200);
        vspinBox->setSingleStep(1);


        rspinBox->setMinimum(0);
        rspinBox->setMaximum(200);
        rspinBox->setSingleStep(.01);

        hspinBox->setMinimum(0);
        hspinBox->setMaximum(200);
        hspinBox->setSingleStep(.01);

        rspinBox->setValue(cylinderRadius);
        hspinBox->setValue(cylinderHeight);
        uspinBox->setValue(usteps);
        vspinBox->setValue(vsteps);

        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("Radius:")));
        hlayout1->addWidget(rslider);
        hlayout1->addWidget(rspinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("u steps:")));
        hlayout2->addWidget(uslider);
        hlayout2->addWidget(uspinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("v steps:")));
        hlayout3->addWidget(vslider);
        hlayout3->addWidget(vspinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        QHBoxLayout * hlayout4 = new QHBoxLayout;
        hlayout4->addWidget(new QLabel(QString("Height:")));
        hlayout4->addWidget(hslider);
        hlayout4->addWidget(hspinBox);
        QFrame * qf4 =  new QFrame;
        qf4->setLayout(hlayout4);


        layout->addWidget(qf4);
        layout->addWidget(qf1);
        layout->addWidget(qf2);
        layout->addWidget(qf3);


        widget->setLayout(layout);

        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(vspinBox,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));
        connect(rspinBox,SIGNAL(valueChanged(double)),this,SLOT(setRadius()));
        connect(hspinBox,SIGNAL(valueChanged(double)),this,SLOT(setHeight()));

        connect(uslider,SIGNAL(valueChanged(int)),uspinBox,SLOT(setValue(int)));
        connect(vslider,SIGNAL(valueChanged(int)),vspinBox,SLOT(setValue(int)));
        connect(rslider,SIGNAL(valueChanged(double)),rspinBox,SLOT(setValue(double)));
        connect(hslider,SIGNAL(valueChanged(double)),hspinBox,SLOT(setValue(double)));

        connect(uspinBox,SIGNAL(valueChanged(int)),uslider,SLOT(setValue(int)));
        connect(vspinBox,SIGNAL(valueChanged(int)),vslider,SLOT(setValue(int)));
        connect(rspinBox,SIGNAL(valueChanged(double)),rslider,SLOT(setValue(double)));
        connect(hspinBox,SIGNAL(valueChanged(double)),hslider,SLOT(setValue(double)));

        connect(this,SIGNAL(valueChanged()),this,SLOT(updateCylinder()));

        widget->show();
    }

    void uv_cylinder(float height,float radius, int u_seg=10, int v_seg=10)
    {
        QList< QPair<int,int> > tuples;

        if (u_seg > 0 && v_seg > 0)
        {
            m_points.clear();
            m_pointIndices.clear();
            m_normals.clear();
            m_edgeIndices.clear();

            float step_theta = (float)2*M_PI / u_seg;

            float step_height = (float)height / v_seg;

            printf("steps Rings %f,steps Height %f",step_theta,step_height);

            //#pragma omp parallel for
            for(int i =0; i < v_seg+1; i++)
            {
                float deltah = i * step_height;

                //#pragma omp parallel for
                for(int j =0; j<u_seg+1;j++)
                {
                    float theta = j * step_theta;

                    tuples.append(QPair<int,int>(i, j));

                    float x = radius * sin(theta);
                    float y = deltah;
                    float z = radius * cos(theta);

                    QVector3D p = QVector3D(x , y , z);

                    m_points.append(p);
                }
            }

            printf("PointS %i",m_points.size());

            //#pragma omp parallel for
            for( int i=0;i<v_seg;i++)
            {
                //#pragma omp parallel for
                for(int j=0;j<u_seg;j++)
                {
                    int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));


                    m_pointIndices.append(index_0);
                    m_pointIndices.append(index_1);
                    m_pointIndices.append(index_2);
                    m_pointIndices.append(index_3);

                    //---latitude--rings----
                    m_edgeIndices.append(index_0);
                    m_edgeIndices.append(index_1);

                    //---longitude--rings-------
                    m_edgeIndices.append(index_1);
                    m_edgeIndices.append(index_2);

                    //m_edgeIndices.append(index_2);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_0);
                }
            }
        }

        printf("Indices computed %i",m_pointIndices.size());

        computeNormals();

        computeBounds();
    }


signals:

    void valueChanged();

private slots:

    void updateCylinder()
    {
        uv_cylinder(cylinderHeight,cylinderRadius,usteps,vsteps);

    }

    void setHeight()
    {
        cylinderHeight = hspinBox->value();
        emit valueChanged();
    }

    void setRadius()
    {
        cylinderRadius = rspinBox->value();
        emit valueChanged();
    }

    void setUsteps()
    {
        usteps = uspinBox->value();
        emit valueChanged();
    }

    void setVsteps()
    {
        vsteps = vspinBox->value();
        emit valueChanged();
    }
};

class QSphereModel : public QBaseModel
{
    Q_OBJECT

    int usteps;
    int vsteps;
    float radius;



    QSlider * uslider;
    QSlider * vslider;
    QDoubleSlider * rslider;

    QSpinBox * uspinBox;
    QSpinBox * vspinBox;
    QDoubleSpinBox * rspinBox;

public:


    enum { Type = MODEL_SPHERE};

    int type() const  { return Type; }


    QSphereModel(QObject * parent =0) : QBaseModel(parent)
    {
        usteps = 15;
        vsteps = 15;
        radius =  1;

        //vertices.clear();

        name = QString("Sphere Model");

        //name = QString("Sphere Model");
        uv_sphere(radius,usteps,vsteps);

        //computeBounds();

        addWidgets();

        setTheme();
    }

    ~QSphereModel()
    {
        delete widget;
    }

    void addWidgets()
    {
        widget = new QWidget;
        widget->setWindowTitle(QString(name));
        uslider = new QSlider(Qt::Horizontal);
        uslider->setValue(usteps);
        uslider->setMinimum(0);
        uslider->setMaximum(200);
        uslider->setSingleStep(1);

        vslider = new QSlider(Qt::Horizontal);
        vslider->setValue(vsteps);
        vslider->setMinimum(0);
        vslider->setMaximum(200);
        vslider->setSingleStep(1);

        rslider = new QDoubleSlider(Qt::Horizontal);
        rslider->setValue(radius);
        rslider->setMinimum(0);
        rslider->setMaximum(200);
        rslider->setSingleStep(.01);

        uspinBox = new QSpinBox;
        vspinBox = new QSpinBox;
        rspinBox = new QDoubleSpinBox;

        uspinBox->setMinimum(0);
        uspinBox->setMaximum(200);
        uspinBox->setSingleStep(1);

        vspinBox->setMinimum(0);
        vspinBox->setMaximum(200);
        vspinBox->setSingleStep(1);

        rspinBox->setMinimum(0);
        rspinBox->setMaximum(200);
        rspinBox->setSingleStep(.01);

        rspinBox->setValue(radius);
        uspinBox->setValue(usteps);
        vspinBox->setValue(vsteps);


        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("Radius:")));
        hlayout1->addWidget(rslider);
        hlayout1->addWidget(rspinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("u steps:")));
        hlayout2->addWidget(uslider);
        hlayout2->addWidget(uspinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("v steps:")));
        hlayout3->addWidget(vslider);
        hlayout3->addWidget(vspinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        layout->addWidget(qf1);
        layout->addWidget(qf2);
        layout->addWidget(qf3);

        widget->setLayout(layout);

        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(vspinBox,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));
        connect(rspinBox,SIGNAL(valueChanged(double)),this,SLOT(setRadius()));

        connect(uslider,SIGNAL(valueChanged(int)),uspinBox,SLOT(setValue(int)));
        connect(vslider,SIGNAL(valueChanged(int)),vspinBox,SLOT(setValue(int)));
        connect(rslider,SIGNAL(valueChanged(double)),rspinBox,SLOT(setValue(double)));

        connect(uspinBox,SIGNAL(valueChanged(int)),uslider,SLOT(setValue(int)));
        connect(vspinBox,SIGNAL(valueChanged(int)),vslider,SLOT(setValue(int)));
        connect(rspinBox,SIGNAL(valueChanged(double)),rslider,SLOT(setValue(double)));

        connect(this,SIGNAL(valueChanged()),this,SLOT(updateShere()));

        widget->show();
    }




    void uv_sphere(float radius, int u_seg =10, int v_seg=10)
    {
        QList< QPair<int,int> > tuples;

        if (u_seg > 0 && v_seg > 0)
        {
            m_points.clear();
            m_pointIndices.clear();
            m_normals.clear();
            m_edgeIndices.clear();

            float step_theta = M_PI / u_seg;
            float step_phie  = 2* M_PI / v_seg;

            for(int i =0; i < u_seg+1; i++)
            {
                float theta = i * step_theta;

                for(int j =0; j<v_seg+1;j++)
                {
                    tuples.append(QPair<int,int>(i, j));

                    float phie = j * step_phie;

                    float x = radius * sin(theta) * cos(phie);
                    float y = radius * sin(theta) * sin(phie);
                    float z = radius * cos(theta);

                    QVector3D p = QVector3D(x , y , z);

                    m_points.append(p);

                }
            }


            for( int i=0;i<u_seg;i++)
            {

                for(int j=0;j<v_seg;j++)
                {
                    int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));


                    m_pointIndices.append(index_0);
                    m_pointIndices.append(index_1);
                    m_pointIndices.append(index_2);
                    m_pointIndices.append(index_3);

                    //---latitude--rings----
                    m_edgeIndices.append(index_0);
                    m_edgeIndices.append(index_1);

                    //---longitude--rings-------
                    m_edgeIndices.append(index_1);
                    m_edgeIndices.append(index_2);

                    //m_edgeIndices.append(index_2);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_0);
                }
            }
        }

        tuples.clear();

        computeNormals();

        computeBounds();
    }

    virtual void scaleToBounds(QVector3D boundsMax,QVector3D boundsMin)
    {
        const QVector3D bounds = boundsMax - boundsMin;

        const qreal scale = 1 / qMax(bounds.x(), qMax(bounds.y(), bounds.z()));

        for (int i = 0; i < m_points.size(); ++i)
        {
            m_points[i] = (m_points[i] - (boundsMin + bounds * 0.5)) * scale;
        }
    }



signals:

    void valueChanged();

private slots:

    void updateShere()
    {

        uv_sphere(radius,usteps,vsteps);

    }

    void setRadius()
    {
        radius = rspinBox->value();

        emit valueChanged();
    }

    void setUsteps()
    {
        usteps = uspinBox->value();

        emit valueChanged();
    }

    void setVsteps()
    {
        vsteps = vspinBox->value();

        emit valueChanged();
    }


};

class QConeModel : public QBaseModel
{
    Q_OBJECT
    int usteps;
    int hsteps;

    float r1;
    float r2;
    float height;


    QIntWidget * uspinBox;
    QIntWidget * hspinBox;

    QDoubleWidget * r1spinBox;
    QDoubleWidget * r2spinBox;
    QDoubleWidget * heightSpinBox;

public:

    enum { Type = MODEL_CONE};

    int type() const  { return Type; }


    QConeModel(QObject * parent =0) : QBaseModel(parent)
    {
        usteps = 10;
        hsteps = 10;
        //boundingSphereRadius =  1;

        r1 = 1.0f;
        r2 = 0.01f;
        height  = 1.0f;

        m_points.clear();


        name = QString("Cone Model");

        uv_cone(r1,r2,height,usteps,hsteps);

        addWidgets();

        setTheme();


    }

    ~QConeModel()
    {
        delete widget;
     }

    void addWidgets()
         {
             widget = new QWidget;
             widget->setWindowTitle(QString(name));

             uspinBox = new QIntWidget;
             hspinBox = new QIntWidget;

             r1spinBox = new QDoubleWidget;
             r2spinBox = new QDoubleWidget;;
             heightSpinBox = new QDoubleWidget;

             uspinBox->setMinMaxValue(0,100,usteps,1);
             hspinBox->setMinMaxValue(0,100,hsteps,1);

             r1spinBox->setMinMaxValue(0,100,r1,0.01);
             r2spinBox->setMinMaxValue(0,100,r2,0.01);
             heightSpinBox->setMinMaxValue(0,100,height,0.01);


             QVBoxLayout * layout  = new QVBoxLayout;

             r1spinBox->setText(QString("R1:"));
             r2spinBox->setText(QString("R2:"));
             heightSpinBox->setText(QString("Height:"));
             uspinBox->setText(QString("U Steps:"));
             hspinBox->setText(QString("H Steps:"));


             layout->addWidget(heightSpinBox);
             layout->addWidget(r1spinBox);
             layout->addWidget(r2spinBox);
             layout->addWidget(uspinBox);
             layout->addWidget(hspinBox);


             widget->setLayout(layout);


             connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
             connect(hspinBox,SIGNAL(valueChanged(int)),this,SLOT(setHteps()));
             connect(r1spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR1()));
             connect(r2spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR2()));
             connect(heightSpinBox,SIGNAL(valueChanged(double)),this,SLOT(setHeight()));

             connect(this,SIGNAL(valueChanged()),this,SLOT(updateCone()));


             widget->show();
         }

    void uv_cone(float r1 = 10.0f, float r2 = 10.0f,float height=2.0f,int u_seg = 10, int h_seg = 10)
         {
             QList< QPair<int,int> > tuples;

             if(u_seg<3) { u_seg = 3; }
             if(h_seg<1) { h_seg = 1; }
             {
                 m_points.clear();
                 m_pointIndices.clear();
                 m_normals.clear();
                 m_edgeIndices.clear();


                 float step_theta =  2 * M_PI / u_seg;

                 float step_height  = height  / h_seg;
                 float step_radius = (r1 -r2) / h_seg;

                 for(int i =0;i<(h_seg+1);i++)
                 {

                     float y = i  * step_height;
                     float r = i  * step_radius + r1;

                     for(int j =0; j<(u_seg+1);j++)
                     {
                         float theta = j * step_theta;

                         float x = r * sin(theta);
                         float z = r * cos(theta);

                         QVector3D p = QVector3D(x , y , z);

                         m_points.append(p);
                         tuples.append(QPair<int,int>(i, j));

                     }
                 }


                 for( int i=0;i<h_seg;i++)
                 {
                     for(int j=0;j<u_seg;j++)
                     {
                         int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                         int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                         int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                         int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));

                         m_pointIndices.append(index_0);
                         m_pointIndices.append(index_1);
                         m_pointIndices.append(index_2);
                         m_pointIndices.append(index_3);

                         //---latitude--rings----
                         m_edgeIndices.append(index_0);
                         m_edgeIndices.append(index_1);

                         //---longitude--rings-------
                         m_edgeIndices.append(index_1);
                         m_edgeIndices.append(index_2);

                         //m_edgeIndices.append(index_2);
                         //m_edgeIndices.append(index_3);
                         //m_edgeIndices.append(index_3);
                         //m_edgeIndices.append(index_0);



                     }
                 }
             }

             computeNormals();

             computeBounds();

         }


signals:
    void valueChanged();

private slots:

    void updateCone()
    {

        uv_cone(r1,r2,height,usteps,hsteps);
    }

    void setR1()
    {
        r1= r1spinBox->getValue();
        emit valueChanged();
    }
    void setR2()
    {
        r2 = r2spinBox->getValue();
        emit valueChanged();
    }

    void setHeight()
    {
        height = heightSpinBox->getValue();
        emit valueChanged();
    }

    void setUsteps()
    {
        usteps = uspinBox->getValue();
        emit valueChanged();
    }

    void setHteps()
    {
        hsteps = hspinBox->getValue();
        emit valueChanged();
    }

};

class QSpiralModel : public QBaseModel
{
         Q_OBJECT

         int usteps;
         int hsteps;

         float r1;
         float r2;
         float height;

        float radius;

         QSpinBox * uspinBox;
         QSpinBox * hspinBox;

         QDoubleSpinBox * r1spinBox;
         QDoubleSpinBox * r2spinBox;

         QDoubleSpinBox * heightSpinBox;

     public:

         enum { Type = MODEL_SPIRAL};

         int type() const  { return Type; }


         QSpiralModel(QObject * parent =0) : QBaseModel(parent)
         {
             usteps = 10;
             hsteps = 10;
             radius =  1;

             r1 = 2.0f;
             r2 = 0.01f;
             height  = 2.0f;

             addWidgets();

             m_points.clear();


             name = QString("Spiral Model");

             uv_cone(r1,r2,height,usteps,hsteps);

             computeBounds();


         }


         ~QSpiralModel()
         {
             delete widget;
         }
         void addWidgets()
         {
             widget = new QWidget;
             widget->setWindowTitle(QString(name));

             uspinBox = new QSpinBox;
             hspinBox = new QSpinBox;

             r1spinBox = new QDoubleSpinBox;
             r2spinBox = new QDoubleSpinBox;;
             heightSpinBox = new QDoubleSpinBox;;

             uspinBox->setMinimum(0);
             uspinBox->setMaximum(100);
             uspinBox->setSingleStep(1);

             hspinBox->setMinimum(0);
             hspinBox->setMaximum(100);
             hspinBox->setSingleStep(1);


             r1spinBox->setMinimum(0);
             r1spinBox->setMaximum(100);
             r1spinBox->setSingleStep(.05);

             r2spinBox->setMinimum(0);
             r2spinBox->setMaximum(100);
             r2spinBox->setSingleStep(.05);

             heightSpinBox->setMinimum(0);
             heightSpinBox->setMaximum(100);
             heightSpinBox->setSingleStep(.05);

             r1spinBox->setValue(r1);
             r2spinBox->setValue(r2);
             uspinBox->setValue(usteps);
             hspinBox->setValue(hsteps);
             heightSpinBox->setValue(height);

             QVBoxLayout * layout  = new QVBoxLayout;

             QHBoxLayout * hlayout1 = new QHBoxLayout;
             hlayout1->addWidget(new QLabel(QString("R1:")));
             hlayout1->addWidget(r1spinBox);
             QFrame * qf1 =  new QFrame;
             qf1->setLayout(hlayout1);

             QHBoxLayout * hlayout2 = new QHBoxLayout;
             hlayout2->addWidget(new QLabel(QString("R2:")));
             hlayout2->addWidget(r2spinBox);
             QFrame * qf2 =  new QFrame;
             qf2->setLayout(hlayout2);

             QHBoxLayout * hlayout3 = new QHBoxLayout;
             hlayout3->addWidget(new QLabel(QString("Height:")));
             hlayout3->addWidget(heightSpinBox);
             QFrame * qf3 =  new QFrame;
             qf3->setLayout(hlayout3);

             QHBoxLayout * hlayout4 = new QHBoxLayout;
             hlayout4->addWidget(new QLabel(QString("U Steps:")));
             hlayout4->addWidget(uspinBox);
             QFrame * qf4 =  new QFrame;
             qf4->setLayout(hlayout4);

             QHBoxLayout * hlayout5 = new QHBoxLayout;
             hlayout5->addWidget(new QLabel(QString("H Steps:")));
             hlayout5->addWidget(hspinBox);
             QFrame * qf5 =  new QFrame;
             qf5->setLayout(hlayout5);




             layout->addWidget(qf1);
             layout->addWidget(qf2);
             layout->addWidget(qf3);
             layout->addWidget(qf4);
             layout->addWidget(qf5);

             widget->setLayout(layout);

             connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
             connect(hspinBox,SIGNAL(valueChanged(int)),this,SLOT(setHteps()));

             connect(r1spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR1()));
             connect(r2spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR2()));

             connect(heightSpinBox,SIGNAL(valueChanged(double)),this,SLOT(setHeight()));

             connect(this,SIGNAL(valueChanged(double)),this,SLOT(updateCone()));

             widget->show();
         }



         void uv_cone(float r1 = 10.0f, float r2 = 10.0f,float height=2.0f,int u_seg = 10, int h_seg = 10)
         {
             QList< QPair<int,int> > tuples;


             if(u_seg<3) { u_seg = 3; }
             if(h_seg<2) { h_seg = 2; }

             {
                 m_points.clear();
                 m_pointIndices.clear();
                 m_normals.clear();
                 m_edgeIndices.clear();

                 //float step_theta = 360 / u_seg;
                 float step_theta =  2 * M_PI / u_seg;

                 float step_height  = height  / h_seg;

                 float step_radius = (r1 -r2) / h_seg;


                 #pragma omp parallel for
                 for(int i =0;i<h_seg+1;i++)
                 {
                     float thetaRadians = i * step_theta;

                     float y = i  * step_height;

                     float r = i  * step_radius + r1;

                     #pragma omp parallel for
                     for(int j =0; j<u_seg+1;j++)
                     {
                         tuples.append(QPair<int,int>(i, j));

                         float x = r * sin(thetaRadians);

                         float z = r * cos(thetaRadians);

                         QVector3D p = QVector3D(x , y , z);

                         m_points.append(p);

                     }
                 }

                 #pragma omp parallel for
                 for( int i=0;i<h_seg;i++)
                 {
                     #pragma omp parallel for
                     for(int j=0;j<u_seg;j++)
                     {
                         int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                         int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                         int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                         int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));

                         m_pointIndices.append(index_0);
                         m_pointIndices.append(index_1);
                         m_pointIndices.append(index_2);
                         m_pointIndices.append(index_3);

                         //---latitude--rings----
                         m_edgeIndices.append(index_0);
                         m_edgeIndices.append(index_1);

                         //---longitude--rings-------
                         m_edgeIndices.append(index_1);
                         m_edgeIndices.append(index_2);

                         //m_edgeIndices.append(index_2);
                         //m_edgeIndices.append(index_3);
                         //m_edgeIndices.append(index_3);
                         //m_edgeIndices.append(index_0);



                     }
                 }
             }

             computeBounds();
         }


         void draw()
         {
             drawCone();
             drawBoundingBox();
         }

         void drawCone()
         {
             glPushMatrix();
             //printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());
             glTranslatef(position.x(),position.y(),position.z());

             glRotatef(rotation.x(),1,0,0);
             glRotatef(rotation.y(),0,1,0);
             glRotatef(rotation.z(),0,0,1);

             glScalef(scale.x(),scale.y(),scale.z());

             //printf("Polygons:%i \n",facesindices.length()/4);

             if(Selected)
             {
                 //glColor3f( .5, .25, .79);
                 glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
             }
             else
             {
                 //glColor3f( .5, .5, .1);
                 glColor3f( colorId.x(), colorId.y(), colorId.z());
             }


             drawModel();


             glPopMatrix();
         }

     signals:

         void valueChanged(double value);

     private slots:

         void updateCone()
         {
             uv_cone(r1,r2,height,usteps,hsteps);
         }

         void setR1()
         {
             r1 = r1spinBox->value();
             emit valueChanged(r1);
         }
         void setR2()
         {
             r2 = r2spinBox->value();
             emit valueChanged(r2);
         }

         void setHeight()
         {
             height = heightSpinBox->value();
             emit valueChanged(height);
         }

         void setUsteps()
         {
             usteps = uspinBox->value();
             emit valueChanged(usteps);
         }

         void setHteps()
         {
             hsteps = hspinBox->value();
             emit valueChanged(hsteps);
         }
     };

class QTorusModel : public QBaseModel
{
    Q_OBJECT

    int usteps;
    int vsteps;

    float r1;
    float r2;

    QSlider * uslider;
    QSlider * vslider;

    QDoubleSlider * r1slider;
    QDoubleSlider * r2slider;

    QSpinBox * uspinBox;
    QSpinBox * vspinBox;

    QDoubleSpinBox * r1spinBox;
    QDoubleSpinBox * r2spinBox;

public:

    enum { Type = MODEL_DONUT};

    int type() const  { return Type; }


    QTorusModel(QObject * parent =0) : QBaseModel(parent)
    {
        usteps = 10;
        vsteps = 10;

        //boundingSphereRadius = 1;

        r1 = 0.3;
        r2 = 1.0;

        m_points.clear();

        name = QString("Torus Model");

        n_donut(usteps,vsteps,r1,r2);

        addWidgets();

        setTheme();
    }

    ~QTorusModel()
    {
        delete widget;
    }
    void addWidgets()
    {



        widget = new QWidget;
        widget->setWindowTitle(QString(name));


        uslider = new QSlider(Qt::Horizontal);
        uslider->setValue(usteps);
        uslider->setMinimum(0);
        uslider->setMaximum(200);
        uslider->setSingleStep(1);

        vslider = new QSlider(Qt::Horizontal);
        vslider->setValue(vsteps);
        vslider->setMinimum(0);
        vslider->setMaximum(200);
        vslider->setSingleStep(1);

        r1slider = new QDoubleSlider(Qt::Horizontal);
        r1slider->setValue(r1);
        r1slider->setMinimum(0);
        r1slider->setMaximum(200);
        r1slider->setSingleStep(.01);

        r2slider = new QDoubleSlider(Qt::Horizontal);
        r2slider->setValue(r2);
        r2slider->setMinimum(0);
        r2slider->setMaximum(200);
        r2slider->setSingleStep(.01);




        uspinBox = new QSpinBox;
        vspinBox = new QSpinBox;

        r1spinBox = new QDoubleSpinBox;
        r2spinBox = new QDoubleSpinBox;


        uspinBox->setMinimum(0);
        uspinBox->setMaximum(200);
        uspinBox->setSingleStep(1);


        vspinBox->setMinimum(0);
        vspinBox->setMaximum(200);
        vspinBox->setSingleStep(1);


        r1spinBox->setMinimum(0);
        r1spinBox->setMaximum(200);
        r1spinBox->setSingleStep(.1);

        r2spinBox->setMinimum(0);
        r2spinBox->setMaximum(200);
        r2spinBox->setSingleStep(.1);


        r2spinBox->setValue(r2);
        r1spinBox->setValue(r1);
        uspinBox->setValue(usteps);
        vspinBox->setValue(vsteps);

        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("R1:")));
        hlayout1->addWidget(r1slider);
        hlayout1->addWidget(r1spinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout4 = new QHBoxLayout;
        hlayout4->addWidget(new QLabel(QString("R2:")));
        hlayout4->addWidget(r2slider);
        hlayout4->addWidget(r2spinBox);
        QFrame * qf4 =  new QFrame;
        qf4->setLayout(hlayout4);


        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("u steps:")));
        hlayout2->addWidget(uslider);
        hlayout2->addWidget(uspinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("v steps:")));
        hlayout3->addWidget(vslider);
        hlayout3->addWidget(vspinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);



        layout->addWidget(qf1);
        layout->addWidget(qf4);
        layout->addWidget(qf2);
        layout->addWidget(qf3);

       layout->addWidget(transformWidget);


        widget->setLayout(layout);

        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(vspinBox,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));
        connect(r1spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR1()));
        connect(r2spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR2()));

        connect(uslider,SIGNAL(valueChanged(int)),uspinBox,SLOT(setValue(int)));
        connect(vslider,SIGNAL(valueChanged(int)),vspinBox,SLOT(setValue(int)));
        connect(r1slider,SIGNAL(valueChanged(double)),r1spinBox,SLOT(setValue(double)));
        connect(r2slider,SIGNAL(valueChanged(double)),r2spinBox,SLOT(setValue(double)));


        connect(uspinBox,SIGNAL(valueChanged(int)),uslider,SLOT(setValue(int)));
        connect(vspinBox,SIGNAL(valueChanged(int)),vslider,SLOT(setValue(int)));
        connect(r2spinBox,SIGNAL(valueChanged(double)),r2slider,SLOT(setValue(double)));
        connect(r1spinBox,SIGNAL(valueChanged(double)),r1slider,SLOT(setValue(double)));


        connect(this,SIGNAL(valueChanged()),this,SLOT(updateTorus()));

        widget->show();
    }

    void n_donut(int sides ,int rings,float r,float R)
    {
        QList< QPair<int,int> > tuples;


        if (sides> 0 && rings > 0)
        {
            m_points.clear();
            m_pointIndices.clear();
            m_normals.clear();
            m_edgeIndices.clear();



            float step_theta = 2*M_PI / sides;
            float step_phie  = 2*M_PI / rings;

            for(int i=0;i<(sides+1);i++)
            {
                float angle_theta = i *step_theta ;

                for(int j=0;j<(rings+1);j++)
                {
                    float angle_phie = j * step_phie;

                    float x = ( R + r * cos(angle_theta)) * cos( angle_phie);
                    float z = ( R + r * cos(angle_theta)) * sin( angle_phie);

                    float y = r * sin(angle_theta);

                    QVector3D p = QVector3D(x , y , z );

                    m_points.append(p);
                    tuples.append(QPair<int,int>(i, j));


                }
            }


            //#pragma omp parallel for
            for( int i=0;i<sides;i++)
            {
                //#pragma omp parallel for
                for(int j=0;j<rings;j++)
                {
                    int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));

                    m_pointIndices.append(index_0);
                    m_pointIndices.append(index_1);
                    m_pointIndices.append(index_2);
                    m_pointIndices.append(index_3);

                    //---latitude--rings----
                    m_edgeIndices.append(index_0);
                    m_edgeIndices.append(index_1);

                    //---longitude--rings-------
                    m_edgeIndices.append(index_1);
                    m_edgeIndices.append(index_2);

                    //m_edgeIndices.append(index_2);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_0);



                }
            }
        }

        computeNormals();

        computeBounds();
    }

signals:

    void valueChanged();

private slots:

    void updateTorus()
    {
        n_donut(usteps,vsteps,r1,r2);
    }

    void setR1()
    {
        r1 = r1spinBox->value();
        emit valueChanged();
    }

    void setR2()
    {
        r2 = r2spinBox->value();
        emit valueChanged();
    }

    void setUsteps()
    {
        usteps = uspinBox->value();
        emit valueChanged();
    }

    void setVsteps()
    {
        vsteps = vspinBox->value();
        emit valueChanged();
    }


};

class QSplineModel : public QBaseModel
{
    Q_OBJECT

    int usteps;
    int hsteps;

    float r1;
    float r2;
    float height;

    QSpinBox * uspinBox;
    QSpinBox * hspinBox;

    QDoubleSpinBox * r1spinBox;
    QDoubleSpinBox * r2spinBox;

    QDoubleSpinBox * heightSpinBox;

public:

    enum { Type = MODEL_SPLINE};

    int type() const  { return Type; }


    QSplineModel(QObject * parent =0) : QBaseModel(parent)
    {
        usteps = 10;
        hsteps = 10;
        //boundingSphereRadius =  1;

        r1 = 2.0f;
        r2 = 0.01f;
        height  = 2.0f;



        m_points.clear();


        name = QString("Spline Model");

        uv_cone(r1,r2,height,usteps,hsteps);

        computeBounds();

        addWidgets();

    }

    ~QSplineModel()
    {
        delete widget;
    }
    void addWidgets()
    {
        widget = new QWidget;
        widget->setWindowTitle(QString(name));

        uspinBox = new QSpinBox;
        hspinBox = new QSpinBox;

        r1spinBox = new QDoubleSpinBox;
        r2spinBox = new QDoubleSpinBox;;
        heightSpinBox = new QDoubleSpinBox;;

        uspinBox->setMinimum(0);
        uspinBox->setMaximum(100);
        uspinBox->setSingleStep(1);

        hspinBox->setMinimum(0);
        hspinBox->setMaximum(100);
        hspinBox->setSingleStep(1);


        r1spinBox->setMinimum(0);
        r1spinBox->setMaximum(100);
        r1spinBox->setSingleStep(.05);

        r2spinBox->setMinimum(0);
        r2spinBox->setMaximum(100);
        r2spinBox->setSingleStep(.05);

        heightSpinBox->setMinimum(0);
        heightSpinBox->setMaximum(100);
        heightSpinBox->setSingleStep(.05);

        r1spinBox->setValue(r1);
        r2spinBox->setValue(r2);
        uspinBox->setValue(usteps);
        hspinBox->setValue(hsteps);
        heightSpinBox->setValue(height);

        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("R1:")));
        hlayout1->addWidget(r1spinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("R2:")));
        hlayout2->addWidget(r2spinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("Height:")));
        hlayout3->addWidget(heightSpinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        QHBoxLayout * hlayout4 = new QHBoxLayout;
        hlayout4->addWidget(new QLabel(QString("U Steps:")));
        hlayout4->addWidget(uspinBox);
        QFrame * qf4 =  new QFrame;
        qf4->setLayout(hlayout4);

        QHBoxLayout * hlayout5 = new QHBoxLayout;
        hlayout5->addWidget(new QLabel(QString("H Steps:")));
        hlayout5->addWidget(hspinBox);
        QFrame * qf5 =  new QFrame;
        qf5->setLayout(hlayout5);




        layout->addWidget(qf1);
        layout->addWidget(qf2);
        layout->addWidget(qf3);
        layout->addWidget(qf4);
        layout->addWidget(qf5);

        widget->setLayout(layout);

        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(hspinBox,SIGNAL(valueChanged(int)),this,SLOT(setHteps()));

        connect(r1spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR1()));
        connect(r2spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR2()));

        connect(heightSpinBox,SIGNAL(valueChanged(double)),this,SLOT(setHeight()));

        connect(this,SIGNAL(valueChanged(double)),this,SLOT(updateCone()));

        widget->show();
    }



    void interpolate(float r1,float r2,int divisions)
    {
        float r = r2-r1;

        float step_r =  r/divisions;

    }

    void uv_cone(float r1 = 10.0f, float r2 = 10.0f,float height=2.0f,int u_seg = 10, int h_seg = 10)
    {
        QList< QPair<int,int> > tuples;


        if(u_seg<3) { u_seg = 3; }
        if(h_seg<1) { h_seg = 1; }
        {
            m_points.clear();
            m_pointIndices.clear();
            m_normals.clear();
            m_edgeIndices.clear();


            float step_theta =  2 * M_PI / u_seg;

            float step_height  = height  / h_seg;
            float step_radius = (r1 -r2) / h_seg;



            for(int i =0;i<(h_seg+1);i++)
            {
                float theta = i * step_theta;

                float y = i  * step_height;

                float r = i  * step_radius + r1;


                for(int j =0; j<(u_seg+1);j++)
                {
                    float x = r * sin(theta);
                    float z = r * cos(theta);

                    QVector3D p = QVector3D(x , y , z);

                    m_points.append(p);
                    tuples.append(QPair<int,int>(i, j));

                }
            }


            for( int i=0;i<h_seg;i++)
            {
                for(int j=0;j<u_seg;j++)
                {
                    int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));

                    m_pointIndices.append(index_0);
                    m_pointIndices.append(index_1);
                    m_pointIndices.append(index_2);
                    m_pointIndices.append(index_3);

                    //---latitude--rings----
                    m_edgeIndices.append(index_0);
                    m_edgeIndices.append(index_1);

                    //---longitude--rings-------
                    m_edgeIndices.append(index_1);
                    m_edgeIndices.append(index_2);

                    //m_edgeIndices.append(index_2);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_0);

                }
            }
        }

        computeBounds();
        computeNormals();
    }




    void draw()
    {
        drawCone();

        drawBoundingBox();
    }

    void drawCone()
    {
        glPushMatrix();
        //printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());
        glTranslatef(position.x(),position.y(),position.z());

        glRotatef(rotation.x(),1,0,0);
        glRotatef(rotation.y(),0,1,0);
        glRotatef(rotation.z(),0,0,1);

        glScalef(scale.x(),scale.y(),scale.z());

        //printf("Polygons:%i \n",facesindices.length()/4);

        if(Selected)
        {
            //glColor3f( .5, .25, .79);
            glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
        }
        else
        {
            //glColor3f( .5, .5, .1);
            glColor3f( colorId.x(), colorId.y(), colorId.z());
        }

        drawModel();

        glPopMatrix();
    }

signals:

    void valueChanged(double value);

private slots:

    void updateCone()
    {
        uv_cone(r1,r2,height,usteps,hsteps);
    }

    void setR1()
    {
        r1 = r1spinBox->value();
        emit valueChanged(r1);
    }
    void setR2()
    {
        r2 = r2spinBox->value();
        emit valueChanged(r2);
    }

    void setHeight()
    {
        height = heightSpinBox->value();
        emit valueChanged(height);
    }

    void setUsteps()
    {
        usteps = uspinBox->value();
        emit valueChanged(usteps);
    }

    void setHteps()
    {
        hsteps = hspinBox->value();
        emit valueChanged(hsteps);
    }

};

class QTubeModel : public QBaseModel
{
    Q_OBJECT

    int usteps;
    int hsteps;

    float r1;
    float r2;
    float height;

    QSpinBox * uspinBox;
    QSpinBox * hspinBox;

    QDoubleSpinBox * r1spinBox;
    QDoubleSpinBox * r2spinBox;

    QDoubleSpinBox * heightSpinBox;

public:

    enum { Type = MODEL_TUBE};

    int type() const  { return Type; }


    QTubeModel(QObject * parent =0) : QBaseModel(parent)
    {
        usteps = 10;
        hsteps = 10;
        //boundingSphereRadius =  1;

        r1 = 2.0f;
        r2 = 0.01f;
        height  = 2.0f;

        m_points.clear();

        name = QString("Tube Model");

        uv_cone(r1,r2,height,usteps,hsteps);

        computeBounds();

        addWidgets();

        setTheme();
    }

    ~QTubeModel()
    {
        delete widget;
    }

    void addWidgets()
    {
        widget = new QWidget;
        widget->setWindowTitle(QString(name));

        uspinBox = new QSpinBox;
        hspinBox = new QSpinBox;

        r1spinBox = new QDoubleSpinBox;
        r2spinBox = new QDoubleSpinBox;;
        heightSpinBox = new QDoubleSpinBox;;

        uspinBox->setMinimum(0);
        uspinBox->setMaximum(100);
        uspinBox->setSingleStep(1);

        hspinBox->setMinimum(0);
        hspinBox->setMaximum(100);
        hspinBox->setSingleStep(1);


        r1spinBox->setMinimum(0);
        r1spinBox->setMaximum(100);
        r1spinBox->setSingleStep(.05);

        r2spinBox->setMinimum(0);
        r2spinBox->setMaximum(100);
        r2spinBox->setSingleStep(.05);

        heightSpinBox->setMinimum(0);
        heightSpinBox->setMaximum(100);
        heightSpinBox->setSingleStep(.05);

        r1spinBox->setValue(r1);
        r2spinBox->setValue(r2);
        uspinBox->setValue(usteps);
        hspinBox->setValue(hsteps);
        heightSpinBox->setValue(height);

        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("R1:")));
        hlayout1->addWidget(r1spinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("R2:")));
        hlayout2->addWidget(r2spinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("Height:")));
        hlayout3->addWidget(heightSpinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        QHBoxLayout * hlayout4 = new QHBoxLayout;
        hlayout4->addWidget(new QLabel(QString("U Steps:")));
        hlayout4->addWidget(uspinBox);
        QFrame * qf4 =  new QFrame;
        qf4->setLayout(hlayout4);

        QHBoxLayout * hlayout5 = new QHBoxLayout;
        hlayout5->addWidget(new QLabel(QString("H Steps:")));
        hlayout5->addWidget(hspinBox);
        QFrame * qf5 =  new QFrame;
        qf5->setLayout(hlayout5);




        layout->addWidget(qf1);
        layout->addWidget(qf2);
        layout->addWidget(qf3);
        layout->addWidget(qf4);
        layout->addWidget(qf5);

        widget->setLayout(layout);

        connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
        connect(hspinBox,SIGNAL(valueChanged(int)),this,SLOT(setHteps()));

        connect(r1spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR1()));
        connect(r2spinBox,SIGNAL(valueChanged(double)),this,SLOT(setR2()));

        connect(heightSpinBox,SIGNAL(valueChanged(double)),this,SLOT(setHeight()));

        connect(this,SIGNAL(valueChanged(double)),this,SLOT(updateCone()));

        widget->show();
    }

    void interpolate(float r1,float r2,int divisions)
    {
        float r = r2-r1;

        float step_r =  r/divisions;

    }

    void uv_cone(float r1 = 10.0f, float r2 = 10.0f,float height=2.0f,int u_seg = 10, int h_seg = 10)
    {
        QList< QPair<int,int> > tuples;


        if(u_seg<3) { u_seg = 3; }
        if(h_seg<1) { h_seg = 1; }
        {
            m_points.clear();
            m_pointIndices.clear();
            m_normals.clear();
            m_edgeIndices.clear();


            float step_theta =  2 * M_PI / u_seg;

            float step_height  = height  / h_seg;
            float step_radius = (r1 -r2) / h_seg;



            for(int i =0;i<(h_seg+1);i++)
            {
                float theta = i * step_theta;

                float y = i  * step_height;

                float r = i  * step_radius + r1;


                for(int j =0; j<(u_seg+1);j++)
                {
                    float x = r * sin(theta);
                    float z = r * cos(theta);

                    QVector3D p = QVector3D(x , y , z);

                    m_points.append(p);
                    tuples.append(QPair<int,int>(i, j));

                }
            }


            for( int i=0;i<h_seg;i++)
            {
                for(int j=0;j<u_seg;j++)
                {
                    int index_0 = tuples.indexOf(QPair<int,int>(i, j));
                    int index_1 = tuples.indexOf(QPair<int,int>(i, j + 1));
                    int index_2 = tuples.indexOf(QPair<int,int>(i + 1, j + 1));
                    int index_3 = tuples.indexOf(QPair<int,int>(i + 1, j));

                    m_pointIndices.append(index_0);
                    m_pointIndices.append(index_1);
                    m_pointIndices.append(index_2);
                    m_pointIndices.append(index_3);

                    //---latitude--rings----
                    m_edgeIndices.append(index_0);
                    m_edgeIndices.append(index_1);

                    //---longitude--rings-------
                    m_edgeIndices.append(index_1);
                    m_edgeIndices.append(index_2);

                    //m_edgeIndices.append(index_2);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_3);
                    //m_edgeIndices.append(index_0);

                }
            }
        }

        computeNormals();

        computeBounds();

    }

signals:

    void valueChanged(double value);

private slots:

    void updateCone()
    {
        uv_cone(r1,r2,height,usteps,hsteps);
    }

    void setR1()
    {
        r1 = r1spinBox->value();
        emit valueChanged(r1);
    }

    void setR2()
    {
        r2 = r2spinBox->value();
        emit valueChanged(r2);
    }

    void setHeight()
    {
        height = heightSpinBox->value();
        emit valueChanged(height);
    }

    void setUsteps()
    {
        usteps = uspinBox->value();
        emit valueChanged(usteps);
    }

    void setHteps()
    {
        hsteps = hspinBox->value();
        emit valueChanged(hsteps);
    }
};

class QCameraModel2 : public QBaseModel
{
         Q_OBJECT
     public:
         enum QCameraView
         {
             TOP = 0,
             BOTTOM,
             FRONT,
             BACK,
             LEFT,
             RIGHT,
             PERSPECTIVE,
             ORTHO
         };

         enum QCameraOrbitMode
         {
             WORLDCENTER,
             SELECTED,
             VIEWCNTER,
         };

         QCameraView getCameraView()
         {
             return cameraView;
         }

         QCameraOrbitMode getCameraOrbitMode()
         {
             return cameraOrbitMode;
         }
         void setCameraOrbitMode(QCameraOrbitMode mode = WORLDCENTER)
         {
             cameraOrbitMode = mode;
         }

     private:

         QCameraView cameraView;
         QCameraOrbitMode cameraOrbitMode;

         QDoubleSpinBox * farspinBox;
         QDoubleSpinBox * nearspinBox;
         QDoubleSpinBox * fovSpinBox;

     public:

         enum { Type = MODEL_CAMERA};

         int type() const  { return Type; }

         //transforms
         //QVector3D position;
         QVector3D target;
         QVector3D up;
         //QVector3D rotation;

         //clipping
         float clipfar;
         float clipnear;

         //lens
         float fov;//field of view
         float aspectRatio;
         float zoomvalue;
         float boundingSphereRadius;

         //mouse controls
         qreal sensitivity;
         QVector2D delta2D;

         QSizeF viewport;
         QSizeF viewportSafeTitle;
         QSizeF viewportSafeFrame;


         QCameraModel2(QObject * parent = 0) : QBaseModel(parent)
         {
             initVertices();

             reset();
             setCameraView(PERSPECTIVE);

             aspectRatio = 1.0f;

             clipnear  = 0.001f;
             clipfar   = 9500.0f;
             fov       = 45.0f;

             zoomvalue   = 3;
             sensitivity = 1;
             boundingSphereRadius = 1;

             addWidgets();
         }

         ~QCameraModel2()
         {
             delete widget;
         }
         void addWidgets()
         {

             widget = new QWidget;
             widget->setWindowTitle(QString(name));

             farspinBox  = new QDoubleSpinBox;
             nearspinBox = new QDoubleSpinBox;;
             fovSpinBox  = new QDoubleSpinBox;;

             farspinBox->setMinimum(0);
             farspinBox->setMaximum(10000);
             farspinBox->setSingleStep(0.1);

             nearspinBox->setMinimum(0);
             nearspinBox->setMaximum(10000);
             nearspinBox->setSingleStep(0.1);

             fovSpinBox->setMinimum(0);
             fovSpinBox->setMaximum(360);
             fovSpinBox->setSingleStep(0.1);

             farspinBox->setValue(clipfar);
             nearspinBox->setValue(clipnear);
             fovSpinBox->setValue(fov);


             QVBoxLayout * layout  = new QVBoxLayout;

             QHBoxLayout * hlayout1 = new QHBoxLayout;
             hlayout1->addWidget(new QLabel(QString("Far Clip:")));
             hlayout1->addWidget(farspinBox);
             QFrame * qf1 =  new QFrame;
             qf1->setLayout(hlayout1);

             QHBoxLayout * hlayout2 = new QHBoxLayout;
             hlayout2->addWidget(new QLabel(QString("Near Clip:")));
             hlayout2->addWidget(nearspinBox);
             QFrame * qf2 =  new QFrame;
             qf2->setLayout(hlayout2);

             QHBoxLayout * hlayout3 = new QHBoxLayout;
             hlayout3->addWidget(new QLabel(QString("Field of View:")));
             hlayout3->addWidget(fovSpinBox);
             QFrame * qf3 =  new QFrame;
             qf3->setLayout(hlayout3);



             layout->addWidget(qf1);
             layout->addWidget(qf2);
             layout->addWidget(qf3);
             layout->addWidget(transformWidget);

             widget->setLayout(layout);


             connect(farspinBox,SIGNAL(valueChanged(double)),this,SLOT(setFar()));
             connect(nearspinBox,SIGNAL(valueChanged(double)),this,SLOT(seNear()));

             connect(fovSpinBox,SIGNAL(valueChanged(double)),this,SLOT(setFov()));

             //connect(this,SIGNAL(valueChanged(double)),this,SLOT(updateCone()));

             widget->show();

         }

         //////

         void translate(QVector3D deltaPos)
         {
             position += deltaPos;
         }


         //////navigation
         void rotate(QPoint delta)
         {
             if(cameraView == PERSPECTIVE)
             {
                 QVector3D deltaVec;

                 deltaVec += QVector3D((delta.y()*sensitivity),(delta.x()*sensitivity),0);

                 rotation += deltaVec;

             }
             else
             {

             }
         }

         void zoom(qreal delta)
         {
             if(cameraView == PERSPECTIVE)
             {
                 QVector3D dir = target-position;

                 dir.normalize();

                 zoomvalue += (delta*0.05);

                 dir *= (0.05 * delta);

                 position += dir;

                 target += dir;
             }
             else
             {
                 zoomvalue += (delta*0.05);
             }
         }

         void pan(QPoint delta)
         {
             if(cameraView == PERSPECTIVE)
             {
                 QVector3D dir = target-position;

                 dir.normalize();

                 QVector3D normal = QVector3D::crossProduct(dir,up);
                 QVector3D updelta = up;

                 updelta *= (delta.y()*-0.015);
                 normal  *= (delta.x()*-0.015);

                 QVector3D finalOffset = updelta+ normal;

                 target   += finalOffset;
                 position += finalOffset;
             }
             else
             {

             }
         }

         /////
         void reset()
         {
             rotation = QVector3D(0,0,0);
             up       = QVector3D(0,1,0);
             position = QVector3D(0.0, 0, -10.0);
             target   = QVector3D(0.0f, 0.0f, 0.0f);
             rotation = QVector3D(32,-37,0);
         }

         void setOrtho(int width,int height)
         {
             QMatrix4x4 m;

             m.ortho(0,width,height,0,clipnear,clipfar);

             glMultMatrixf((GLfloat*)m.data());
         }

         void setCameraView(QCameraView view = PERSPECTIVE)
         {
             cameraView =  view;

             switch(cameraView)
             {
             case FRONT://0
                 position  = QVector3D(0,0,1);
                 target    = QVector3D(0,0,0);
                 up        = QVector3D(0,1,0);
                 break;

             case BACK://1
                 position  = QVector3D(0,0,-1);
                 target    = QVector3D(0,0,0);
                 up        = QVector3D(0,1,0);
                 break;

             case TOP://2

                 position = QVector3D(0,1,0);
                 target   = QVector3D(0,0,0);
                 up       = QVector3D(0,0,-1);
                 break;

             case BOTTOM://3
                 position    = QVector3D(0,-1,0);
                 target = QVector3D(0,0,0);
                 up     = QVector3D(0,0,1);
                 break;

             case LEFT://4
                 position      = QVector3D(-1,0,0);
                 target   = QVector3D(0,0,0);
                 up       = QVector3D(0,1,0);
                 break;

             case RIGHT://5
                 position    = QVector3D(1,0,0);
                 target = QVector3D(0,0,0);
                 up     = QVector3D(0,1,0);
                 break;

             case PERSPECTIVE://6
                 reset();
                 break;
             case ORTHO:
                 reset();
                 break;

            default:

                 break;
             }
         }

         void setViewPort(int w,int h)
         {
             viewport = QSize(w,h);

             viewportSafeTitle = viewport - QSize(100,100);
             viewportSafeFrame = viewport - QSize(50,50);

             aspectRatio = (GLfloat) viewport.width() /(GLfloat) viewport.height() ;


             glViewport (0, 0, (GLsizei) viewport.width(), (GLsizei) viewport.height());
             glMatrixMode (GL_PROJECTION);
             glLoadIdentity ();

             gluPerspective(fov, aspectRatio, clipnear, clipfar);
             glMatrixMode(GL_MODELVIEW);
             glLoadIdentity();

         }

         void switchCameraView(QKeyEvent * event)
         {
             switch(event->key())
             {
             case Qt::Key_1:
                 setCameraView(FRONT);
                 break;

             case Qt::Key_2:
                 setCameraView(BOTTOM);
                 break;

             case Qt::Key_3:
                 setCameraView(FRONT);

                 break;

             case Qt::Key_4:
                setCameraView(BACK);
                 break;

             case Qt::Key_5:
                setCameraView(LEFT);
                 break;

             case Qt::Key_6:
                 setCameraView(RIGHT);
                 break;

             case Qt::Key_7:
                 setCameraView(ORTHO);

                 break;

             case Qt::Key_8:
                 setCameraView(PERSPECTIVE);
                 break;

             }

         }

         void cameraNavigation(QMouseEvent *event,QPoint delta)
         {
             if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::MiddleButton)
             {
                 pan(delta);
             }
             else if (event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::LeftButton)
             {
                 rotate(delta);
             }
             else if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::RightButton)
             {

             }
         }

         void orbitView()
         {
             if(cameraView == PERSPECTIVE)
             {

                 glMatrixMode( GL_PROJECTION );
                 glLoadIdentity();

                 glMatrixMode( GL_MODELVIEW);
                 glLoadIdentity();//important

                 gluPerspective( fov,aspectRatio,clipnear,clipfar );
                 glTranslatef(position.x(), position.y(), position.z());

                 glRotatef(rotation.x(), 1, 0, 0);
                 glRotatef(rotation.y(), 0, 1, 0);
                 glRotatef(rotation.z(), 0, 0, 1);
                 //printViewMatrix();
             }
             else
             {
                 glMatrixMode( GL_PROJECTION );
                 glLoadIdentity();

                 glMatrixMode( GL_MODELVIEW);
                 glLoadIdentity();//important

                 glOrtho(0,viewport.width(),viewport.height(),0,clipnear,clipfar);

                 //gluPerspective( fov,aspectRatio,clipnear,clipfar );
                 glTranslatef(position.x(), position.y(), position.z());

                 glRotatef(rotation.x(), 1, 0, 0);
                 glRotatef(rotation.y(), 0, 1, 0);
                 glRotatef(rotation.z(), 0, 0, 1);

                 /*
                 glMatrixMode( GL_PROJECTION );
                 glLoadIdentity();
                 glOrtho( -zoomvalue*aspectRatio, zoomvalue*aspectRatio, -zoomvalue, zoomvalue, clipnear, clipfar );

                 //glViewport( 0, 0, width(), height()) );

                 glMatrixMode( GL_MODELVIEW );
                 glLoadIdentity();
                 gluLookAt(position.x(), position.y(), position.z(),   // Eye-position (above)
                           target.x(), target.z(),target.z(),     // View-point
                           up.x(), up.y(), up.z() );   // Up-vector

                 */
             }

         }

         /*

         void printViewMatrix()
         {
             qDebug()<<"Pos:"<<position.x()<<","<<position.y()<<","<<position.z();
             qDebug()<<"rotation:"<<rotation.x()<<","<<rotation.y()<<","<<rotation.z();
             qDebug()<<"target:"<<target.x()<<","<<target.y()<<","<<target.z();

             float viewmatrix[16];

             glGetFloatv(GL_MODELVIEW_MATRIX,viewmatrix);

             for(int i=0;i<16;i+=4)
             {
                 qDebug()<<"View matrix:"<<viewmatrix[0+i]<<viewmatrix[1+i]<<viewmatrix[2+i]<<viewmatrix[3+i];
             }
         }

         void drawtext2D(QGLWidget *w,Text text)
         {
             text.setText(text.getText());
             text.drawtext2D(w,QColor(0,0,0));
         }


         void drawText2D()
         {

             QString xstr(" X");
             QFont font;
             font.setPointSize(15);

             glColor3f(1.0f, 0.0f, 0.0f);
             renderText(1.0f, 0.0f, 0.0f,xstr,font);

         }



         */

         void  draw()
         {
             glPushMatrix();
             //printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());
             //glTranslatef(position.x(),position.y(),position.z());

             //glRotatef(rotation.x(),1,0,0);
             //glRotatef(rotation.y(),0,1,0);
             //glRotatef(rotation.z(),0,0,1);

             //glScalef(scale.x(),scale.y(),scale.z());

             //printf("Polygons:%i \n",facesindices.length()/4);

             if(Selected)
             {
                 //glColor3f( .5, .25, .79);
                 glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
             }
             else
             {
                 //glColor3f( .5, .5, .1);
                 glColor3f( colorId.x(), colorId.y(), colorId.z());
             }
             drawCamera();

             glPopMatrix();

             drawBoundingBox();
         }

         void initVertices()
         {
             int count = sizeof(Globals::cameraVertices)/sizeof(float);

             count/= 3;

             for(int i=0;i<count;i+=3)
             {
                 QVector3D v(Globals::cameraVertices[i],Globals::cameraVertices[i+1],Globals::cameraVertices[i+2]);

                 m_points.append(v);
             }

             computeBounds();

         }

         void drawCamera()
         {
             float shininess = 32.0f;
             float diffuseColor[3] = {1.0f, 1.0f, 1.0f};
             float specularColor[4] = {1.0f, 1.0f, 1.0f, 1.0f};

             // set specular and shiniess using glMaterial
             glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess); // range 0 ~ 128
             glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specularColor);

             // set ambient and diffuse color using glColorMaterial (gold-yellow)
             glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
             glColor3fv(diffuseColor);

             // start to render polygons
             glEnableClientState(GL_NORMAL_ARRAY);
             glEnableClientState(GL_VERTEX_ARRAY);

             glNormalPointer(GL_FLOAT, 0, Globals::cameraNormals);
             glVertexPointer(3, GL_FLOAT, 0, Globals::cameraVertices);

             glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[0]);
             glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[5]);
             glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[10]);
             glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[15]);
             glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[20]);
             glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[25]);
             glDrawElements(GL_TRIANGLE_STRIP, 39, GL_UNSIGNED_INT, &Globals::cameraIndices[30]);
             glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[69]);
             glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[113]);
             glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[157]);
             glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[201]);

             glDisableClientState(GL_VERTEX_ARRAY);	// disable vertex arrays
             glDisableClientState(GL_NORMAL_ARRAY);	// disable normal arrays
         }


     signals:

         void valueChanged(double value);

     private slots:

         void updateCone()
         {
            // uv_cone(r1,r2,height,usteps,hsteps);
         }
         void setFar()
         {
             clipfar = farspinBox->value();
             emit valueChanged(clipfar);
         }
         void seNear()
         {
             clipnear = nearspinBox->value();
             emit valueChanged(clipnear);
         }
         void setFov()
         {
             fov = fovSpinBox->value();
             emit valueChanged(fov);
         }
};

class QCameraModel : public QBaseModel
{
    Q_OBJECT

private:

    QDoubleSpinBox * farspinBox;
    QDoubleSpinBox * nearspinBox;
    QDoubleSpinBox * fovSpinBox;

public:

    enum QCameraView
    {
        TOP = 0,
        BOTTOM,
        FRONT,
        BACK,
        LEFT,
        RIGHT,
        PERSPECTIVE,
        ORTHO,
        FRUSTRUM,

    };

    enum QCameraOrbitMode
    {
        WORLDCENTER,
        SELECTED,
        VIEWCNTER,

    };

    QCameraView getCameraView()
    {
        return PerspectiveMode;
    }

    QCameraOrbitMode getCameraOrbitMode()
    {
        return OrbitMode;
    }

    void setCameraOrbitMode(QCameraOrbitMode mode = WORLDCENTER)
    {
        OrbitMode = mode;
    }

public:

    //QMatrix4x4 projection;

    enum { Type = MODEL_CAMERA};

    int type() const  { return Type; }

    //transforms
    //QVector3D position;
    QVector3D target;
    QVector3D up;
    //QVector3D rotation;

    //clipping
    float zFar;
    float zNear;

    //lens
    float fov;//field of view
    float aspectRatio;
    float zoomvalue;
    float boundingSphereRadius;

    //mouse controls
    qreal sensitivity;
    QVector2D delta2D;

    QSizeF viewport;
    QSizeF viewportSafeTitle;
    QSizeF viewportSafeFrame;

    QMatrix4x4 ProjectionMatrix;
    QMatrix4x4 viewMatrix;

    QRay viewRay;


    QCameraView PerspectiveMode;

    QCameraOrbitMode OrbitMode;



    QCameraModel(QObject * parent = 0) : QBaseModel(parent)
    {
        initVertices();

        PerspectiveMode = PERSPECTIVE;

        aspectRatio = 1.0f;

        zNear  = 0.001f;
        zFar   = 1500.0f;
        fov    = 45.0f;

        zoomvalue   = 3.0f;
        sensitivity = 0.01f;
        boundingSphereRadius = 1;

        up       = QVector3D(0,1,0);
        target   = QVector3D(0.0f, 0.0f, 0.0f);


        position = QVector3D(0.0, 0, -15.0);
        rotation = QVector3D(32,-37,0);
        //rotation = QVector3D(-30,143,0);
        //scale    = QVector3D(1,1,-1);

        addWidgets();
    }

    ~QCameraModel()
    {
        delete widget;
    }

    void addWidgets()
    {

        widget = new QWidget;
        widget->setWindowTitle(QString(name));

        farspinBox  = new QDoubleSpinBox;
        nearspinBox = new QDoubleSpinBox;;
        fovSpinBox  = new QDoubleSpinBox;;

        farspinBox->setMinimum(0);
        farspinBox->setMaximum(10000);
        farspinBox->setSingleStep(0.1);

        nearspinBox->setMinimum(0);
        nearspinBox->setMaximum(10000);
        nearspinBox->setSingleStep(0.1);

        fovSpinBox->setMinimum(0);
        fovSpinBox->setMaximum(360);
        fovSpinBox->setSingleStep(0.1);

        farspinBox->setValue(zFar);
        nearspinBox->setValue(zNear);
        fovSpinBox->setValue(fov);


        QVBoxLayout * layout  = new QVBoxLayout;

        QHBoxLayout * hlayout1 = new QHBoxLayout;
        hlayout1->addWidget(new QLabel(QString("Far Clip:")));
        hlayout1->addWidget(farspinBox);
        QFrame * qf1 =  new QFrame;
        qf1->setLayout(hlayout1);

        QHBoxLayout * hlayout2 = new QHBoxLayout;
        hlayout2->addWidget(new QLabel(QString("Near Clip:")));
        hlayout2->addWidget(nearspinBox);
        QFrame * qf2 =  new QFrame;
        qf2->setLayout(hlayout2);

        QHBoxLayout * hlayout3 = new QHBoxLayout;
        hlayout3->addWidget(new QLabel(QString("Field of View:")));
        hlayout3->addWidget(fovSpinBox);
        QFrame * qf3 =  new QFrame;
        qf3->setLayout(hlayout3);

        layout->addWidget(qf1);
        layout->addWidget(qf2);
        layout->addWidget(qf3);
        layout->addWidget(transformWidget);

        widget->setLayout(layout);


        connect(farspinBox,SIGNAL(valueChanged(double)),this,SLOT(setFar()));
        connect(nearspinBox,SIGNAL(valueChanged(double)),this,SLOT(seNear()));

        connect(fovSpinBox,SIGNAL(valueChanged(double)),this,SLOT(setFov()));

        //connect(this,SIGNAL(valueChanged(double)),this,SLOT(updateCone()));

        widget->show();

    }


    void trans__()
    {
        //glTranslatef(0,0,-zoom);

        //glTranslatef(tx,ty,0);

        //glRotatef(rotx,1,0,0);

        //glRotatef(roty,0,1,0);
    }

    void rotate(QPoint delta)
    {
        QVector3D deltaVec = QVector3D((delta.y()*sensitivity),(delta.x()*sensitivity),0);

        rotation += deltaVec;

        qDebug()<<"Rotation:"<< rotation;
    }

    void zoom(qreal delta)
    {
        QVector3D dir = target-position;

        dir.normalize();

        zoomvalue += (delta*0.05);

        dir *= (0.05 * delta);

        target   += dir;
        position += dir;
    }

    void pan(QPoint delta)
    {

        //----------------------------
        //
        //           UP
        //           |
        //           |
        //           |   dir = (target - P0)
        //           P0 -------->  target
        //          /
        //         /
        //        /
        //       Normal
        //
        //
        //----------------------------


        QVector3D dir = target - position;

        dir.normalize();

        QVector3D normal = QVector3D::crossProduct(dir,up);

        QVector3D updelta = up;

        updelta *= ( delta.y() * -0.0005 );
        normal  *= ( delta.x() * -0.0005 );

        QVector3D finalOffset = updelta + normal;


        target   += finalOffset;
        position += finalOffset;


    }

    /*
    void translate(QVector3D deltaPos)
    {
        position += deltaPos;
    }

    */


    void reset()
    {
        up       = QVector3D(0,1,0);

        position = QVector3D(0.0, 0, 15.0);

        target   = QVector3D(0.0f, 0.0f, 0.0f);

        rotation = QVector3D(32,-37,0);
    }


    /*

    void setCameraView(QCameraView view = PERSPECTIVE)
    {
        cameraView =  view;

        switch(cameraView)
        {
        case FRONT://0
            position  = QVector3D(0,0,1);
            target    = QVector3D(0,0,0);
            up        = QVector3D(0,1,0);
            break;

        case BACK://1
            position  = QVector3D(0,0,-1);
            target    = QVector3D(0,0,0);
            up        = QVector3D(0,1,0);
            break;

        case TOP://2
            position = QVector3D(0,1,0);
            target   = QVector3D(0,0,0);
            up       = QVector3D(0,0,-1);
            break;

        case BOTTOM://3
            position    = QVector3D(0,-1,0);
            target = QVector3D(0,0,0);
            up     = QVector3D(0,0,1);
            break;

        case LEFT://4
            position      = QVector3D(-1,0,0);
            target   = QVector3D(0,0,0);
            up       = QVector3D(0,1,0);
            break;

        case RIGHT://5
            position    = QVector3D(1,0,0);
            target = QVector3D(0,0,0);
            up     = QVector3D(0,1,0);
            break;

        case PERSPECTIVE://6
            reset();
            break;
        case ORTHO:
            reset();
            break;

       default:

            break;
        }
    }

    */

    void setViewPort(int w,int h)
    {
        viewport = QSize(w,h);

        viewportSafeTitle = viewport - QSize(100,100);
        viewportSafeFrame = viewport - QSize(50,50);

        aspectRatio = (GLfloat) viewport.width() /(GLfloat) viewport.height() ;

        /*
        glViewport (0, 0, (GLsizei) viewport.width(), (GLsizei) viewport.height());
        glMatrixMode (GL_PROJECTION);
        glLoadIdentity ();

        gluPerspective(fov, aspectRatio, zNear, zFar);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        */

    }


    //-------SELECTION BY COLOR-------------------------------------


    // utility functions to translate colors to and from ints or chars
    QColor charToColor( unsigned char r, unsigned char g, unsigned char b )
    {
        return QColor( r / 255.0f, g / 255.0f, b / 255.0f );
    }

    unsigned int charToInt( unsigned char r, unsigned char g, unsigned char b )
    {
        return b + ( g << 8 ) + ( r << 16 );
    }

    QColor intToColor( unsigned int i )
    {
        unsigned char r = ( i >> 16 ) & 0xFF;
        unsigned char g = ( i >> 8 ) & 0xFF;
        unsigned char b = ( i >> 0 ) & 0xFF;

        return QColor( r / 255.0f, g / 255.0f, b / 255.0f );
    }


    unsigned int colorToInt( const QColor &color )
    {
        unsigned char r = (unsigned char)( color.red() * 255 );
        unsigned char g = (unsigned char)( color.green() * 255 );
        unsigned char b = (unsigned char)( color.blue() * 255 );

        return b + ( g << 8 ) + ( r << 16 );

    }

    //--------------------------------------------


    void loadProjectionMatrix(QMatrix4x4  & projectionMatrix_)
    {
        glMatrixMode(GL_PROJECTION);

        glLoadIdentity();

        //qreal *dataMat = projectionMatrix_.transposed().data();

        float *dataMat = projectionMatrix_.data();

        GLfloat matriceArray[16];

        for (int i= 0; i < 16; ++i)
        {
            matriceArray[i] = dataMat[i];
        }

        glMultMatrixf(matriceArray);
    }

    // Load view matrix (only for immediate mode...)
    void loadViewMatrix( QMatrix4x4 viewMatrix_)
    {
        glMatrixMode(GL_MODELVIEW);

        glLoadIdentity();

        //qreal *dataMat = viewMatrix_.transposed().data();

        float *dataMat = viewMatrix_.data();

        GLfloat matriceArray[16];

        for (int i= 0; i < 16; ++i)
        {
            matriceArray[i] = dataMat[i];
        }

        glMultMatrixf(matriceArray);
    }

    void orbitView()
    {

        // Reset projection
        ProjectionMatrix.setToIdentity();

        double w =  viewport.width();
        double h =  viewport.height();

        // const qreal zNear = 0.1, zFar = 1000.0,fov = 45.0;

        // Calculate aspect ratio
        aspectRatio = qreal(w) / qreal(h ? h : 1);

        if(PerspectiveMode == PERSPECTIVE)
        {
            // Set near plane to 3.0, far plane to 7.0, field of view 45 degrees

            ProjectionMatrix.perspective(fov, aspectRatio, zNear, zFar);

        }
        else if(PerspectiveMode == ORTHO)
        {
            //ProjectionMatrix.perspective(fov, aspectRatio, zNear, zFar);
            ProjectionMatrix.ortho(-0.5f, +0.5f, +0.5f, -0.5f, zNear, zFar);

        }


        viewMatrix.setToIdentity();

        //viewMatrix.lookAt(position,target,up);
        viewMatrix.translate(position.x(),position.y(),position.z());

        viewMatrix.rotate(rotation.x(), 1, 0, 0);
        viewMatrix.rotate(rotation.y(), 0, 1, 0);
        viewMatrix.rotate(rotation.z(), 0, 0, 1);

        //viewMatrix.scale(1,1,1);



        loadProjectionMatrix(ProjectionMatrix);
        loadViewMatrix(viewMatrix);


        //---------------light----------------------

        //QColor m_modelColor(93, 137, 181);
        //const float pos[] = { 0 , 20, 0 };
        //glLightfv(GL_LIGHT0, GL_POSITION, pos);
        //glColor4f(m_modelColor.redF(), m_modelColor.greenF(), m_modelColor.blueF(), 1.0f);
    }

    void  draw()
    {
        /*
        glPushMatrix();
        //printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());
        //glTranslatef(position.x(),position.y(),position.z());

        //glRotatef(rotation.x(),1,0,0);
        //glRotatef(rotation.y(),0,1,0);
        //glRotatef(rotation.z(),0,0,1);

        //glScalef(scale.x(),scale.y(),scale.z());

        //printf("Polygons:%i \n",facesindices.length()/4);

        if(Selected)
        {
            //glColor3f( .5, .25, .79);
            glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
        }
        else
        {
            //glColor3f( .5, .5, .1);
            glColor3f( colorId.x(), colorId.y(), colorId.z());
        }
        drawCamera();

        glPopMatrix();

        drawBoundingBox();

        */
    }

    void initVertices()
    {
        int count = sizeof(Globals::cameraVertices)/sizeof(float);

        count/= 3;

        for(int i=0;i<count;i+=3)
        {
            QVector3D v(Globals::cameraVertices[i],Globals::cameraVertices[i+1],Globals::cameraVertices[i+2]);

            m_points.append(v);
        }

        computeBounds();

    }

    void drawCamera()
    {
        float shininess = 32.0f;
        float diffuseColor[3] = {1.0f, 1.0f, 1.0f};
        float specularColor[4] = {1.0f, 1.0f, 1.0f, 1.0f};

        // set specular and shiniess using glMaterial
        glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess); // range 0 ~ 128
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specularColor);

        // set ambient and diffuse color using glColorMaterial (gold-yellow)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
        glColor3fv(diffuseColor);

        // start to render polygons
        glEnableClientState(GL_NORMAL_ARRAY);
        glEnableClientState(GL_VERTEX_ARRAY);

        glNormalPointer(GL_FLOAT, 0, Globals::cameraNormals);
        glVertexPointer(3, GL_FLOAT, 0, Globals::cameraVertices);

        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[0]);
        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[5]);
        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[10]);
        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[15]);
        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[20]);
        glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_INT, &Globals::cameraIndices[25]);
        glDrawElements(GL_TRIANGLE_STRIP, 39, GL_UNSIGNED_INT, &Globals::cameraIndices[30]);
        glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[69]);
        glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[113]);
        glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[157]);
        glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_INT, &Globals::cameraIndices[201]);

        glDisableClientState(GL_VERTEX_ARRAY);	// disable vertex arrays
        glDisableClientState(GL_NORMAL_ARRAY);	// disable normal arrays
    }


    virtual void switchCameraView(QKeyEvent * event)
    {
        /*
        switch(event->key())
        {
        case Qt::Key_1:
            setCameraView(FRONT);
            break;

        case Qt::Key_2:
            setCameraView(BOTTOM);
            break;

        case Qt::Key_3:
            setCameraView(FRONT);

            break;

        case Qt::Key_4:
           setCameraView(BACK);
            break;

        case Qt::Key_5:
           setCameraView(LEFT);
            break;

        case Qt::Key_6:
            setCameraView(RIGHT);
            break;

        case Qt::Key_7:
            setCameraView(ORTHO);

            break;

        case Qt::Key_8:
            setCameraView(PERSPECTIVE);
            break;

        }

        */

    }

    virtual void cameraNavigation(QMouseEvent *event,QPoint delta)
    {
        viewRay.rayCastScene(event->pos().x(),event->pos().y());

        if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::MiddleButton)
        {
            pan(delta);
        }
        else if (event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::LeftButton)
        {
            rotate(delta);
        }
        else if(event->modifiers()&Qt::AltModifier &&  event->buttons() & Qt::RightButton)
        {

        }
    }

signals:

    void valueChanged(double value);

private slots:

    void updateCone()
    {
       // uv_cone(r1,r2,height,usteps,hsteps);
    }

    void setFar()
    {
        zFar = farspinBox->value();

        emit valueChanged(zFar);
    }

    void seNear()
    {
        zNear = nearspinBox->value();

        emit valueChanged(zNear);
    }

    void setFov()
    {
        fov = fovSpinBox->value();

        emit valueChanged(fov);
    }
};

class QLightModel : public QBaseModel
{
    Q_OBJECT
public:

    enum { Type = MODEL_LIGHT};

    int type() const  { return Type; }


    QLightModel(QObject * parent =0) : QBaseModel(parent)
    {
        m_points.clear();
        //indices.clear();

        name = QString("Light Omni");

        position = QVector3D(10,10,10);

        //position = QVector3D(0,0,10);
        m_points.append(position);
        //boundingSphereRadius = 5;
    }


    ~QLightModel()
    {
        delete widget;
    }

    void draw()
    {
        drawLight();

        glPushMatrix();
        //printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());

        //glTranslatef(position.x(),position.y(),position.z());

        //glRotatef(rotation.x(),1,0,0);
        //glRotatef(rotation.y(),0,1,0);
        //glRotatef(rotation.z(),0,0,1);

        //glScalef(scale.x(),scale.y(),scale.z());
        glPointSize(22);

        glEnable(GL_POINT_SMOOTH);
        glBegin(GL_POINTS);

        if(Selected)
        {
            //glColor3f( .5, .25, .79);
            glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
        }
        else
        {
            //glColor3f( .5, .5, .1);
            glColor3f( colorId.x(), colorId.y(), colorId.z());
        }

        glVertex3f(position.x(),position.y(),position.z());

        //printf("vertices:%f,%f,%f \n",v.x(),v.y(),v.z());


        glEnd();

        glDisable(GL_POINT_SMOOTH);

        glPopMatrix();

        //drawBoundingBox();

        //qDebug()<<"Quad Polygon Model drawn";


    }


    void drawLight()
    {
        float pos[] = {position.x(),position.y(),position.z(),0};
        float spec[4]  = { 0.4f, 0.4f, 0.4f,1 };
        float diffuse[4]  = { .8f, 0.8f, 0.8f ,1};
        float ambient[4]  = { 0.2f, 0.2f, 0.2f,1 };


        glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
        glLightfv(GL_LIGHT0, GL_SPECULAR, spec);
        glLightfv(GL_LIGHT0, GL_POSITION, pos);

        //glEnable(GL_DEPTH_TEST);
        //glShadeModel(GL_SMOOTH);



        GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
        GLfloat mat_shininess[] = { 50.0 };
        GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };
        //glClearColor (0.0, 0.0, 0.0, 0.0);
        glShadeModel (GL_SMOOTH);

        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
        glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
          //glLightfv(GL_LIGHT0, GL_POSITION, light_position);
        //glColorMaterial ( GL_FRONT_AND_BACK, GL_EMISSION ) ;
        glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
        glEnable ( GL_COLOR_MATERIAL ) ;

        //glLightModeliv(GL_LIGHT_MODEL_TWO_SIDE,GL_TRUE);

        GLfloat lmodel_ambient[] = { 0.2, 0.2, 0.2, 1.0 };

        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);


        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_DEPTH_TEST);
    }

};



class QParticlesModel : public QBaseModel
{
         Q_OBJECT
     public:
         enum { Type = MODEL_PARTICLES};

         int type() const  { return Type; }

         //QList<ParticleSystem*> particlessystems;

         //ParticleSystem *ps;

         QParticlesModel(QObject * parent =0) : QBaseModel(parent)
         {
             //ps = new ParticleSystem;

             //m_points.clear();

             name = QString("Particles Model");


         }

         ~QParticlesModel()
         {
             delete widget;
         }




         void draw()
         {
             //drawCube();
             //drawBoundingBox();
             //ps->drawSimulatedParticles();
         }



         void drawCube()
         {
             glPushMatrix();
             //printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());
             glTranslatef(position.x(),position.y(),position.z());
             glRotatef(rotation.x(),1,0,0);
             glRotatef(rotation.y(),0,1,0);
             glRotatef(rotation.z(),0,0,1);

             glScalef(scale.x(),scale.y(),scale.z());

             //printf("Polygons:%i \n",facesindices.length()/4);

             if(Selected)
             {
                 //glColor3f( .5, .25, .79);
                 glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
             }
             else
             {
                 //glColor3f( .5, .5, .1);
                 glColor3f( colorId.x(), colorId.y(), colorId.z());
             }

             drawModel(true,false);

             glPopMatrix();
         }

         void drawModel(bool wireframe, bool normals)
         {

         }
};


#include <fstream>
#include <iostream>
#include <sstream>
#include <cstdlib>



class QMeshModel : public QBaseModel
{
    Q_OBJECT

    //int usteps;
    //int vsteps;
    //float radius;

    //QSlider * uslider;
    //QSlider * vslider;
    //QDoubleSlider * rslider;

    //QSpinBox * uspinBox;
    //QSpinBox * vspinBox;
    //QDoubleSpinBox * rspinBox;

public:

    //QList< QTriangle > triangles;
    enum { Type = MODEL_MESH};

    int type() const  { return Type; }

    //QString fileName() const { return m_fileName; }


    QMeshModel( QObject * parent = 0 ) : QBaseModel(parent)
    {
        color = QColor(120, 200, 200);

        name  = QString("Mesh Model");

        m_points.clear();

        m_normals.clear();

        loadMeshFile();

        computeBounds();

        addWidgets();

        setTheme();


        showWireframe     = true;
        showFacesNormals  = false;
        showPointsNormals = false;
        showSurface       = false;
        showPoints        = false;
        visible           = true;
        Selected          = false;

     }

     ~QMeshModel()
     {
        delete widget;
     }

     void addWidgets()
     {
         //widget = new QWidget;
         //widget->setWindowTitle(QString(name));
         //uslider = new QSlider(Qt::Horizontal);
         //uslider->setValue(usteps);
         //uslider->setMinimum(0);
         //uslider->setMaximum(200);
         //uslider->setSingleStep(1);

         //vslider = new QSlider(Qt::Horizontal);
         //vslider->setValue(vsteps);
         //vslider->setMinimum(0);
         //vslider->setMaximum(200);
         //vslider->setSingleStep(1);

         //rslider = new QDoubleSlider(Qt::Horizontal);
         //rslider->setValue(radiu+s);
         //rslider->setMinimum(0);
         //rslider->setMaximum(200);
         //rslider->setSingleStep(.01);

         //uspinBox = new QSpinBox;
         //vspinBox = new QSpinBox;
         //rspinBox = new QDoubleSpinBox;

         //uspinBox->setMinimum(0);
         //uspinBox->setMaximum(200);
         //uspinBox->setSingleStep(1);

         //vspinBox->setMinimum(0);
         //vspinBox->setMaximum(200);
         //vspinBox->setSingleStep(1);

         //rspinBox->setMinimum(0);
         //rspinBox->setMaximum(200);
         //rspinBox->setSingleStep(.01);

         //rspinBox->setValue(radius);
         //uspinBox->setValue(usteps);
         //vspinBox->setValue(vsteps);


         //QVBoxLayout * layout  = new QVBoxLayout;

         //QHBoxLayout * hlayout1 = new QHBoxLayout;
         //hlayout1->addWidget(new QLabel(QString("Radius:")));
         //hlayout1->addWidget(rslider);
         //hlayout1->addWidget(rspinBox);
         //QFrame * qf1 =  new QFrame;
         //qf1->setLayout(hlayout1);

         //QHBoxLayout * hlayout2 = new QHBoxLayout;
         //hlayout2->addWidget(new QLabel(QString("u steps:")));
         //hlayout2->addWidget(uslider);
         //hlayout2->addWidget(uspinBox);
         //QFrame * qf2 =  new QFrame;
         //qf2->setLayout(hlayout2);

         //QHBoxLayout * hlayout3 = new QHBoxLayout;
         //hlayout3->addWidget(new QLabel(QString("v steps:")));
         //hlayout3->addWidget(vslider);
         //hlayout3->addWidget(vspinBox);
         //QFrame * qf3 =  new QFrame;
         //qf3->setLayout(hlayout3);

         //layout->addWidget(qf1);
         //layout->addWidget(qf2);
         //layout->addWidget(qf3);

         //widget->setLayout(layout);

         //connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
         //connect(vspinBox,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));
         //connect(rspinBox,SIGNAL(valueChanged(double)),this,SLOT(setRadius()));

         //connect(uslider,SIGNAL(valueChanged(int)),uspinBox,SLOT(setValue(int)));
         //connect(vslider,SIGNAL(valueChanged(int)),vspinBox,SLOT(setValue(int)));
         //connect(rslider,SIGNAL(valueChanged(double)),rspinBox,SLOT(setValue(double)));

         //connect(uspinBox,SIGNAL(valueChanged(int)),uslider,SLOT(setValue(int)));
         //connect(vspinBox,SIGNAL(valueChanged(int)),vslider,SLOT(setValue(int)));
         //connect(rspinBox,SIGNAL(valueChanged(double)),rslider,SLOT(setValue(double)));

         //connect(this,SIGNAL(valueChanged()),this,SLOT(updateShere()));

         //widget->show();
     }




     void loadObjFile(QString filePath)
     {
         QFile file(filePath);

         if (!file.open(QIODevice::ReadOnly))
             return;


         QTextStream in(&file);

         while (!in.atEnd())
         {
             QString input = in.readLine();

             if (input.isEmpty() || input[0] == '#')
                 continue;

             QTextStream ts(&input);

             QString id;

             ts >> id;

             if (id == "v")
             {
                 QVector3D p;

                 for (int i = 0; i < 3; ++i)
                 {
                     float v;

                     ts>>v;

                     if(i ==0)
                     {
                         p.setX(v);
                     }
                     else if(i ==1)
                     {
                         p.setY(v);
                     }
                     else if(i ==2)
                     {
                         p.setZ(v);
                     }
                 }

                 m_points.append( p);
             }
             else if(id == "vt")
             {
                 QVector2D uv;

                 for (int i = 0; i < 2; ++i)
                 {
                     float v;

                     ts>>v;

                     if(i==0)
                         uv.setX(v);
                     if(i==1)
                         uv.setY(v);

                 }

                 m_texcoords.append( uv);

             }
             else if (id == "f" || id == "fo")
             {
                 QVarLengthArray<int, 4> p;

                 while (!ts.atEnd())
                 {
                     QString vertex;

                     ts >> vertex;

                     const int vertexIndex = vertex.split('/').value(0).toInt();

                     if (vertexIndex)
                     {
                         p.append(vertexIndex > 0 ? vertexIndex - 1 : m_points.size() + vertexIndex);
                     }
                 }

                 for (int i = 0; i < p.size(); ++i)
                 {
                     const int edgeA = p[i];
                     const int edgeB = p[(i + 1) % p.size()];

                     if (edgeA < edgeB)
                     {
                         m_edgeIndices << edgeA << edgeB;
                     }
                 }

                 for (int i = 0; i < 3; ++i)
                 {
                     m_pointIndices << p[i];
                 }

                 if (p.size() == 4)
                 {
                     for (int i = 0; i < 3; ++i)
                     {
                         m_pointIndices << p[(i + 2) % 4];
                     }
                 }
             }
             else if(id == "vn")
             {
                 QVector3D vn;

                 for (int i = 0; i < 3; ++i)
                 {
                     float v;

                     ts>>v;

                     if(i ==0)
                     {
                         vn.setX(v);
                     }
                     else if(i ==1)
                     {
                         vn.setY(v);
                     }
                     else if(i ==2)
                     {
                         vn.setZ(v);
                     }
                 }


                 m_normals.append(vn);

                 //qDebug()<<vn;

             }
         }
     }

     void loadStlFile(QString filePath)
     {
         //Binary STL
         //Because ASCII STL files can become very large
         //a binary version of STL exists. A binary STL
         //file has an 80-character header
         //(which is generally ignored, but should never begin with
         //"solid" because that will lead most software to assume
         //that this is an ASCII STL file[citation needed]).
         //Following the header is a 4-byte unsigned integer
         //indicating the number of triangular facets in the file.
         //Following that is data describing each triangle in turn.
         //The file simply ends after the last triangle.

         //Each triangle is described by twelve 32-bit floating-point
         //numbers: three for the normal and then
         //         three for the X/Y/Z coordinate of each vertex � just as with the ASCII version of STL.
         //         After these follows a 2-byte ("short")
         //         unsigned integer that is the "attribute byte count" �
         //         in the standard format, this should be zero because
         //         most software does not understand anything else.



         // Load STL file
         //
         // UINT8[80] � Header
         // UINT32 � Number of triangles

         // foreach triangle
         // REAL32[3] � Normal vector
         // REAL32[3] � Vertex 1
         // REAL32[3] � Vertex 2
         // REAL32[3] � Vertex 3
         // UINT16 � Attribute byte count
         // end

         qDebug()<<"STL file reading beginning";

         std::ifstream file(filePath.toStdString().c_str(), std::ios::binary);

         char header[80];
         int nbTrianglesFile;

         file.read(header, 80); //header
         file.read((char*)&nbTrianglesFile, 4); //read number of triangles

         int nbTriangles = nbTrianglesFile;

         qDebug()<<"Number of Triangles"<<nbTriangles;

         //triangles.reserve(nbTriangles);
         //vertices.reserve(nbTriangles/2);

         QList<QVector3D> verts;
         QList<int> trianglez;

         int index1, index2, index3;

         float x, y, z;

         float nx, ny, nz;

         //Vertex v1, v2, v3;

         QVector3D v1, v2, v3;

         for (int i=0;i<nbTriangles;i++)
         {
             //file.read((char*)&x, 12); //normal

             file.read((char*)&nx, 4); //normal
             file.read((char*)&ny, 4);
             file.read((char*)&nz, 4);

             QVector3D normal(nx,ny,nz);

             qDebug()<<"Normal:"<<normal;

             file.read((char*)&x, 4); //vertex 1
             file.read((char*)&y, 4);
             file.read((char*)&z, 4);
             v1 = QVector3D(x,y,z);


             //index1 = detectNewVertex(v1, i, verticesSet,vertices);
             file.read((char*)&x, 4); //vertex 2
             file.read((char*)&y, 4);
             file.read((char*)&z, 4);
             v2 = QVector3D(x,y,z);


             //index2 = detectNewVertex(v2, i, verticesSet,vertices);
             file.read((char*)&x, 4); //vertex 3
             file.read((char*)&y, 4);
             file.read((char*)&z, 4);
             v3 = QVector3D(x,y,z);


             qDebug()<<v1;
             qDebug()<<v2;
             qDebug()<<v3;

             verts.append(v1);
             verts.append(v2);
             verts.append(v3);

             trianglez.append(i);

             //index3 = detectNewVertex(v3, i, verticesSet,vertices);
             file.read((char*)&x, 2); //1 byte attribute

             //QVector3D normal = QVector3D::normal(v1, v2, v3);

             //triangles.push_back(Triangle(QVector3D::normal(v1, v2, v3), index1, index2, index3, i));


             qDebug()<<"Number of Triangles"<<nbTriangles<<"N:"<<(i+1);
         }


         file.close();

         qDebug()<<"STL file reading complete";

     }

     void loadMetroFile(QString filePath)
     {
     }

     void loadMeshFile()
     {
         //QString filePath = QFileDialog::getOpenFileName(0, QString("Choose model"), QString(), QLatin1String("*.obj"));

         QString filePath;
         QStringList stringlist;

         stringlist.append(QString("OBJ File (*.obj)"));

         stringlist.append(QString("STL File (*.stl)"));

         stringlist.append(QString("Metropolis File (*.metro)"));

         QFileDialog dialog;


         //dialog.setFilters(stringlist);

         dialog.show();

         QStringList fileNames;

         if (dialog.exec())
         {
             fileNames = dialog.selectedFiles();

             qDebug()<<fileNames;

             filePath = fileNames[0];
         }

         if(filePath.endsWith(".obj"))
         {
             loadObjFile(filePath);
         }
         else if(filePath.endsWith(".stl"))
         {
             loadStlFile(filePath);
         }
         else if(filePath.endsWith(".metro"))
         {
             loadMetroFile(filePath);
         }
     }


     QColor color;


signals:

     void valueChanged();

 private slots:


     //void updateShere()
     //{
         //uv_sphere(radius,usteps,vsteps);
     //}

     //void setRadius()
     //{
     //    radius = rspinBox->value();
     //    emit valueChanged();
     //}

     //void setUsteps()
     //{
     //    usteps = uspinBox->value();
     //    emit valueChanged();
     //}

     //void setVsteps()
     //{
     //    vsteps = vspinBox->value();
     //    emit valueChanged();
     //}


};

/*

class QMaterial : public QObject
{
    Q_OBJECT

    float diffuse;
    float specular;
    float ambient;
    float bump;
    float reflection;
    float alpha;
    float transparency;
    float emission;


    QSlider * uslider;
    QSlider * vslider;

    QDoubleSlider * rslider;

    QSpinBox * uspinBox;
    QSpinBox * vspinBox;

    QDoubleSpinBox * rspinBox;

public:


     ///---------glsl acceleration-----------

    QColor color;

    QGLBuffer verticesBuffer_; //vertices buffer (openGL)
    QGLBuffer normalsBuffer_; //normals buffer (openGL)
    QGLBuffer indicesBuffer_; //indexes (openGL)

    QGLShaderProgram shaderProgram_; //program shader




    enum ShaderMode
    {
        COLOR_FLAT,
        LAMBERT,
        PHONG,
        COOK_TORRANCE,

        WIREFRAME,
        TRANSPARENCY,
        REFLECTION_1,
        REFLECTION_2,
    };

    ShaderMode shaderType_; //type of shader

    GLuint reflectionTexture_; //texture reflection

    QList<GLuint> textures;

    QMaterial()
    {
        verticesBuffer_ = QGLBuffer(QGLBuffer::VertexBuffer);
        normalsBuffer_  = QGLBuffer(QGLBuffer::VertexBuffer);
        indicesBuffer_  = QGLBuffer(QGLBuffer::IndexBuffer);

        shaderType_ = PHONG;
    }

    void setShader(ShaderMode shader)
    {
        shaderType_ = shader;
        shaderProgram_.removeAllShaders();
        //QString pathShader = QDir::currentPath()+"/Shaders/";
        switch(shaderType_)
        {
        case PHONG :
            shaderProgram_.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/phongVertex.glsl"));// pathShader+"phongVertex.glsl");
            shaderProgram_.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/phongFragment.glsl"));// pathShader+"phongFragment.glsl");
            break;
        case WIREFRAME :
            shaderProgram_.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/wireframeVertex.glsl")); //pathShader+"wireframeVertex.glsl");
            shaderProgram_.addShaderFromSourceFile(QGLShader::Geometry,QString(":/Shaders/wireframeGeometry.glsl")); //pathShader+"wireframeGeometry.glsl");
            shaderProgram_.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/wireframeFragment.glsl"));// pathShader+"wireframeFragment.glsl");
            shaderProgram_.setGeometryInputType(GL_TRIANGLES);
            shaderProgram_.setGeometryOutputType(GL_TRIANGLE_STRIP);
            shaderProgram_.setGeometryOutputVertexCount(3);
            break;
        case TRANSPARENCY :
            shaderProgram_.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/transparencyVertex.glsl"));// pathShader+"transparencyVertex.glsl");
            shaderProgram_.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/transparencyFragment.glsl"));// pathShader+"transparencyFragment.glsl");
            break;
        case REFLECTION_1 :
        case REFLECTION_2 :

            QImage tex;

            bool loaded = false;

            if (shaderType_==REFLECTION_1)
            {
                loaded = tex.load(QString(":/Resources/reflection1.png"));//QDir::currentPath()+"/Ressources/reflection1.png");
            }
            else if (shaderType_==REFLECTION_2)
            {
                loaded = tex.load(QString(":/Resources/reflection2.png"));//QDir::currentPath()+"/Ressources/reflection2.png");
            }

            if(loaded)
            {
                tex = QGLWidget::convertToGLFormat(tex);

                glGenTextures( 1, &reflectionTexture_ );
                glBindTexture( GL_TEXTURE_2D, reflectionTexture_ );
                glTexImage2D(GL_TEXTURE_2D,0,GL_RGB,tex.width(),tex.height(),0,GL_RGBA,GL_UNSIGNED_BYTE,tex.bits());
                glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
                glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
            }

            shaderProgram_.addShaderFromSourceFile(QGLShader::Vertex,QString(":/Shaders/reflectionVertex.glsl"));// pathShader+"reflectionVertex.glsl");
            shaderProgram_.addShaderFromSourceFile(QGLShader::Fragment,QString(":/Shaders/reflectionFragment.glsl"));// pathShader+"reflectionFragment.glsl");

            break;
        }

        shaderProgram_.link();
    }





     //Initialize Vertex Buffer Object (VBO)
     void createVertexBuffers()
     {
         GLfloat* verticesArray  = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLfloat* normalsArray   = (GLfloat*)malloc(vertices_.size()*3*sizeof(GLfloat)*2);
         GLuint* indicesArray    = (GLuint*) malloc(triangles_.size()*3*sizeof(GLuint)*2);


         int nbVertices  = getNbVertices();
         int nbTriangles = getNbTriangles();

     #pragma omp parallel for
         for (int i=0;i<nbVertices;++i)
         {
             Vertex &ver=vertices_[i];

             verticesArray[i*3]=ver.x();
             verticesArray[i*3+1]=ver.y();
             verticesArray[i*3+2]=ver.z();
             const std::vector<int> &iTri=ver.tIndices_;
             int nbTri = iTri.size();
             Vertex normal;
             for (int j=0;j<nbTri;++j)
                 normal+=triangles_[iTri[j]].normal_;
             normal.normalize();
             vertices_[i].normal_=normal;
             normalsArray[i*3]=normal.x();
             normalsArray[i*3+1]=normal.y();
             normalsArray[i*3+2]=normal.z();
         }

     #pragma omp parallel for
         for (int i=0;i<nbTriangles;++i)
         {
             Triangle &tri=triangles_[i];
             indicesArray[i*3]=tri.vIndices_[0];
             indicesArray[i*3+1]=tri.vIndices_[1];
             indicesArray[i*3+2]=tri.vIndices_[2];
         }

         verticesBuffer_.create();
         verticesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         verticesBuffer_.bind();
         verticesBuffer_.allocate(verticesArray, getNbVertices()*3*sizeof(GLfloat)*2);
         verticesBuffer_.release();
         normalsBuffer_.create();
         normalsBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         normalsBuffer_.bind();
         normalsBuffer_.allocate(normalsArray, getNbVertices()*3*sizeof(GLfloat)*2);
         normalsBuffer_.release();
         indicesBuffer_.create();
         indicesBuffer_.setUsagePattern(QGLBuffer::DynamicDraw);
         indicesBuffer_.bind();
         indicesBuffer_.allocate(indicesArray, getNbTriangles()*3*sizeof(GLuint)*2);
         indicesBuffer_.release();

         free(verticesArray);
         free(normalsArray);
         free(indicesArray);

         setShader(shaderType_);
     }

     // Draw buffer shaders
     void drawBufferShader()
     {
         verticesBuffer_.bind();
         shaderProgram_.enableAttributeArray("vertex");
         shaderProgram_.setAttributeBuffer("vertex", GL_FLOAT,  0,  3);
         normalsBuffer_.bind();
         shaderProgram_.enableAttributeArray("normal");
         shaderProgram_.setAttributeBuffer("normal", GL_FLOAT,  0,  3);
         indicesBuffer_.bind();
         glDrawElements(GL_TRIANGLES, getNbTriangles()*3, GL_UNSIGNED_INT, 0);
         indicesBuffer_.release();
         shaderProgram_.disableAttributeArray("normal");
         shaderProgram_.disableAttributeArray("vertex");

         normalsBuffer_.release();
         verticesBuffer_.release();
     }

     // Draw the mesh
     void draw(const QMatrix4x4 & modelViewMatrix,
               const QMatrix4x4 & modelViewProjectionMatrix,
               const QVector3D & centerPicking,
               float radiusSquared)
     {




         switch (shaderType_)
         {
         case PHONG :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             drawBufferShader();
             shaderProgram_.release();
             break;

         case WIREFRAME :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color);
             shaderProgram_.setUniformValue("winScale", camera.getViewport());
             drawBufferShader();
             shaderProgram_.release();
             break;
         case TRANSPARENCY :
             glDepthMask(GL_FALSE);
             glEnable(GL_BLEND);
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("lightPosition", position);
             shaderProgram_.setUniformValue("color", QColor::fromRgb(color.red(),color.green(), color.blue(), 35));
             drawBufferShader();
             shaderProgram_.release();
             glDisable(GL_BLEND);
             glDepthMask(GL_TRUE);
             break;
         case REFLECTION_1 :
         case REFLECTION_2 :
             shaderProgram_.bind();
             shaderProgram_.setUniformValue("modelViewMatrix", modelViewMatrix);
             shaderProgram_.setUniformValue("modelViewProjectionMatrix", modelViewProjectionMatrix);
             shaderProgram_.setUniformValue("normalMatrix", modelViewMatrix.normalMatrix());
             shaderProgram_.setUniformValue("centerPicking", modelViewMatrix*centerPicking);
             shaderProgram_.setUniformValue("radiusSquared", radiusSquared);
             shaderProgram_.setUniformValue("color", color_);
             shaderProgram_.setUniformValue("reflectionTexture", 0);
             glBindTexture(GL_TEXTURE_2D, reflectionTexture_);
             drawBufferShader();
             shaderProgram_.release();
             break;
         }
     }



signals:

     void valueChanged();

private slots:



     void setRadius()
     {
         radius = rspinBox->value();
         emit valueChanged();
     }

     void setUsteps()
     {
         usteps = uspinBox->value();
         emit valueChanged();
     }

     void setVsteps()
     {
         vsteps = vspinBox->value();

         emit valueChanged();
     }

};

*/
/*

class QMeshModel : public QBaseModel
{
    Q_OBJECT


    //int usteps;
    //int vsteps;
    //float radius;

    //QSlider * uslider;
    //QSlider * vslider;
    //QDoubleSlider * rslider;

    //QSpinBox * uspinBox;
    //QSpinBox * vspinBox;
    //QDoubleSpinBox * rspinBox;


public:
   // QList< QTriangle > triangles;

    enum { Type = MODEL_MESH};

    int type() const  { return Type; }

    //QString fileName() const { return m_fileName; }

    void loadObjFile(QString filePath)
    {
        QFile file(filePath);

        if (!file.open(QIODevice::ReadOnly))
            return;


        QTextStream in(&file);

        while (!in.atEnd())
        {
            QString input = in.readLine();

            if (input.isEmpty() || input[0] == '#')
                continue;

            QTextStream ts(&input);

            QString id;

            ts >> id;

            if (id == "v")
            {
                QVector3D p;

                for (int i = 0; i < 3; ++i)
                {
                    float v;

                    ts>>v;

                    if(i ==0)
                    {
                        p.setX(v);
                    }
                    else if(i ==1)
                    {
                        p.setY(v);
                    }
                    else if(i ==2)
                    {
                        p.setZ(v);
                    }
                }

                m_points.append( p);
            }
            else if(id == "vt")
            {
                QVector2D uv;

                for (int i = 0; i < 2; ++i)
                {
                    float v;

                    ts>>v;

                    if(i==0)
                        uv.setX(v);
                    if(i==1)
                        uv.setY(v);

                }

                m_texcoords.append( uv);

            }
            else if (id == "f" || id == "fo")
            {
                QVarLengthArray<int, 4> p;

                while (!ts.atEnd())
                {
                    QString vertex;

                    ts >> vertex;

                    const int vertexIndex = vertex.split('/').value(0).toInt();

                    if (vertexIndex)
                    {
                        p.append(vertexIndex > 0 ? vertexIndex - 1 : m_points.size() + vertexIndex);
                    }
                }

                for (int i = 0; i < p.size(); ++i)
                {
                    const int edgeA = p[i];
                    const int edgeB = p[(i + 1) % p.size()];

                    if (edgeA < edgeB)
                    {
                        m_edgeIndices << edgeA << edgeB;
                    }
                }

                for (int i = 0; i < 3; ++i)
                {
                    m_pointIndices << p[i];
                }

                if (p.size() == 4)
                {
                    for (int i = 0; i < 3; ++i)
                    {
                        m_pointIndices << p[(i + 2) % 4];
                    }
                }
            }
            else if(id == "vn")
            {
                QVector3D vn;

                for (int i = 0; i < 3; ++i)
                {
                    float v;

                    ts>>v;

                    if(i ==0)
                    {
                        vn.setX(v);
                    }
                    else if(i ==1)
                    {
                        vn.setY(v);
                    }
                    else if(i ==2)
                    {
                        vn.setZ(v);
                    }
                }


                m_normals.append(vn);

                qDebug()<<vn;

            }
        }
    }

    void loadStlFile(QString filePath)
    {
        //Binary STL
        //Because ASCII STL files can become very large
        //a binary version of STL exists. A binary STL
        //file has an 80-character header
        //(which is generally ignored, but should never begin with
        //"solid" because that will lead most software to assume
        //that this is an ASCII STL file[citation needed]).
        //Following the header is a 4-byte unsigned integer
        //indicating the number of triangular facets in the file.
        //Following that is data describing each triangle in turn.
        //The file simply ends after the last triangle.

        //Each triangle is described by twelve 32-bit floating-point
        //numbers: three for the normal and then
        //         three for the X/Y/Z coordinate of each vertex � just as with the ASCII version of STL.
        //         After these follows a 2-byte ("short")
        //         unsigned integer that is the "attribute byte count" �
        //         in the standard format, this should be zero because
        //         most software does not understand anything else.



        // Load STL file
        //
        // UINT8[80] � Header
        // UINT32 � Number of triangles

        // foreach triangle
        // REAL32[3] � Normal vector
        // REAL32[3] � Vertex 1
        // REAL32[3] � Vertex 2
        // REAL32[3] � Vertex 3
        // UINT16 � Attribute byte count
        // end

        qDebug()<<"STL file reading beginning";

        std::ifstream file(filePath.toStdString().c_str(), std::ios::binary);

        char header[80];
        int nbTrianglesFile;

        file.read(header, 80); //header
        file.read((char*)&nbTrianglesFile, 4); //read number of triangles

        int nbTriangles = nbTrianglesFile;

        qDebug()<<"Number of Triangles"<<nbTriangles;

        //triangles.reserve(nbTriangles);
        //vertices.reserve(nbTriangles/2);

        QList<QVector3D> verts;
        QList<int> trianglez;

        int index1, index2, index3;

        float x, y, z;

        float nx, ny, nz;

        //Vertex v1, v2, v3;

        QVector3D v1, v2, v3;

        for (int i=0;i<nbTriangles;i++)
        {
            //file.read((char*)&x, 12); //normal

            file.read((char*)&nx, 4); //normal
            file.read((char*)&ny, 4);
            file.read((char*)&nz, 4);

            QVector3D normal(nx,ny,nz);
            qDebug()<<"Normal:"<<normal;

            file.read((char*)&x, 4); //vertex 1
            file.read((char*)&y, 4);
            file.read((char*)&z, 4);
            v1 = QVector3D(x,y,z);


            //index1 = detectNewVertex(v1, i, verticesSet,vertices);
            file.read((char*)&x, 4); //vertex 2
            file.read((char*)&y, 4);
            file.read((char*)&z, 4);
            v2 = QVector3D(x,y,z);


            //index2 = detectNewVertex(v2, i, verticesSet,vertices);
            file.read((char*)&x, 4); //vertex 3
            file.read((char*)&y, 4);
            file.read((char*)&z, 4);
            v3 = QVector3D(x,y,z);


            qDebug()<<v1;
            qDebug()<<v2;
            qDebug()<<v3;

            verts.append(v1);
            verts.append(v2);
            verts.append(v3);

            trianglez.append(i);

            //index3 = detectNewVertex(v3, i, verticesSet,vertices);
            file.read((char*)&x, 2); //1 byte attribute

            //QVector3D normal = QVector3D::normal(v1, v2, v3);

            //triangles.push_back(Triangle(QVector3D::normal(v1, v2, v3), index1, index2, index3, i));


            qDebug()<<"Number of Triangles"<<nbTriangles<<"N:"<<(i+1);
        }


        file.close();

        qDebug()<<"STL file reading complete";

    }


    void loadMeshFile()
    {
        //QString filePath = QFileDialog::getOpenFileName(0, QString("Choose model"), QString(), QLatin1String("*.obj"));

        QString filePath;

        QStringList stringlist;
        stringlist.append(QString("Metropolis File (*.metro)"));
        stringlist.append(QString("STL File (*.stl)"));
        stringlist.append(QString("STL File (*.obj)"));


        QFileDialog dialog;
        dialog.setFilters(stringlist);
        dialog.show();

        QStringList fileNames;

        if (dialog.exec())
        {
            fileNames = dialog.selectedFiles();

            qDebug()<<fileNames;

            filePath = fileNames[0];
        }

        if(filePath.endsWith(".obj"))
        {
            loadObjFile(filePath);
        }
        else if(filePath.endsWith(".stl"))
        {
            loadStlFile(filePath);
        }
        else
        {

        }
    }



    QMeshModel(QObject * parent =0) : QBaseModel(parent)
    {


        color =  QColor(120, 200, 200);

        name = QString("Mesh Model");

        m_points.clear();
        m_normals.clear();

        loadMeshFile();

        computeBounds();

        addWidgets();
     }


    ~QMeshModel()
     {
        delete widget;
     }
    void addWidgets()
     {
             /*
             //widget = new QWidget;
             //widget->setWindowTitle(QString(name));
             //uslider = new QSlider(Qt::Horizontal);
             //uslider->setValue(usteps);
             //uslider->setMinimum(0);
             //uslider->setMaximum(200);
             //uslider->setSingleStep(1);

             //vslider = new QSlider(Qt::Horizontal);
             //vslider->setValue(vsteps);
             //vslider->setMinimum(0);
             //vslider->setMaximum(200);
             //vslider->setSingleStep(1);

             //rslider = new QDoubleSlider(Qt::Horizontal);
             //rslider->setValue(radiu+s);
             //rslider->setMinimum(0);
             //rslider->setMaximum(200);
             //rslider->setSingleStep(.01);

             //uspinBox = new QSpinBox;
             //vspinBox = new QSpinBox;
             //rspinBox = new QDoubleSpinBox;

             //uspinBox->setMinimum(0);
             //uspinBox->setMaximum(200);
             //uspinBox->setSingleStep(1);

             //vspinBox->setMinimum(0);
             //vspinBox->setMaximum(200);
             //vspinBox->setSingleStep(1);

             //rspinBox->setMinimum(0);
             //rspinBox->setMaximum(200);
             //rspinBox->setSingleStep(.01);

             //rspinBox->setValue(radius);
             //uspinBox->setValue(usteps);
             //vspinBox->setValue(vsteps);


             //QVBoxLayout * layout  = new QVBoxLayout;

            // QHBoxLayout * hlayout1 = new QHBoxLayout;
             //hlayout1->addWidget(new QLabel(QString("Radius:")));
             //hlayout1->addWidget(rslider);
             //hlayout1->addWidget(rspinBox);
             //QFrame * qf1 =  new QFrame;
             //qf1->setLayout(hlayout1);

             //QHBoxLayout * hlayout2 = new QHBoxLayout;
             //hlayout2->addWidget(new QLabel(QString("u steps:")));
             //hlayout2->addWidget(uslider);
             //hlayout2->addWidget(uspinBox);
             //QFrame * qf2 =  new QFrame;
             //qf2->setLayout(hlayout2);

             //QHBoxLayout * hlayout3 = new QHBoxLayout;
             //hlayout3->addWidget(new QLabel(QString("v steps:")));
             //hlayout3->addWidget(vslider);
             //hlayout3->addWidget(vspinBox);
             //QFrame * qf3 =  new QFrame;
             //qf3->setLayout(hlayout3);

             //layout->addWidget(qf1);
             //layout->addWidget(qf2);
             //layout->addWidget(qf3);

             //widget->setLayout(layout);

             //connect(uspinBox,SIGNAL(valueChanged(int)),this,SLOT(setUsteps()));
             //connect(vspinBox,SIGNAL(valueChanged(int)),this,SLOT(setVsteps()));
             /connect(rspinBox,SIGNAL(valueChanged(double)),this,SLOT(setRadius()));

             //connect(uslider,SIGNAL(valueChanged(int)),uspinBox,SLOT(setValue(int)));
             //connect(vslider,SIGNAL(valueChanged(int)),vspinBox,SLOT(setValue(int)));
             //connect(rslider,SIGNAL(valueChanged(double)),rspinBox,SLOT(setValue(double)));

             //connect(uspinBox,SIGNAL(valueChanged(int)),uslider,SLOT(setValue(int)));
             //connect(vspinBox,SIGNAL(valueChanged(int)),vslider,SLOT(setValue(int)));
             //connect(rspinBox,SIGNAL(valueChanged(double)),rslider,SLOT(setValue(double)));

             //connect(this,SIGNAL(valueChanged()),this,SLOT(updateShere()));

             //widget->show();


         }


    void draw()
     {
         //setDrawMode(WIREFRAME);

         drawMesh();

         drawBoundingBox();
     }

    void render2(bool wireframe, bool normals) const
     {
         glEnable(GL_DEPTH_TEST);
         glEnableClientState(GL_VERTEX_ARRAY);



         //if (wireframe)
         {
             //glEnable(GL_CULL_FACE);
             //glEnable(GL_COLOR_MATERIAL);
             //glColor3f(.2,.2,.2);
             //glVertexPointer(3, GL_FLOAT, 0, (float *)m_points.constData());
             //glDrawElements(GL_LINES, m_edgeIndices.size(), GL_UNSIGNED_INT, m_edgeIndices.data());
             //glDisable(GL_COLOR_MATERIAL);
         }
         //else

         {
             glEnable(GL_LIGHTING);
             glEnable(GL_LIGHT0);
             glEnable(GL_COLOR_MATERIAL);
             //glColor3f(.2,.2,.2);
             glShadeModel(GL_SMOOTH);
             //glShadeModel(GL_FLAT);

             glEnableClientState(GL_NORMAL_ARRAY);

             glVertexPointer(  3, GL_FLOAT, 0, (float*)m_points.constData()    );

             if(m_texcoords.size()>0)
             {
                 glEnableClientState(GL_TEXTURE_COORD_ARRAY);
                 glTexCoordPointer(2, GL_FLOAT, 0, (float*)m_texcoords.constData() );
             }

             glNormalPointer(GL_FLOAT, 0, (float *)m_normals.constData());
             glDrawElements(GL_TRIANGLES, m_pointIndices.size(), GL_UNSIGNED_INT, m_pointIndices.constData());

             glDisableClientState(GL_NORMAL_ARRAY);
             glDisableClientState(GL_TEXTURE_COORD_ARRAY);

             glDisable(GL_COLOR_MATERIAL);
             glDisable(GL_LIGHT0);
             glDisable(GL_LIGHTING);
         }

         if (normals)
         {
             //QVector<QVector3D> normals;

             //for (int i = 0; i < m_normals.size(); ++i)
             //{
              //   normals << m_points.at(i) << (m_points.at(i) + m_normals.at(i) * 0.02f);
             //}

             //glVertexPointer(3, GL_FLOAT, 0, (float *)normals.constData());

             //glDrawArrays(GL_LINES, 0, normals.size());

             glVertexPointer(3, GL_FLOAT, 0, (float *)m_normals.constData());

             glDrawArrays(GL_LINES, 0, m_normals.size());
         }

         glDisableClientState(GL_VERTEX_ARRAY);

         glDisable(GL_DEPTH_TEST);


     }


    void drawMesh()
     {
         glPushMatrix();
         //printf("position:%f,%f,%f \n",position.x(),position.y(),position.z());
         glTranslatef(position.x(),position.y(),position.z());

         glRotatef(rotation.x(),1,0,0);
         glRotatef(rotation.y(),0,1,0);
         glRotatef(rotation.z(),0,0,1);

         glScalef(scale.x(),scale.y(),scale.z());

         //printf("Polygons:%i \n",facesindices.length()/4);

         if(Selected)
         {
             //glColor3f( .5, .25, .79);
             glColor3f(selectedColor.x(),selectedColor.y(),selectedColor.z());
         }
         else
         {
             //glColor3f( .5, .5, .1);
             glColor3f( colorId.x(), colorId.y(), colorId.z());
         }

         //obj->Render();

         render2(true,false);

         glPopMatrix();
     }



    ///---------glsl acceleration-----------


    QMaterial material;



 signals:

     void valueChanged();

 private slots:


     //void updateShere()
     //{
         //uv_sphere(radius,usteps,vsteps);
     //}

     //void setRadius()
     //{
     //    radius = rspinBox->value();
     //    emit valueChanged();
     //}

     //void setUsteps()
     //{
     //    usteps = uspinBox->value();
     //    emit valueChanged();
     //}

     //void setVsteps()
     //{
     //    vsteps = vspinBox->value();
     //    emit valueChanged();
     //}


};

     */




#endif // MODELS


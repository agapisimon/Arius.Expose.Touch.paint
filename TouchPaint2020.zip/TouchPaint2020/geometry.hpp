#ifndef GEOMETRY_HPP
#define GEOMETRY_HPP

#include<QtWidgets>
#include<QtOpenGL>
#include<GL/glu.h>
#include<globals.hpp>



enum QTrans
{
    X = 0,
    Y,
    Z,

    XY,
    ZX,
    YZ,

    XYZ_NONE,
    UNIFORM,
    SCREEN,
    TRACKBALL,

};

enum QTransformMode
{
    MOVE,
    SCALE,
    ROTATION,
    NONE =0,
};

enum QPlaneIntersection
{
    NOINTERSCETION,
    INTERSECTS,
    PARALLEL,
};




class QBoundSphere
{
public:
    QVector3D center;

    float radius;

    bool RaySphereCollision(QVector3D A, QVector3D B)
    {

        QVector3D sphereCenter = center;
        float sphereRadius = radius;

        QVector3D dirtosphere = sphereCenter - A;
        QVector3D lineDir = B-A;
        lineDir = lineDir.normalized();

        QVector3D d =  B - A;

        float distance = d.length();//length of segement
        float t = QVector3D::dotProduct(dirtosphere,lineDir);//dirtosphere to project to lineDir

        QVector3D closestPoint;

        if(t<=0)
            closestPoint = A;
        else if(t>= distance)
            closestPoint = B;
        else
            closestPoint = A + lineDir * t;//calculate the point along the line using t


        QVector3D clp = sphereCenter - closestPoint;

        //now to check the closestPoint is in sphereradius
        return clp.length()<= sphereRadius;
    }

    bool RaySphereCollision(QVector3D sphereCenter,float sphereRadius,QVector3D A, QVector3D B)
    {
        QVector3D dirtosphere = sphereCenter - A;
        QVector3D lineDir = B-A;
        lineDir = lineDir.normalized();

        QVector3D d =  B - A;

        float distance = d.length();//length of segement
        float t = QVector3D::dotProduct(dirtosphere,lineDir);//dirtosphere to project to lineDir

        QVector3D closestPoint;

        if(t<=0)
            closestPoint = A;
        else if(t>= distance)
            closestPoint = B;
        else
            closestPoint = A + lineDir * t;//calculate the point along the line using t


        QVector3D clp = sphereCenter - closestPoint;

        //now to check the closestPoint is in sphereradius
        return clp.length()<= sphereRadius;
    }

    QBoundSphere()
    {
        radius = 1;
    }

    QBoundSphere(float _radius, QVector3D _center)
    {
        if (radius <= 0 )
        {
            radius = 0;
        }

        radius = _radius;
        center = _center;
    }

    void setBoundSphere(float _radius, QVector3D _center)
    {

        if (radius <= 0 )
        {
            radius = 0;
        }

        radius = _radius;
        center = _center;
    }

    void centerAtAverage(QList<QVector3D> points)
    {
        if (points.isEmpty())
        {
            return;
        }

        center = QVector3D(points.at(0));

        foreach (QVector3D point , points)
        {
            center+=point;
        }

        center/= points.size();

        foreach (QVector3D point , points)
        {
            QVector3D distanceToAnotherPoint =point-center;

            float greaterRadius = distanceToAnotherPoint.lengthSquared();

            if (greaterRadius > radius)
            {
                radius = greaterRadius;
            }
        }
        radius = (float) sqrt(radius);
        //localTransform.reset();
    }


    QBoundSphere * copy()
    {
        return new QBoundSphere(radius, center);
    }
};

class QAabb
{
    QList<QVector3D> corners;
public :

    enum intersect
    {
        INSIDE,
        INTERSECT,
        OUTSIDE
    };
    QVector3D min;
    QVector3D max;


    QVector3D center;

    float radius;

    // Constructor
    QAabb(const QVector3D &min, const QVector3D &max) : min(min), max(max)
    {
        corners.reserve(8);
    }
    QAabb()
    {
        corners.reserve(8);
    }

    // Destructor
    ~QAabb()
    {

    }
    QAabb getMaxBounds()
    {

        QVector3D mmax = QVector3D( 1e30, 1e30, 1e30 );
        QVector3D mmin = QVector3D( -1e30,  -1e30,  -1e30 );
        return QAabb(mmax,mmin);
    }


    QBoundSphere getBoundSphere()
    {
        QBoundSphere s;

        s.center =  getCenter();
        s.radius =  getRadius();

        radius =  s.radius;

        return s;
    }

    QVector3D getCenter()
    {
        center = (max+min)/2;
        return center;
    }

    QVector3D getMax()
    {
        return max;
    }

    QVector3D getMin()
    {
        return min;
    }

    float getDiagonalLength()
    {
        QVector3D l = max-min;

        return l.length();
    }



    float getRadius()
    {
        center = (max+min)/2;

        QVector3D r =  max-center;

        return r.length();
    }

    //Computes the volume of the bounding box.

    float volume() const
    {
        QVector3D size = max - min;

        return size.x()*size.y()*size.z();
    }



    //Translates the bounding box.

    void translate(const QVector3D & delta)
    {
        min += delta;
        max += delta;
    }

    void rotate(const QVector3D & rotation)
    {
        QMatrix4x4 m;

        m.setToIdentity();

        m.rotate(rotation.x(),1,0,0);
        m.rotate(rotation.y(),0,1,0);
        m.rotate(rotation.z(),0,0,1);

        min  =  m * min;
        max  =  m * max;
    }



    //Scales the bounding box about the optional point.

    void scaleAboutAPoint(const QVector3D &size, const QVector3D &point = QVector3D(0.0, 0.0, 0.0))
    {
        QVector3D center = (max - min)/2.0 + point;

        max = (max - center)*size;
        min = (min - center)*size;
    }

    void reScale(float offset =0.2)
    {
        QVector3D diagonal = (max - min);
        diagonal.normalize();

        max = max - diagonal*offset;
        min = min + diagonal*offset;

        center = (max - min)/2.0;

    }

    //Test if the given point is inside this bounding box.

     bool inside(const QVector3D &point)
     {
         return point.x() >= min.x() && point.x() <= max.x() &&
                     point.y() >= min.y()  && point.y()  <= max.y()  &&
                     point.z() >= min.z() && point.z() <= max.z();
     }


    //Test if the given bounding box is inside this bounding box.

     bool inside(const QAabb &other)
     {
         return inside(other.min) && inside(other.max);
     }


    //Test if the given bounding box is outside this bounding box.

     bool outside(const QAabb &other)
     {
         return !inside(other.min) && !inside(other.max);
     }

     //Collision detection
     bool isOutside(const QAabb &aabb)
     {
         if( aabb.min.x() > max.x() || aabb.max.x() < min.x() )
             return true;
         if( aabb.min.y() > max.y() || aabb.max.y() < min.y() )
             return true;
         if( aabb.min.z() > max.z() || aabb.max.z() < min.z() )
             return true;
         return false;
     }

     // Return true if aabb is inside the box
     bool isInside(const QAabb &aabb)
     {
         if( min.x() >= aabb.min.x() && max.x() <= aabb.max.x() &&
                 min.y() >= aabb.min.y() && max.y() <= aabb.max.y() &&
                 min.z() >= aabb.min.z() && max.z() <= aabb.max.z() )
             return true;
         return false;
     }


     //Test if the given bounding box intersects this bounding box.

     bool intersects(const QAabb &other)
     {
         return inside(other.min) != inside(other.max);
     }


      //Test the given bounding box with this bounding box.

     intersect test(const QAabb &other)
     {
         bool point1(inside(other.min)), point2(inside(other.max));

         return point1?(point2?INSIDE:INTERSECT):(point2?INTERSECT:OUTSIDE);

     }


     void split(QAabb &left, QAabb &right)
     {
         float sizex = max.x() - min.x();
         float sizey = max.y() - min.y();
         float sizez = max.z() - min.z();

         if (sizex < sizey)
         {
             if (sizey > sizez)
             {
                 left.min = min;

                 left.max =  QVector3D( max.x(),min.y() + sizey/2.0,max.z());

                 right.max =  QVector3D(min.x(),min.y() + sizey/2.0,min.z());

                 right.max = max;
             }
             else
             {
                 left.min = min;

                 left.max= QVector3D(max.x(), max.y(),min.z() + sizez/2.0);

                 right.min= QVector3D(min.x(), min.y(),min.z() + sizez/2.0);

                 right.max = max;
             }
         }
         else
         {
             if (sizex > sizez)
             {
                 left.min = min;

                 left.max= QVector3D(min.x()+ sizex/2.0, max.y(),max.z());

                 right.min= QVector3D(min.x()+ sizex/2.0, min.y(),min.z());

                 right.max = max;
             }
             else
             {
                 left.min = min;

                 left.max= QVector3D(min.x(), max.y(),min.z()+ sizex/2.0);

                 right.min= QVector3D(min.x(), min.y(),min.z()+ sizez/2.0);

                 right.max = max;
             }
         }
     }


     // Return true if vert is inside the aabb
     bool pointInside(const QVector3D &vertex)
    {
        if(vertex.x()<=min.x())
            return false;
        if(vertex.x()>max.x())
            return false;
        if(vertex.y()<=min.y())
            return false;
        if(vertex.y()>max.y())
            return false;
        if(vertex.z()<=min.z())
            return false;
        if(vertex.z()>max.z())
            return false;
        return true;
    }



    void setQAabbFromPoints(const QList<QVector3D> & points)
    {
        min = QVector3D(0,0,0);
        max = QVector3D(0,0,0);

        for(int i=0;i<points.size();i++)
        {
            QVector3D v =  points[i];

            expand(v);
        }
    }

    static QAabb getQAabbFromPointList(const QList<QVector3D> & points)
    {
        QAabb b;
        b.min = QVector3D(0,0,0);
        b.max = QVector3D(0,0,0);

        for(int i=0;i<points.size();i++)
        {
            QVector3D v =  points[i];

            b.expand(v);
        }

        return b;
    }

    QList<QVector3D> getAllCorners()
    {

        corners[0] = min;

        corners[1] = QVector3D(min.x(),min.y(),max.z());

        corners[2] = QVector3D(min.x(),max.y(),min.z());

        corners[3] = QVector3D(max.x(),min.y(),min.z());

        corners[4] = QVector3D(max.x(),min.y(),max.z());

        corners[5] = QVector3D(max.x(),max.y(),min.z());

        corners[6] = QVector3D(min.x(),max.y(),max.z());

        corners[7] = max;

        return corners;
    }


    // Change the size of the aabb to include another aabb
    void expand(const QAabb &aabb)
    {
        if (aabb.max.x()>max.x())
            max.setX(aabb.max.x());
        if (aabb.min.x()<min.x())
            min.setX(aabb.min.x());
        if (aabb.max.y()>max.y())
            max.setY(aabb.max.y());
        if (aabb.min.y()<min.y())
            min.setY(aabb.min.y());
        if (aabb.max.z()>max.z())
            max.setZ(aabb.max.z());
        if (aabb.min.z()<min.z())
            min.setZ(aabb.min.z());
    }
    // Change the size of the aabb to include vert
    void expand(const QVector3D &vert)
    {
        if (vert.x()>max.x())
            max.setX(vert.x());
        if (vert.x()<min.x())
            min.setX(vert.x());
        if (vert.y()>max.y())
            max.setY(vert.y());
        if (vert.y()<min.y())
            min.setY(vert.y());
        if (vert.z()>max.z())
            max.setZ(vert.z());
        if (vert.z()<min.z())
            min.setZ(vert.z());
    }

    //Generate a bounding box that contains this one and the given
    //one.

    QAabb merge(QAabb b)
    {
        QAabb res;

        if (min.x() < b.min.x())
        {
            res.min.setX(min.x());
        }
        else
        {
            res.min.setX(b.min.x());
        }


        if (max.x() > b.max.x())
        {
            res.max.setX( max.x());
        }
        else
        {
            res.max.setX( b.max.x());
        }

        if (min.y() < b.min.y())
        {
            res.min.setY( min.y());
        }
        else
        {
            res.min.setY(b.min.y());
        }



        if (max.y() > b.max.y())
        {
            res.max.setY( max.y());
        }
        else
        {
            res.max.setY( b.max.y());
        }


        if (min.z() < b.min.z())
        {
            res.min.setZ(min.z());
        }
        else
        {
            res.min.setZ( b.min.z());
        }

        if (max.z() > b.max.z())
        {
            res.max.setZ(max.z());
        } else {
            res.max.setZ(b.max.z());
        }

        return res;
    }


     //Generate a bounding box that contains this one and the point
     //given by the vector v.

    QAabb merge(QVector3D v)
    {
        QAabb res;

        if (min.x() < v.x())
        {
            res.min.setX( min.x());
        }
        else
        {
            res.min.setX(v.x());
        }


        if (max.x() > v.x())
        {
            res.max.setX( max.x());
        }
        else
        {
            res.max.setX(v.x());
        }

        if (min.y() < v.y())
        {
            res.min.setY(min.y());
        }
        else
        {
            res.min.setY(v.y());
        }

        if (max.y() > v.y())
        {
            res.max.setY(max.y());
        }
        else
        {
            res.max.setY(v.y());
        }


        if (min.z() < v.z())
        {
            res.min.setZ( min.z());
        }
        else
        {
            res.min.setZ( v.z());
        }


        if (max.z() > v.z())
        {
            res.max.setZ(max.z());
        }
        else
        {
            res.max.setZ(v.z());
        }

        return res;
    }

    // Return true if a ray intersection the box
    bool intersectRay( QVector3D origin,  QVector3D dir)
    {
        float t1 = (min.x() - origin.x())/dir.x();
        float t2 = (max.x() - origin.x())/dir.x();
        float t3 = (min.y() - origin.y())/dir.y();
        float t4 = (max.y() - origin.y())/dir.y();
        float t5 = (min.z() - origin.z())/dir.z();
        float t6 = (max.z() - origin.z())/dir.z();

        float tmin = std::max(std::max(std::min(t1, t2), std::min(t3, t4)), std::min(t5, t6));
        float tmax = std::min(std::min(std::max(t1, t2), std::max(t3, t4)), std::max(t5, t6));

        bool _intersect = (tmax >=0 && tmin<tmax);

        if(_intersect)
        {
            qDebug()<<"Intersected QAabox:"<<_intersect;
        }
        else
        {
            qDebug()<<"Intersected QAabox:"<<_intersect;
        }

        return _intersect;


    }

    // Return true if a sphere intersect with the box
    bool intersectSphere( QVector3D vert, float radiusSquared)
    {
        QVector3D nearest;

        if (min.x() > vert.x())
            nearest.setX(min.x());
        else if (max.x() < vert.x())
            nearest.setX(max.x());
        else
            nearest.setX(vert.x());
        if (min.y() > vert.y())
            nearest.setY(min.y());
        else if (max.y() < vert.y())
            nearest.setY(max.y());
        else
            nearest.setY(vert.y());
        if (min.z() > vert.z())
            nearest.setZ(min.z());
        else if (max.z() < vert.z())
            nearest.setZ(max.z());
        else
            nearest.setZ(vert.z());

        return (vert-nearest).lengthSquared()<radiusSquared;
    }

    // Check if the aabb is a plane
    void checkFlat(float offset)
    {
        if(min.x()==max.x())
        {
            min.setX(min.x()-offset);
            max.setX(max.x()+offset);
        }
        if(min.y()==max.y())
        {
            min.setY(min.y()-offset);
            max.setY(max.y()+offset);
        }
        if(min.z()==max.z())
        {
            min.setZ(min.z()-offset);
            max.setZ(max.z()+offset);
        }
    }

    // Compute the distance from point p to axis-aligned bounding box
    float getDistanceToQAabbCenter(QVector3D p )
    {
        QVector3D l = p - center;

        return l.length();
    }

    void Min(QVector3D & a, const QVector3D & b, const QVector3D & c )
    {

        float x = (b.x() < c.x()) ? b.x() : c.x();
        float y = (b.y() < c.y()) ? b.y() : c.y();
        float z = (b.z() < c.z()) ? b.z() : c.z();

        a = QVector3D(x,y,z);
    }

    void Max(QVector3D &a, const QVector3D &b, const QVector3D &c )
    {
        float x = (b.x() > c.x()) ? b.x() : c.x();
        float y = (b.y() > c.y()) ? b.y() : c.y();
        float z = (b.z() > c.z()) ? b.z() : c.z();

        a = QVector3D(x,y,z);
    }

    // Compute the distance from point p to axis-aligned bounding box
    float getDistancePointToBoundingBox(QVector3D p )
    {
        QVector3D c, s; // bbox center and half-side lengths
        QVector3D d; // separation vector
        float dist2;

        // Compute bbox center c
        float x = 0.5f * (max.x() + min.x());
        float y = 0.5f * (max.y() + min.y());
        float z = 0.5f * (max.z() + min.z());


        c =  QVector3D(x,y,z);

        // Compute bbox half-side lengths s
        x = 0.5f * (max.x() - min.x());
        y = 0.5f * (max.y() - min.y());
        z = 0.5f * (max.z() - min.z());

        s = QVector3D(x,y,z);

        // Initial separation vector: d = vector bbox center c to point p
        d = p -c; // d = p - c


        // Update separation vector
        if (d.x() <= -s.x())
        {
            d += QVector3D(s.x(),0,0);
            //d.x() += s.x();   // outside min bound
        }
        else if (d.x() >= s.x())
        {
             d -= QVector3D(s.x(),0,0);
            //d.x() -= s.x();   // outside max bound
        }
        else
        {

            d.setX( 0.0f);   // inside bounds
        }

        if (d.y() <= -s.y())
        {
            //d.y += s.y;   // outside min bound
            d += QVector3D(0,s.y(),0);
        }
        else if (d.y() >= s.y())
        {
             d -= QVector3D(0,s.y(),0);

           // d.y -= s.y;   // outside max bound
        }
        else
        {
            d.setY(0.0f);   // inside bounds
        }

        if (d.z() <= -s.z())
        {
            d += QVector3D(0,0,s.z());
            //d.z += s.z;   // outside min bound
        }
        else if (d.z() >= s.z())
        {
            //d.z -= s.z;   // outside max bound
            d -= QVector3D(0,0,s.z());
        }
        else
        {
            d.setZ(0.0f);   // inside bounds
        }

        dist2 = QVector3D::dotProduct(d,d);// d.x*d.x + d.y*d.y + d.z*d.z; // dot product d . d

        return dist2;
    }

    // Compute the distance from point p to axis-aligned bounding box
    float getDistancePointToBoundingBox(QVector3D p , QAabb  * bbox)
    {
        QVector3D c, s; // bbox center and half-side lengths
        QVector3D d; // separation vector

        // Compute bbox center c
        float x = 0.5f * (bbox->max.x() + bbox->min.x());
        float  y = 0.5f * (bbox->max.y() + bbox->min.y());
        float z = 0.5f * (bbox->max.z() + bbox->min.z());

        c+= QVector3D(x,y,z);

        // Compute bbox half-side lengths s
        x = 0.5f * (bbox->max.x() - bbox->min.x());
        y = 0.5f * (bbox->max.y() - bbox->min.y());
        z = 0.5f * (bbox->max.z() - bbox->min.z());

        s += QVector3D(x,y,z);

        // Initial separation vector: d = vector bbox center c to point p
        d = p -c; // d = p - c


        // Update separation vector
        if (d.x() <= -s.x())
        {
            //d.x += s.x;   // outside min bound
            d += QVector3D(s.x(),0,0);
        }
        else if (d.x() >= s.x())
        {
            //d.x -= s.x;   // outside max bound
            d -= QVector3D(s.x(),0,0);

        }
        else
        {
            d.setX(0.0f);   // inside bounds
        }

        if (d.y() <= -s.y())
        {
            //d.y += s.y;   // outside min bound
            d += QVector3D(0,s.y(),0);
        }
        else if (d.y() >= s.y())
        {
            //d.y -= s.y;   // outside max bound
            d -= QVector3D(0,s.y(),0);
        }
        else
        {
            d.setY(0.0f);   // inside bounds
        }

        if (d.z() <= -s.z())
        {
            //d.z += s.z;   // outside min bound
            d += QVector3D(0,0,s.z());
        }
        else if (d.z() >= s.z())
        {
           // d.z -= s.z;   // outside max bound
            d -= QVector3D(0,0,s.z());
        }
        else
        {
            d.setZ(0.0f);   // inside bounds
        }

        float distance = QVector3D::dotProduct(d,d);// d.x*d.x + d.y*d.y + d.z*d.z; // dot product d . d

        return distance;
    }


    void print(const char *s="") const
    {
          printf ("BOUNDING BOX %s: %f %f %f  -> %f %f %f\n", s,  min.x(),min.y(),min.z(), max.x(),max.y(),max.z());
    }

    // Draw the aabb
    void draw( QColor color= QColor(Qt::cyan))
    {
        glLineWidth(1);
        glDisable(GL_LIGHTING);
        glBegin(GL_LINES);

        glColor3f(color.redF(), color.greenF(), color.blueF());
        glVertex3f(min.x(), min.y(), min.z());glVertex3f(max.x(), min.y(), min.z());
        glVertex3f(max.x(), min.y(), min.z());glVertex3f(max.x(), max.y(), min.z());
        glVertex3f(max.x(), max.y(), min.z());glVertex3f(min.x(), max.y(), min.z());
        glVertex3f(min.x(), max.y(), min.z());glVertex3f(min.x(), min.y(), min.z());
        glVertex3f(min.x(), min.y(), min.z());glVertex3f(min.x(), min.y(), max.z());
        glVertex3f(min.x(), min.y(), max.z());glVertex3f(max.x(), min.y(), max.z());
        glVertex3f(max.x(), min.y(), max.z());glVertex3f(max.x(), min.y(), min.z());
        glVertex3f(max.x(), min.y(), max.z());glVertex3f(max.x(), max.y(), max.z());
        glVertex3f(max.x(), max.y(), max.z());glVertex3f(max.x(), max.y(), min.z());
        glVertex3f(max.x(), max.y(), max.z());glVertex3f(min.x(), max.y(), max.z());
        glVertex3f(min.x(), max.y(), max.z());glVertex3f(min.x(), max.y(), min.z());
        glVertex3f(min.x(), max.y(), max.z());glVertex3f(min.x(), min.y(), max.z());
        glEnd();

        glEnable(GL_LIGHTING);
    }


};

class QGeometry
{
public:

    QMatrix4x4 createMatrixFromRowMajor(float * data)
    {
        QMatrix4x4 m;

        for(int i=0;i<16;i+=4)
        {
            QVector4D v(data[i],data[i+1],data[i+2],data[i+3]);

            int index = i/4;

            m.setRow(index,v);
        }

        return m;

    }

    QMatrix4x4 createMatrixFromColumnMajor(float * data)
    {
        QMatrix4x4 m;

        for(int i=0;i<16;i+=4)
        {
            QVector4D v(data[i],data[i+1],data[i+2],data[i+3]);

            int index = i/4;

            m.setColumn(index,v);
        }

        return m;

    }



    //GetPixelColorAnd3DPosition() returns the current 3d position and
    // color of the 2D pixel at (x,y)

    // using the current viewport, projection and modelview data that defines our (camera's)
    // view into the 3D world. It is only used to pick objects in 3D space.

    static QColor  getPixelColorAnd3DPosition(QVector3D point,int x, int y)
    {
        static GLint    viewport[4];
        static GLdouble modelview[16];
        static GLdouble projection[16];

        GLfloat winX, winY, winZ;
        GLdouble posX, posY, posZ;

        glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
        glGetDoublev(GL_PROJECTION_MATRIX, projection);
        glGetIntegerv(GL_VIEWPORT, viewport);

        GLubyte pixel[3];

        winX = (float)x;
        winY = (float)viewport[3] - (float)y;

        glReadBuffer( GL_BACK );

        //read color and depth
        glReadPixels(x, int(winY),1,1,GL_RGB,GL_UNSIGNED_BYTE,(void *)pixel);
        glReadPixels( x, int(winY), 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &winZ );

        gluUnProject( winX, winY, winZ, modelview, projection,viewport, &posX, &posY, &posZ);

        point  = QVector3D((float)posX,(float)posY,(float)posZ);

        QColor color(pixel[0],pixel[1],pixel[2]);

        return color;
    }


    //Compute intersection vertex between a ray and a triangle. Returne false if it doesn't intersect.
    static bool intersectionRayTriangle(const QVector3D &s1, const QVector3D &s2,
                                 const QVector3D &v1, const QVector3D &v2,
                                 const QVector3D &v3, const QVector3D &normal,
                                 QVector3D &vertInter)
    {
        float dist1 = QVector3D::dotProduct(s1-v1, normal);
        float dist2 = QVector3D::dotProduct(s2-v1, normal);

        if ((dist1*dist2)>= 0.0f)
            return false;

        if (dist1==dist2)        //ray parallel to triangle plane
            return false;
        //intersection between ray and triangle
        vertInter = s1+(s2-s1)*(-dist1/(dist2-dist1));

        if (QVector3D::dotProduct(QVector3D::crossProduct(normal, v2-v1), vertInter-v1)<0.0f)
            return false;

        if (QVector3D::dotProduct(QVector3D::crossProduct(normal, v3-v2), vertInter-v2)<0.0f)
            return false;

        if (QVector3D::dotProduct(QVector3D::crossProduct(normal, v1-v3), vertInter-v1)<0.0f)
            return false;

        return true;
    }

    // Intersection point between a ray and a plane
    static QVector3D intersectionRayPlane(const QVector3D &start,const QVector3D &end, const QVector3D &position, const QVector3D &normal)
    {
        float dist1 = QVector3D::dotProduct(start-position, normal);
        float dist2 = QVector3D::dotProduct(end-position, normal);

        if ((dist1*dist2)>= 0.0f)
            return QVector3D();

        if (dist1==dist2)        //ray parallel to triangle plane
            return QVector3D();
        //intersection between ray and triangle
        return start+(end-start)*(-dist1/(dist2-dist1));
    }

    // Projection of mouse coordinate on sphere unit
    static QVector3D mouseOnUnitSphere(const QPointF &mouseXY)
    {
        float tempZ = 1-mouseXY.x()*mouseXY.x()-mouseXY.y()*mouseXY.y();

        float mouseZ= tempZ>0 ? sqrtf(tempZ) : 0;

        QVector3D sourisSphere(mouseXY.x(), mouseXY.y(), mouseZ);

        return sourisSphere.normalized();
    }

    //Normalize coordinate mouse between 0 and 1

    static QPointF normalizedMouse(const QPointF &mouseXY, const QSizeF viewport)
    {
        return QPointF(2.0*mouseXY.x()/viewport.width()-1.0,1.0-(2.0*mouseXY.y()/viewport.height()));
    }

    // Compute the ray normal to screen (through mouse)
    static  void getRayNormalToScreen(const QPointF &mouseXY, const QSizeF &viewport, QVector3D &vertexNear, QVector3D &vertexFar)
    {
        double model[16];
        double projection[16];
        int view[4];
        double dX, dY, dZ;
        glGetIntegerv(GL_VIEWPORT, view);
        glGetDoublev (GL_MODELVIEW_MATRIX, model);
        glGetDoublev (GL_PROJECTION_MATRIX, projection);
        gluUnProject (mouseXY.x(), viewport.height()-mouseXY.y(),0.0, model, projection, view, &dX, &dY, &dZ);

        vertexNear =  QVector3D((float)dX,(float)dY,(float)dZ);
        //vertexNear.setX((float)dX);
        //vertexNear.setY((float)dY);
        //vertexNear.setZ((float)dZ);
        gluUnProject (mouseXY.x(), viewport.height()-mouseXY.y(),1.0, model, projection, view, &dX, &dY, &dZ);
        //vertexFar.setX((float)dX);
        //vertexFar.setY((float)dY);
        //vertexFar.setZ((float)dZ);
        vertexFar =  QVector3D((float)dX,(float)dY,(float)dZ);
    }

    static QVector3D getRayNormalAtScreenPos(const QPointF &mouseXY, const QSizeF &viewport, QVector3D &vertexNear, QVector3D &vertexFar)
    {
        double model[16];
        double projection[16];
        int view[4];
        double dX, dY, dZ;

        glGetIntegerv(GL_VIEWPORT, view);
        glGetDoublev (GL_MODELVIEW_MATRIX, model);
        glGetDoublev (GL_PROJECTION_MATRIX, projection);

        gluUnProject (mouseXY.x(), viewport.height()-mouseXY.y(),0.0, model, projection, view, &dX, &dY, &dZ);

        vertexNear =  QVector3D((float)dX,(float)dY,(float)dZ);

        gluUnProject (mouseXY.x(), viewport.height()-mouseXY.y(),1.0, model, projection, view, &dX, &dY, &dZ);

        vertexFar =  QVector3D((float)dX,(float)dY,(float)dZ);

        QVector3D ray = vertexFar - vertexNear;

        return ray.normalized();
    }

    // Compute the unit vector coplanar to screen
    static QVector3D getCoplanarVectorOnScreen(const QPointF &mouseXYOld, const QPointF &mouseXYNew, const QSizeF &viewport)
    {
        double model[16];
        double projection[16];
        int view[4];
        double dX1, dX2, dY1, dY2, dZ1, dZ2;

        glGetIntegerv(GL_VIEWPORT, view);
        glGetDoublev (GL_MODELVIEW_MATRIX, model);
        glGetDoublev (GL_PROJECTION_MATRIX, projection);

        gluUnProject (mouseXYOld.x(), viewport.height()-mouseXYOld.y(), 0.0, model, projection, view, &dX1, &dY1, &dZ1);
        gluUnProject (mouseXYNew.x(), viewport.height()-mouseXYNew.y(), 0.0, model, projection, view, &dX2, &dY2, &dZ2);

        return QVector3D(dX2 - dX1, dY2 - dY1, dZ2 -dZ1).normalized();
    }

    //Compute the projection of a vertex on a line
    static QVector3D vertexOnLine(const QVector3D &vertex, const QVector3D &vertexNear, const QVector3D &vertexFar)
    {
        QVector3D ab = vertexFar - vertexNear;
        float abSquared = ab.lengthSquared();
        float dot = QVector3D::dotProduct(ab, (vertex - vertexNear));
        float t = dot / abSquared;
        return (vertexNear + ab*t);
    }

    //Project the mouse coordinate into the world coordinate at a given z
    static QVector3D point2Dto3D(const QPointF &mouseXY, const QSizeF &viewport, float z)
    {
        double model[16];
        double projection[16];
        int view[4];
        double dX, dY, dZ;
        glGetIntegerv(GL_VIEWPORT, view);
        glGetDoublev (GL_MODELVIEW_MATRIX, model);
        glGetDoublev (GL_PROJECTION_MATRIX, projection);

        gluUnProject (mouseXY.x(), viewport.height()-mouseXY.y(), z, model, projection, view, &dX, &dY, &dZ);

        return QVector3D(dX, dY, dZ);
    }

    // Project a vertex onto the screen
    static QPointF point3Dto2D(const QVector3D &vertex, const QSizeF &viewport, double &z)
    {
        double model[16];
        double projection[16];
        int view[4];
        double dX, dY;

        glGetIntegerv(GL_VIEWPORT, view);
        glGetDoublev (GL_MODELVIEW_MATRIX, model);
        glGetDoublev (GL_PROJECTION_MATRIX, projection);

        gluProject(vertex.x(), vertex.y(), vertex.z(), model, projection, view, &dX, &dY, &z);

        return QPointF(dX, viewport.height()-dY);
    }

    // Return any perpendicular vector to another vector
    static QVector3D getPerpendicularVector(const QVector3D &vector)
    {
        QVector3D result;

        if (vector.x() == 0.0f || vector.y() == 0.0f || vector.z() == 0.0f)
        {
            if (vector.x() == 0.0f)
                result.setX(1.0f);
            else if (vector.y() == 0.0f)
                result.setY(1.0f);
            else
                result.setZ(1.0f);
        }
        else
        {
            result.setX(vector.z());
            result.setY(vector.z());
            result.setZ(-(vector.x()+vector.y()));
            result.normalize();
        }
        return result;
    }

    //Compute the bounding box of a triangle defined by three vertices
    static QAabb computeTriangleAabb(const QVector3D &v1, const QVector3D &v2, const QVector3D &v3)
    {
        float minX = std::min(std::min(v1.x(),v2.x()),v3.x());
        float minY = std::min(std::min(v1.y(),v2.y()),v3.y());
        float minZ = std::min(std::min(v1.z(),v2.z()),v3.z());

        float maxX = std::max(std::max(v1.x(),v2.x()),v3.x());
        float maxY = std::max(std::max(v1.y(),v2.y()),v3.y());
        float maxZ = std::max(std::max(v1.z(),v2.z()),v3.z());

        return QAabb(QVector3D(minX, minY, minZ), QVector3D(maxX, maxY, maxZ));
    }

    // Compute the inradius (radius of incircle) of a triangle
    static float computeInradiusSquared(const QVector3D &v1, const QVector3D &v2, const QVector3D &v3)
    {
        float a = (v1-v2).length();
        float b = (v1-v3).length();
        float c = (v2-v3).length();

        float halfPerimeter = (a+b+c)*0.5f;

        return (1/halfPerimeter)*(halfPerimeter-a)*(halfPerimeter-b)*(halfPerimeter-c);
    }

    // If point is inside the triangle, test the sum of the areas
    static bool pointInsideTriangle(const QVector3D &point, const QVector3D &v1, const QVector3D &v2, const QVector3D &v3)
    {
        QVector3D vec1  = v1-v2;
        QVector3D vec2  = v1-v3;

        QVector3D vecP1 = point-v2;
        QVector3D vecP2 = point-v3;

        float total = QVector3D::crossProduct(vec1, vec2).length();
        float area1 = QVector3D::crossProduct(vec1, vecP1).length();
        float area2 = QVector3D::crossProduct(vec2, vecP2).length();
        float area3 = QVector3D::crossProduct(vecP1, vecP2).length();

        if(fabs(total-(area1+area2+area3))<0.0001f) //magic epsilon...
            return true;
        else
            return false;
    }

    // Minimum distance to a segment
    static float distanceToSegment(const QVector3D &point, const QVector3D &v1, const QVector3D &v2)
    {
        float length = (v2-v1).lengthSquared();

        float t = QVector3D::dotProduct(point-v1,v2-v1)/length;

        if(t < 0.0) return (point-v1).lengthSquared();

        if(t> 1.0) return (point-v2).lengthSquared();

        QVector3D ptProj = v1 + t*(v2-v1);

        return (point-ptProj).lengthSquared();
    }

    //If a sphere intersect a triangle
    static bool sphereIntersectTriangle(const QVector3D &point, float radiusSq,
                                           const QVector3D &v1, const QVector3D &v2, const QVector3D &v3)
    {
        if(distanceToSegment(point,v1,v2)<radiusSq)
            return true;

        if(distanceToSegment(point,v2,v3)<radiusSq)
            return true;

        if(distanceToSegment(point,v1,v3)<radiusSq)
            return true;

        return false;
    }
    static float getRadiansFromDegrees(float degrees)
    {
        return degrees *M_PI / 180.0;
    }

    static QMatrix4x4 getPerspectiveProjectionMatrix(float fov,float aspect,float _near,float _far)
    {
        QMatrix4x4 m;
        m.setToIdentity();

        float f= aspect/tan(fov*0.5);

        float n= 1.0f/(_near-_far);

        QVector4D r1(f/aspect, 0.0, 0.0, 0.0);
        QVector4D r2(0.0, f  , 0.0	, 0.0);
        QVector4D r3(0.0, 0.0, (_far+_near)*n, -1.0);
        QVector4D r4(0.0, 0.0, 2.0*_far*_near*n, 0.0);

        m.setRow(0,r1);
        m.setRow(1,r2);
        m.setRow(2,r3);
        m.setRow(3,r4);



        return m;
    }

    static QMatrix4x4 getMatrixFromTranslation(QVector3D v)
    {
        QMatrix4x4 m;

        QVector4D r1(1.0, 0.0, 0.0, 0.0);
        QVector4D r2(0.0, 1.0, 0.0, 0.0);
        QVector4D r3(0.0, 0.0, 1.0, 0.0);
        QVector4D r4(v.x()	, v.y()  , v.z()  , 1.0);

        m.setRow(0,r1);
        m.setRow(1,r2);
        m.setRow(2,r3);
        m.setRow(3,r4);

        return m;
    }

    static QMatrix4x4 getMatrixFromScale(QVector3D v)
    {
        QMatrix4x4 m;

        QVector4D r1(v.x(), 0.0, 0.0, 0.0);
        QVector4D r2(0.0, v.y(), 0.0, 0.0);
        QVector4D r3(0.0, 0.0, v.z(), 0.0);
        QVector4D r4(0.0, 0.0 , 0  , 1.0);

        m.setRow(0,r1);
        m.setRow(1,r2);
        m.setRow(2,r3);
        m.setRow(3,r4);

        return m;
    }

    static QMatrix4x4 getMatrixFromRotationX(float angle)
    {
        //left hand rule
        float cosR= cos(angle);
        float sinR= sin(angle);

        QMatrix4x4 m;

        QVector4D r1(1.0, 0.0, 0.0, 0.0);
        QVector4D r2(0.0, cosR, sinR, 0.0);
        QVector4D r3(0.0, -sinR, cosR, 0.0);
        QVector4D r4(0.0, 0.0, 0.0, 1.0);

        m.setRow(0,r1);
        m.setRow(1,r2);
        m.setRow(2,r3);
        m.setRow(3,r4);

        return m;
    }

    static QMatrix4x4 getMatrixFromRotationY(float angle)
    {
        //left hand rule
        float cosR= cos(angle);
        float sinR= sin(angle);

        QMatrix4x4 m;

        QVector4D r1(cosR , 0.0, -sinR	, 0.0);
        QVector4D r2(0.0, 1.0  , 0.0, 0.0);
        QVector4D r3(sinR, 0.0, cosR, 0.0);
        QVector4D r4(0.0, 0.0, 0.0 , 1.0);

        m.setRow(0,r1);
        m.setRow(1,r2);
        m.setRow(2,r3);
        m.setRow(3,r4);

        return m;
    }

    static QMatrix4x4 getMatrixFromRotationZ(float angle)
    {
        //left hand rule
        float cosR= cos(angle);
        float sinR= sin(angle);

        QMatrix4x4 m;

        QVector4D r1(cosR  ,sinR, 0.0, 0.0);
        QVector4D r2(-sinR ,cosR, 0.0, 0.0);
        QVector4D r3(0.0, 0.0, 1.0, 0.0);
        QVector4D r4(0.0, 0.0, 0.0 , 1.0);

        m.setRow(0,r1);
        m.setRow(1,r2);
        m.setRow(2,r3);
        m.setRow(3,r4);

        return m;
    }

    static QMatrix4x4 getMatrixFromRotation(QVector3D v)
    {
        QMatrix4x4 m;

        QMatrix4x4 rX = getMatrixFromRotationX(v.x());
        QMatrix4x4 rY = getMatrixFromRotationX(v.y());
        QMatrix4x4 rZ = getMatrixFromRotationX(v.z());

        m =  rX * rY * rZ;

        return m;
    }

    static QVector3D getScaleFromMatrix( QMatrix4x4 m)
    {
        QVector4D r1 = m.row(0);
        QVector4D r2 = m.row(1);
        QVector4D r3 = m.row(2);

        QVector3D v(r1.x(),r2.y(),r3.z());

        return v;
    }

    static QVector3D getTranslationFromMatrix( QMatrix4x4 m)
    {
        QVector4D r = m.row(3);

        QVector3D v(r.x(),r.y(),r.z());

        return v;
    }

    static QMatrix4x4 getOrthoProjectionMatrix( float left, float right,float bottom,float top,float _near,float _far)
    {
        QMatrix4x4 matrix;

        QVector4D r1;
        r1.setX(2.0f / (right - left));
            //matrix[0] = 2 / (right - left);
            //matrix[1] = 0;
            //matrix[2] = 0;
            //matrix[3] = 0;

            QVector4D r2;
            r2.setY(2.0f / (top - bottom));

            //matrix[4] = 0;
            //matrix[5] = 2 / (top - bottom);
            //matrix[6] = 0;
            //matrix[7] = 0;

            QVector4D r3;
            r3.setZ(-2.0f / (_far - _near));

            //matrix[8] = 0;
            //matrix[9] = 0;
            //matrix[10] = -2 / (far - near);
            //matrix[11] = 0;


            QVector4D r4;
            r4.setX(-(right + left) / (right - left));
            r4.setY(-(top + bottom) / (top - bottom));
            r4.setZ(-(_far + _near) / (_far - _near));
            r4.setW(1.0f);

            //matrix[12] = -(right + left) / (right - left);
            //matrix[13] = -(top + bottom) / (top - bottom);
            //matrix[14] = -(far + near) / (far - near);
            //matrix[15] = 1;

            matrix.setRow(0,r1);
            matrix.setRow(1,r2);
            matrix.setRow(2,r3);
            matrix.setRow(3,r4);

            return matrix;
    }

    static QVector3D getRandomPointInSphere()
    {
        float lambda = Globals::frandom(1000);

        float u = Globals::frandom(1000) * 2.0 - 1.0;

        float phi = Globals::frandom(1000) * 2.0 * M_PI;

        float radius  = sqrt(1.0 - u * u);

        float v = pow(lambda, 1/3);

        float x  = v * radius * cos(phi);
        float y =  v * radius * sin(phi);
        float z =  v * u;

        QVector3D p(x,y,z);

        return p;

    }

    static inline bool isPointInTriangle( const QVector3D& vector1, const QVector3D& vector2, const QVector3D& vector3, const QVector3D& position )
    {
        float alpha;
        float beta;
        float gamma;

        float area = 0.5f *  QVector3D::crossProduct( vector2 - vector1, vector3 - vector1 ).length() ;

        alpha = 0.5f *  QVector3D::crossProduct( vector2 - position, vector3 - position ).length() / area;

        beta  = 0.5f * QVector3D::crossProduct( vector1 - position, vector3 - position ).length() / area;

        gamma = 0.5f * QVector3D::crossProduct( vector1 - position, vector2 - position ).length() / area;

        //if (abs( 1.0f - alpha - beta - gamma ) > std::numeric_limits<float>::epsilon()) return false;
        if (fabs( 1.0f - alpha - beta - gamma ) > 0.00001f)
            return false;

        return true;
    }
};



/*
class QBaseModel;

class QHitInfo
{
public:

    bool Selected;

    QBaseModel * selectedModel;
    int modelID;

    QHitInfo()
    {
        modelID = 0;
        Selected = false;
    }


};

*/

//Plane defined by a point and a normal
//The normal and point are expressed in non-opengl 3D cartesian co-ordinates.
//where the Z axis in vertical. In OpenGL the Y axis is vertical.
class QPlane
{
public:

    QVector3D normal;
    QVector3D center;

    //int axesAlignment;

    QTrans axesAlignment;

    QList<QVector3D> vertices;


    double d;

    QPlane()
    {
        center  = QVector3D(0,0,0);
        normal  = QVector3D(0,1,0);
        axesAlignment = ZX;
    }

    QPlane(QVector3D norm,QVector3D pos, QTrans axes)
    {
        normal = QVector3D(norm.x(),norm.y(),norm.z());
        pos = QVector3D(pos.x(),pos.y(),pos.z());
        axesAlignment = axes;
    }

    QPlane(QVector3D a, QVector3D b, QVector3D c)
    {
        vertices.append(a);
        vertices.append(b);
        vertices.append(c);

        center =  (a+b+c);

        center /= 3;

        normal =  QVector3D::crossProduct((b -a),(c-a));

        normal.normalize();

        this->d = QVector3D::dotProduct(center,normal);
    }

    QPlane(QVector3D a, QVector3D b, QVector3D c,QVector3D d)
    {
        vertices.append(a);
        vertices.append(b);
        vertices.append(c);
        vertices.append(d);

        center =  (a+b+c+d);

        center /= 4;

        normal =  QVector3D::crossProduct((b -a),(c-a));

        normal.normalize();

        this->d = QVector3D::dotProduct(center,normal);
    }

    QPair<bool,QVector3D> intersects(QVector3D p0, QVector3D p1)
    {
        QPair<bool,QVector3D> _interset;

        QVector3D p = p1- p0;


        if (QVector3D::dotProduct(p,normal) == 0)
        {
            _interset = QPair<bool,QVector3D>(false,QVector3D(0,0,0));

            return _interset;
        }

        double t = (d - QVector3D::dotProduct(p0,normal)) / QVector3D::dotProduct(p,normal);

        /* p0 + t * (p1-p0) */

        QVector3D intersect = p0 + t*p;


        _interset = QPair<bool,QVector3D>(true,intersect);

        return _interset;

    }


    double distance(QVector3D position)
    {
       return QVector3D::dotProduct(normal,(center-position));
    }



    //Returns the line where two planes intersect. The line where two planes
    //intersect is given by the cross product of the normals of both planes.
    //The equation of the line is given in the form of a Vec3 object.

    QVector3D getIntersectionLineDirection(QPlane  plane)
    {
        QVector3D dir = QVector3D::crossProduct(normal,plane.normal);

        return dir.normalized();
    }




    void drawNormal()
    {
        //glDisable(GL_LIGHTING);
        //glEnable(GL_LINE_SMOOTH);
        //glDisable( GL_TEXTURE_2D );
        glLineWidth(2.0);
        glBegin(GL_LINES);
        glColor3f(1.0f,1.0f,0.0f);
        glVertex3f(center.x(),center.z(),center.y());
        glVertex3f(normal.x()*4+center.x(),normal.z()*4+center.z(),normal.y()*5+center.y());
        glEnd();
        //glEnable(GL_LIGHTING);
        //glDisable(GL_LINE_SMOOTH);
        //glEnable( GL_TEXTURE_2D );
    }

    virtual void drawPlane(float scale = 0.1f)
    {

        //glDisable(GL_LIGHTING);
        //glEnable(GL_LINE_SMOOTH);
        //glDisable( GL_TEXTURE_2D );
        //glEnable(GL_COLOR_MATERIAL);
        glLineWidth(1.0);
        //glColor3f(1.0f,0.0f,0.0f);

        float size = 1.0f;
        // xy plane default
        float x = center.x();
        float y = center.z();
        float z = center.y();

        glPushMatrix();

        glScalef(scale,scale,scale);

        if(axesAlignment == XY)
        {
            x = center.x();
            y = center.z();
            z = center.y();

        }
        else if(axesAlignment == ZX)
        {
            glRotatef(90.0f,1.0f,0.0f,0.0f);
            x = center.x();
            y = center.y();
            z = -center.z();

        }
        else if(axesAlignment == YZ)
        {
            glRotatef(-90.0f,0.0f,0.0f,1.0f);
            x = -center.z();
            y = center.x();
            z = center.y();

        }

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(1.0f,0.0f,1.0f,0.2f);
        glBegin(GL_QUADS);
            glVertex3f(x-size,y,z-size);
            glVertex3f(x-size,y,z+size);
            glVertex3f(x+size,y,z+size);
            glVertex3f(x+size,y,z-size);
        glEnd();
        glDisable(GL_BLEND);

        glColor3f(1.0f,0.0f,0.0f);
        glBegin(GL_LINES);
            glVertex3f(x-size,y,z-size);
            glVertex3f(x-size,y,z+size);
            glVertex3f(x+size,y,z-size);
            glVertex3f(x+size,y,z+size);
            glVertex3f(x-size,y,z-size);
            glVertex3f(x+size,y,z-size);
            glVertex3f(x-size,y,z+size);
            glVertex3f(x+size,y,z+size);
        glEnd();
        glPopMatrix();



        //glEnable(GL_LIGHTING);
        //glDisable(GL_LINE_SMOOTH);
        //glEnable( GL_TEXTURE_2D );

    }


    int getAxesAlignment()
    {
       return axesAlignment;
    }


    void setAxesAlignment(QTrans value)//int value)
    {
       axesAlignment = value;
    }
};

class QTriangle
{
public:
    QVector3D center;
    QVector3D normal;
    QList<int>indices;

    QVector3D a, b,c;

    QPlane plane;

    QBoundSphere boundingSphere;

    QAabb bounds;

    QTriangle(QVector3D a, QVector3D b, QVector3D c)
    {
        this->a = a;
        this->b = b;
        this->c = c;

        center = a + b+ c;

        center/=3;

        normal =  QVector3D::crossProduct(b-a,c-a);

        normal.normalize();
    }

    QPlane getPlane()
    {
        plane =  QPlane(a, b, c);

        return plane;
    }

    //Checks for intersection between two triangles.
    //The other triangle to check intersection with.
    //return true if triangles intersect, false otherwise.

    bool intersects(QTriangle target)
    {
        // Simple verification
        //if (!getBoundingBox().intersects(target.getBoundingBox()))
        //{
        //    return false;
        //}

        QVector3D a1 = this->a;
        QVector3D b1 = this->b;
        QVector3D c1 = this->c;

        QVector3D a2 = target.a;
        QVector3D b2 = target.b;
        QVector3D c2 = target.c;

        // Planes where triangles live
        QPlane p1 = getPlane();
        QPlane p2 = target.getPlane();

        // Distances from Plane1 to Points of Triangle2
        double dp1_a2 = p1.distance(a2);
        double dp1_b2 = p1.distance(b2);
        double dp1_c2 = p1.distance(c2);

        // Distances from Plane2 to Points of Triangle1
        double dp2_a1 = p2.distance(a1);
        double dp2_b1 = p2.distance(b1);
        double dp2_c1 = p2.distance(c1);

        // Check for co-planar triangles
        if (dp1_a2 == 0 && dp1_b2 == 0 && dp1_c2 == 0) {
            // TODO: check for co-planar intersections...
            return false;
        }

        // Check for same sign... (+=true, -=false)
        bool sign_a1 = dp2_a1 > 0;
        bool sign_b1 = dp2_b1 > 0;
        bool sign_c1 = dp2_c1 > 0;

        bool sign_a2 = dp1_a2 > 0;
        bool sign_b2 = dp1_b2 > 0;
        bool sign_c2 = dp1_c2 > 0;

        if (sign_a1 == sign_b1 && sign_a1 == sign_c1 || sign_a2 == sign_b2
                && sign_a2 == sign_c2)
        {
            // Triangle is on one side of plane. Intersection does not occur.
            return false;
        }

        // Select v1_0 and v1_2 on the same side of plane, and v1_1 on the other
        // side.
        QVector3D v1_0, v1_1, v1_2;

        double dv1_0, dv1_1, dv1_2;
        if (sign_a1 != sign_b1 && sign_b1 == sign_c1)
        {
            v1_1 = a1; // Odd one
            dv1_1 = dp2_a1;
            v1_0 = b1;
            v1_2 = c1; // Same side
            dv1_0 = dp2_b1;
            dv1_2 = dp2_c1;
        }
        else if (sign_b1 != sign_a1 && sign_a1 == sign_c1)
        {
            v1_1 = b1; // Odd one
            dv1_1 = dp2_b1;
            v1_0 = a1;
            v1_2 = c1; // Same side
            dv1_0 = dp2_a1;
            dv1_2 = dp2_c1;
        }
        else if (sign_c1 != sign_a1 && sign_a1 == sign_b1)
        {
            v1_1 = c1; // Odd one
            dv1_1 = dp2_c1;
            v1_0 = a1;
            v1_2 = b1; // Same side
            dv1_0 = dp2_a1;
            dv1_2 = dp2_b1;
        }
        else
        {
            return false;
        }

        // Select v2_0 and v2_2 on the same side of plane, and v2_1 on the other
        // side.
        QVector3D v2_0, v2_1, v2_2;

        double dv2_0, dv2_1, dv2_2;

        if (sign_a2 != sign_b2 && sign_b2 == sign_c2)
        {
            v2_1 = a2; // Odd one
            dv2_1 = dp1_a2;
            v2_0 = b2;
            v2_2 = c2; // Same side
            dv2_0 = dp1_b2;
            dv2_2 = dp1_c2;
        }
        else if (sign_b2 != sign_a2 && sign_a2 == sign_c2)
        {
            v2_1 = b2; // Odd one
            dv2_1 = dp1_b2;
            v2_0 = a2;
            v2_2 = c2; // Same side
            dv2_0 = dp1_a2;
            dv2_2 = dp1_c2;
        }
        else if (sign_c2 != sign_a2 && sign_a2 == sign_b2)
        {
            v2_1 = c2; // Odd one
            dv2_1 = dp1_c2;
            v2_0 = a2;
            v2_2 = b2; // Same side
            dv2_0 = dp1_a2;
            dv2_2 = dp1_b2;
        }
        else
        {
             return false;//("Signs undefined!");
        }

        // Figure out line L where planes intersect
        // Cross product of the planes
        QVector3D d = p1.getIntersectionLineDirection(p2);

        // Line of intersection
        // L = O + t * D
        QVector3D o = p2.intersects(v1_0, v1_1).second; // Some point on L

        // Project points onto line - plane 1 */
        // pv1_i = D . (V1_i - o)
        double pv1_0 = QVector3D::dotProduct( d,(v1_0-o));
        double pv1_1 = QVector3D::dotProduct(d,(v1_1-o));
        double pv1_2 = QVector3D::dotProduct(d,(v1_2-o));

        // Project points onto line - plane 2 */
        // pv1_i = D . (V1_i - o)
        double pv2_0 = QVector3D::dotProduct(d,(v2_0-o));
        double pv2_1 = QVector3D::dotProduct(d,(v2_1-o));
        double pv2_2 =QVector3D::dotProduct( d,(v2_2-o));

        // Intervals of T
        double t1_01 = pv1_0 + (pv1_1 - pv1_0) * dv1_0 / (dv1_0 - dv1_1);
        double t1_12 = pv1_1 + (pv1_2 - pv1_1) * dv1_1 / (dv1_1 - dv1_2);
        double t2_01 = pv2_0 + (pv2_1 - pv2_0) * dv2_0 / (dv2_0 - dv2_1);
        double t2_12 = pv2_1 + (pv2_2 - pv2_1) * dv2_1 / (dv2_1 - dv2_2);

        double min_1 = qMin(t1_01, t1_12);
        double max_1 = qMax(t1_01, t1_12);
        double min_2 = qMin(t2_01, t2_12);
        double max_2 = qMax(t2_01, t2_12);

        return !(max_1 < min_2) && !(max_2 < min_1);

    }



    //Returns the minimum <code>BoundingBox</code> which contains this
    //<code>Triangle</code> and is aligned with the coordinate axis
    // return The <code>BoundingBox</code> arround this <code>Triangle</code>.

     QAabb getBoundingBox()
     {
         double x1 = qMin(qMin(a.x(), b.x()), c.x());
         double y1 = qMin(qMin(a.y(), b.y()), c.y());
         double z1 = qMin(qMin(a.z(), b.z()), c.z());

         double x2 = qMax(qMax(a.x(), b.x()), c.x());
         double y2 = qMax(qMax(a.y(), b.y()), c.y());
         double z2 = qMax(qMax(a.z(), b.z()), c.z());

         bounds = QAabb(QVector3D(x1,y1,z1),QVector3D(x2,y2,z2));

         return bounds;
     }

     //Test if 3D point is inside 3D Triangle.
     //param p the 3D point to check
     //return true if the point is inside the triangle, false otherwise

      bool intersect(QVector3D p)
      {
          long sign12, sign23, sign31;

          QVector3D vect12, vect23, vect31, vect1h, vect2h, vect3h;

          QVector3D cross12_1p, cross23_2p, cross31_3p;

          //First, a quick bounding-box test:
          //If P is outside triangle bbox, there cannot be an intersection.

          QAabb bbox = getBoundingBox();

          if (!bbox.inside(p))
          {
                 return false;
          }


          //For each triangle side, make a vector out of it by subtracting
          //vertexes;

          //make another vector from one vertex to point P. */
          //The crossproduct of these two vectors is orthogonal to both and the */
          //signs of its X,Y,Z components indicate whether P was to the inside or */
          //to the outside of this triangle side. */

          vect12 = a-b;
          vect1h = a-p;

          cross12_1p = QVector3D::crossProduct(vect12,vect1h);

          vect23 = b-c;
          vect2h = b-p;

          cross23_2p = QVector3D::crossProduct(vect23,vect2h);

          vect31 = c-a;
          vect3h = c-p;
          cross31_3p = QVector3D::crossProduct(vect31,vect3h);

          // Extract X,Y,Z signs 0...63 integer
          sign12 = sign3(cross12_1p);
          sign23 = sign3(cross23_2p);
          sign31 = sign3(cross31_3p);

          // If all three crossproduct vectors agree in their component signs,
          // then the point must be inside all three.
          // P cannot be OUTSIDE all three sides simultaneously.
          return (sign12 & sign23 & sign31) != 0;

      }

      //Express the sign as a 8 bit number.

      long sign3(QVector3D a)
      {
          return (a.x() < 0 ? 4 : 0) | (a.x() > -0 ? 32 : 0) | (a.y() < 0 ? 2 : 0)
                      | (a.y() > -0 ? 16 : 0) | (a.z() < 0 ? 1 : 0) | (a.z() > -0 ? 8 : 0);
      }

      //Returns the requested vertex identified by vertex number. First vertex
      //has index 0. An <code>ArrayIndexOutOfBoundsException</code> is thrown
      //if the requested vertex index is greater than 2.
      //
      //param index
      //the index of the requested vertex.
      //return the requested vertex.

      QVector3D getVertex(int index)
      {
          switch (index)
          {
              case 0:
                  return a;
              case 1:
                  return b;
              case 2:
                  return c;
          }
      }



};

class QDisk
{
public:

    QList<QVector3D > vertices;

    QList< QPair<int,int> > edges;

    QVector3D normal;
    QVector3D pos;

    QTrans axesAlignment;
    float radius;

    QDisk(int Count = 42,float radius = 1.5,QTrans axesAlignment=XY)
    {
        switch(axesAlignment)
        {
        case XY:
            normal  = QVector3D(0,0,1);
            break;
        case ZX:
            normal  = QVector3D(0,1,0);

            break;
        case YZ:
            normal  = QVector3D(1,0,0);
            break;
        }

        this->radius  = radius;
        pos     = QVector3D(0,0,0);

        this->axesAlignment = axesAlignment;

        for(int i =0;i< Count;i++)
        {
            float angle = 2 * M_PI* (float)i/Count;


            if(axesAlignment = XY)
            {
                float x = radius*sin(angle);
                float y = radius*cos(angle);
                float z =0;

                  QVector3D p = QVector3D(x,y,z);

                  vertices.append(p);
            }
            else if(axesAlignment = YZ)
            {
                   float x = 0;
                   float y = radius*cos(angle);
                   float z = radius*sin(angle);

                   QVector3D p = QVector3D(x,y,z);

                   vertices.append(p);
            }
            else if(axesAlignment = ZX)
            {
                   float x = radius*cos(angle);
                   float y = 0;
                   float z = radius*sin(angle);

                   QVector3D p = QVector3D(x,y,z);
                   vertices.append(p);
            }
            else if(axesAlignment = SCREEN)
            {
                   //QRay ray;
                   //ray.rayCastScene();

            }
        }
        for(int i=0;i<vertices.size()-1;i++)
        {

            QPair<int,int> edge(i,i+1);

            edges.append(edge);
        }

        QPair<int,int> edge(vertices.size(),0);

        edges.append(edge);
        //printf("vertices Count: %i",vertices.size());


    }

    void drawNormal()
    {
        glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);
        glLineWidth(2.0);
        glBegin(GL_LINES);
        glColor3f(1.0f,1.0f,0.0f);
        glVertex3f(pos.x(),pos.z(),pos.y());
        glVertex3f(normal.x()*radius+pos.x(),normal.z()*radius+pos.z(),normal.y()*radius+pos.y());
        glEnd();
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }

    void drawDisk(bool fill = false,QTrans _axesAlignment = XY)
    {
        axesAlignment = _axesAlignment;

        glPushMatrix();
        /*

        switch(axesAlignment)
        {
        case XY: break;
        case ZX: glRotatef(90.0f,1.0f,0.0f,0.0f); break;
        case YZ: glRotatef(90.0f,0.0f,1.0f,0.0f); break;
        }

        */

        //glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);

        if(fill)
        {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            //glColor4f(.5f,0.5f,0.5f,0.2f);

            switch(axesAlignment)
            {
            case XY: glColor4f(0,0,1,.2);break;
            case ZX: glColor4f(0,1,0,.2); break;
            case YZ: glColor4f(1,0,0,.2); break;
            }

            glBegin(GL_POLYGON);

            for(int i=0;i<vertices.size();i++)
            {
               QVector3D v = vertices[i];
               glVertex3f(v.x(),v.y(),v.z());

            }
            glEnd();

           glDisable(GL_BLEND);
        }


        switch(axesAlignment)
        {
        case XY: glColor4f(0,0,1,1);break;
        case ZX: glColor4f(0,1,0,1); break;
        case YZ: glColor4f(1,0,0,1); break;
        }

         glLineWidth(1.0);

         glBegin(GL_LINE_STRIP);

         for(int i=0;i<vertices.size();i++)
         {
            QVector3D v = vertices[i];
            glVertex3f(v.x(),v.y(),v.z());
         }

         QVector3D v = vertices[0];
         glVertex3f(v.x(),v.y(),v.z());
         glEnd();
         glLineWidth(2.0);
         glPopMatrix();

         glEnable(GL_DEPTH_TEST);
         //glEnable(GL_LIGHTING);

    }


    int getAxesAlignment()
    {
       return axesAlignment;
    }


    void setAxesAlignment(QTrans value)
    {
       axesAlignment = value;
    }
};

class QArrow
{
public:
    QList<QVector3D> vertices;
    QVector3D normal;
    QVector3D pos;
    QVector3D end;

    int axesAlignment;
    float radius;

    GLUquadric * pointer;

    QArrow(float _radius =0.5f)
    {

        radius  = _radius;
        pos     = QVector3D(0,0,0);
        normal  = QVector3D(0,0,1);
        end = radius*normal + pos;
        axesAlignment = XY;

        pointer = gluNewQuadric();

        //printf("vertices Count: %i",vertices.size());
    }



    void drawNormal()
    {
        glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);
        glLineWidth(2.0);
        glBegin(GL_LINES);
        glColor3f(1.0f,1.0f,0.0f);
        glVertex3f(pos.x(),pos.z(),pos.y());
        glVertex3f(end.x(),end.z(),end.y());
        glEnd();
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);
    }


    void drawArrow(int _axesAlignment = XY)
    {
        axesAlignment = _axesAlignment;

        glPushMatrix();

        switch(axesAlignment)
        {
        case XY: glTranslatef(0,0,1*radius);break;
        case ZX: glTranslatef(0,1*radius,0);glRotatef(-90.0f,1.0f,0.0f,0.0f); break;
        case YZ: glTranslatef(1*radius,0,0);glRotatef(90.0f,0.0f,1.0f,0.0f); break;
        }

        //glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);


        switch(axesAlignment)
        {
        case XY: glColor4f(0,0,1,1);break;
        case ZX: glColor4f(0,1,0,1); break;
        case YZ: glColor4f(1,0,0,1); break;
        }

        //drawNormal();

        glPushMatrix();

        //glTranslatef(end.x,end.y,end.z);


        gluCylinder (pointer, .08f,0,0.4f,6,1);

        glPopMatrix();

        glPopMatrix();

        glEnable(GL_DEPTH_TEST);
         //glEnable(GL_LIGHTING);

    }


    int getAxesAlignment()
    {
       return axesAlignment;
    }


    void setAxesAlignment(int value)
    {
       axesAlignment = value;
    }
};

//Ray defined by 2 points (can we call it a segment?)
//The 2 points p0 and p1 are expressed in non-opengl cartesian co-ordinates.
//where the Z axis in vertical. In opengl the screen and the Y axis is vertical.

class QRay
{
public:
    QVector3D p0;
    QVector3D p1;

    QVector3D direction;

    int hitStatus;

    QRay()
    {
        p0 = QVector3D(0,0,0);
        p1 = QVector3D(0,0,0);
    }

    QRay(QVector3D P0,QVector3D P1)
    {
        p0 = QVector3D(0,0,0);
        p1 = QVector3D(0,0,0);

        p0 = P0;
        p1 = P1;

        direction = p1-p0;

        direction = direction.normalized();
    }

    QRay(int x, int y)
    {
        p0 = QVector3D(0,0,0);
        p1 = QVector3D(0,0,0);

        rayCastScene(x, y);
    }

    void rayCastScene( int x, int y)
    {
        double modelview[16], projection[16];
        int viewport[4];
        float z = 1;

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewport );


        double x_start= 0, y_start=0, z_start=0;
        gluUnProject( x, viewport[3]-y, 0, modelview, projection, viewport, &x_start, &y_start, &z_start );
        QVector3D start(x_start,y_start,z_start);
       // printf("start x:%f,y:%f,z:%f\n\n",start.x,start.y,start.z);


        double x_end= 0, y_end=0, z_end=0;
        gluUnProject( x, viewport[3]-y, 1, modelview, projection, viewport, &x_end, &y_end, &z_end );
        QVector3D end(x_end,y_end,z_end);
        //printf("end x:%f,y:%f,z:%f\n\n",end.x,end.y,end.z);


        p0 = start;
        p1 = end;

        direction = p1 - p0;
        direction = direction.normalized();

        //printf("Ray x:%f,y:%f,z:%f\n\n",ray.x,ray.y,ray.z);
    }

    QVector3D getRayCastSceneDirection( int x, int y)
    {
        double modelview[16], projection[16];
        int viewport[4];
        float z = 1;

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewport );


        double x_start= 0, y_start=0, z_start=0;
        gluUnProject( x, viewport[3]-y, 0, modelview, projection, viewport, &x_start, &y_start, &z_start );
        QVector3D start(x_start,y_start,z_start);
       // printf("start x:%f,y:%f,z:%f\n\n",start.x,start.y,start.z);


        double x_end= 0, y_end=0, z_end=0;
        gluUnProject( x, viewport[3]-y, 1, modelview, projection, viewport, &x_end, &y_end, &z_end );
        QVector3D end(x_end,y_end,z_end);
        //printf("end x:%f,y:%f,z:%f\n\n",end.x,end.y,end.z);


        p0 = start;
        p1 = end;

        direction = p1 - p0;
        direction = direction.normalized();

        //printf("Ray x:%f,y:%f,z:%f\n\n",ray.x,ray.y,ray.z);

        return direction;
    }


    // Intersects(): intersect a segment and a plane
    //    Input:  p = a plane
    //    Output: I = the intersection point (when it exists)
    //    Return: 0 = disjoint (no intersection)
    //            1 = intersection in the unique point I
    //            2 = the segment lies in the plane
    //


    //the plane is in flight simulator co-ordinate system form, where the Z axis in vertical
    //(whereas in OpenGL the Y axis is vertical ).

    int Intersects(QPlane plane, QVector3D I)
    {
        QVector3D intersectPoint;

        QVector3D u = p1 - p0;
        QVector3D w = p0 - plane.center;

        float     D = QVector3D::dotProduct(plane.normal,u);
        float     N = QVector3D::dotProduct(-plane.normal,w);

        if (fabs(D) < 0)    // segment is parallel to plane
        {
            if (N == 0)     // segment lies in plane
            {
                hitStatus = PARALLEL;
                return 2;
            }
            else
            {
                hitStatus = NOINTERSCETION;
                return 0;   // no intersection
            }
        }

        float s = N / D;

        if (s < 0 || s > 1)
        {
            hitStatus = NOINTERSCETION;
            return 0;     // no intersection
        }

        intersectPoint = p0 + u*s; // compute segment intersect point


        I =  intersectPoint;

        hitStatus = INTERSECTS;

        return 1;
    }



    QVector3D getRayPlaneIntersection(QPlane plane)
    {
        QVector3D intersectPoint;

        QVector3D u = p1 - p0;
        QVector3D w = p0 - plane.center;

        float     D = QVector3D::dotProduct(plane.normal,u);
        float     N = QVector3D::dotProduct(-plane.normal,w);

        if (fabs(D) < 0)    // segment is parallel to plane
        {
            if (N == 0)     // segment lies in plane
            {
                hitStatus = PARALLEL;
                return intersectPoint;
            }
            else
            {
                hitStatus = NOINTERSCETION;
                return intersectPoint;   // no intersection
            }
        }

        float s = N / D;
        if (s < 0 || s > 1)
        {
            hitStatus = NOINTERSCETION;
            return intersectPoint;     // no intersection
        }

        intersectPoint = p0 + u*s; // compute segment intersect point

        hitStatus = INTERSECTS;

        return intersectPoint;
    }

};

class QCollision
{
public:


    QVector3D  getLinePlaneIntersectPoint(QRay ray,QPlane plane)
    {
        QVector3D intersectPoint;

        QVector3D u = ray.p1 - ray.p0;
        QVector3D w = ray.p0 - plane.center;

        float     D = QVector3D::dotProduct(plane.normal,u);
        float     N = QVector3D::dotProduct(-plane.normal,w);

        if (fabs(D) < 0)    // segment is parallel to plane
        {
            if (N == 0)     // segment lies in plane
            {
                return QVector3D(0,0,0);
            }
            else
            {
                return QVector3D(0,0,0);   // no intersection
            }
        }

        float s = N / D;
        if (s < 0 || s > 1)
        {
            return QVector3D(0,0,0);;     // no intersection
        }

        intersectPoint = ray.p0 + u*s; // compute segment intersect point

        return intersectPoint;
    }


    bool spheretoSphereIntersect(QBoundSphere a, QBoundSphere b)
    {
        QVector3D ab;
        float sqdist, sqrad;
        ab = b.center - a.center;
        float l = ab.length();
        sqdist = l*l;
        //Combined radii squared
        sqrad = a.radius*a.radius + b.radius*b.radius;
        return (sqdist<sqrad);
    }


    static bool RaySphereCollision(QVector3D sphereCenter,float sphereRadius,QVector3D A, QVector3D B)
    {
        QVector3D dirtosphere = sphereCenter - A;


        QVector3D lineDir = B-A;
        lineDir = lineDir.normalized();

        QVector3D d =  B - A;

        float distance = d.length();//length of segement
        float t = QVector3D::dotProduct(dirtosphere,lineDir);//dirtosphere to project to lineDir

        QVector3D closestPoint;

        if(t<=0)
            closestPoint = A;
        else if(t>= distance)
            closestPoint = B;
        else
            closestPoint = A + lineDir * t;//calculate the point along the line using t


        QVector3D clp = sphereCenter - closestPoint;

        //now to check the closestPoint is in sphereradius
        return clp.length()<= sphereRadius;
    }

    static QList<QVector3D> getLineSphereIntersectionPoints(QVector3D start, QVector3D end, QVector3D sphereCenter, double sphereRadius)
    {
        QList<QVector3D> intersectionPoints;

        double cx = sphereCenter.x();
        double cy = sphereCenter.y();
        double cz = sphereCenter.z();

        double px = start.x();
        double py = start.y();
        double pz = start.z();

        double vx = end.x() - px;
        double vy = end.y() - py;
        double vz = end.z() - pz;

        double A = vx * vx + vy * vy + vz * vz;
        double B = 2.0 * (px * vx + py * vy + pz * vz - vx * cx - vy * cy - vz * cz);
        double C = px * px - 2 * px * cx + cx * cx + py * py - 2 * py * cy + cy * cy +
                   pz * pz - 2 * pz * cz + cz * cz - sphereRadius * sphereRadius;

        // discriminant
        double D = B * B - 4 * A * C;

        double t1 = (-B - sqrt(D)) / (2.0 * A);

        QVector3D p0 =  QVector3D(start.x() * (1 - t1) + t1 * end.x(),
                                         start.y() * (1 - t1) + t1 * end.y(),
                                         start.z() * (1 - t1) + t1 * end.z());

        double t2 = (-B + sqrt(D)) / (2.0 * A);

        QVector3D p1 =  QVector3D(start.x() * (1 - t2) + t2 * end.x(),
                                         start.y() * (1 - t2) + t2 * end.y(),
                                         start.z() * (1 - t2) + t2 * end.z());

        if (D < 0 || t1 > 1 || t2 >1)
        {
            //intersectionPoints.append(QVector3D(0,0,0));
        }
        else if (D == 0)
        {
            intersectionPoints.append(p0);

            QVector3D surfaceNormal0 = (p0 - sphereCenter).normalized();

        }
        else
        {
            // The normal vector to the surface of
            // a sphere is outward from the center.

            QVector3D surfaceNormal0 = (p0 - sphereCenter).normalized();
            QVector3D surfaceNormal1 = (p1 - sphereCenter).normalized();

            intersectionPoints.append(p0);
            intersectionPoints.append(p1);

        }

        return intersectionPoints;
    }

    static float getClosetDistanceRayToLineSegment(const QVector3D& rayOrigin,const QVector3D& rayVec,const QVector3D& lineStart,const QVector3D& lineEnd)
    {

        //-----------------------------------------------
        //              /
        //    u   P(sc)/
        //P0------#---/------->
        //        |  /
        //     Wc | /
        //        |/
        //        #
        //       /Q(tc)
        //      /
        //     /
        //    /
        //   /v
        //  /
        // Q0
        //
        //line 1 P(s) = P0 + s*(P1-P0) = P0 +s*U
        //line 2 Q(t) = Q0 + t(Q1-Q0) = Q0+t*v
        //line 3 W(t) = W0 + t(u-v) with W0 = P0 - Q0;
        //----------------------------------------------
        //We can solve these two equations by substituting
        //  WC = p(sc)-Q(t)=w0 +sc*u -tc*v, where w0=P0-Q0,
        //into each one to get two simultaneous linear equations:
        //-------------------------------------------------------

        //the smallest distance possible
        float epsilon = 8.854187817f * pow(10,-12);

        QVector3D rayDirection = rayVec;
        QVector3D lineDirection = lineEnd - lineStart;
        QVector3D lineStartToRayOriginDirection = rayOrigin - lineStart;

        float a = QVector3D::dotProduct(rayDirection,rayDirection);	// always >= 0
        float b = QVector3D::dotProduct(rayDirection,lineDirection);
        float c = QVector3D::dotProduct(lineDirection,lineDirection);	// always >= 0
        float d = QVector3D::dotProduct(rayDirection,lineStartToRayOriginDirection);
        float e = QVector3D::dotProduct(lineDirection,lineStartToRayOriginDirection);

        float D = a*c - b*b;	// always >= 0
        float sc, sN, sD = D;	// sc = sN / sD, default sD = D >= 0
        float tc, tN, tD = D;	// tc = tN / tD, default tD = D >= 0

        // compute the line parameters of the two closest points
        if (D < epsilon)
        {
            // the lines are almost parallel
            sN = 0.0;			// force using point P0 on segment S1
            sD = 1.0;			// to prevent possible division by 0.0 later
            tN = e;
            tD = c;
        }
        else
        {
            // get the closest points on the infinite lines
            sN = (b*e - c*d);
            tN = (a*e - b*d);
            if (sN < 0.0)
            {	// sc < 0 => the s=0 edge is visible
                sN = 0.0;
                tN = e;
                tD = c;
            }
        }

        if (tN < 0.0)
        {		// tc < 0 => the t=0 edge is visible
            tN = 0.0;
            // recompute sc for this edge
            if (-d < 0.0)
                sN = 0.0;
            else
            {
                sN = -d;
                sD = a;
            }
        }
        else if (tN > tD)
        {	  // tc > 1 => the t=1 edge is visible
            tN = tD;
            // recompute sc for this edge
            if ((-d + b) < 0.0)
                sN = 0;
            else
            {
                sN = (-d + b);
                sD = a;
            }
        }
        // finally do the division to get sc and tc
        sc = (abs(sN) < epsilon ? 0.0f : sN / sD);
        tc = (abs(tN) < epsilon ? 0.0f : tN / tD);

        // get the difference of the two closest points
        QVector3D dP = lineStartToRayOriginDirection + (sc * rayDirection) - (tc * lineDirection);

        //info.iFracRay  = sc;
        //info.iFracLine = tc;

        return dP.length();// return the closest point
    }

    static QVector3D getClosetPointRayToLineSegment(const QVector3D& rayOrigin,const QVector3D& rayVec,const QVector3D& lineStart,const QVector3D& lineEnd)
    {


        //-----------------------------------------------
        //              /
        //    u   P(sc)/
        //P0------#---/------->
        //        |  /
        //     Wc | /
        //        |/
        //        #
        //       /Q(tc)
        //      /
        //     /
        //    /
        //   /v
        //  /
        // Q0
        //
        //line 1 P(s) = P0 + s*(P1-P0) = P0 +s*U
        //line 2 Q(t) = Q0 + t(Q1-Q0) = Q0+t*v
        //line 3 W(t) = W0 + t(u-v) with W0 = P0 - Q0;
        //----------------------------------------------
        //We can solve these two equations by substituting
        //  WC = p(sc)-Q(t)=w0 +sc*u -tc*v, where w0=P0-Q0,
        //into each one to get two simultaneous linear equations:
        //-------------------------------------------------------

        //the smallest distance possible
        float epsilon = 8.854187817f * pow(10,-12);

        QVector3D rayDirection = rayVec;
        QVector3D lineDirection = lineEnd - lineStart;
        QVector3D lineStartToRayOriginDirection = rayOrigin - lineStart;

        float a = QVector3D::dotProduct(rayDirection,rayDirection);	// always >= 0
        float b = QVector3D::dotProduct(rayDirection,lineDirection);
        float c = QVector3D::dotProduct(lineDirection,lineDirection);	// always >= 0
        float d = QVector3D::dotProduct(rayDirection,lineStartToRayOriginDirection);
        float e = QVector3D::dotProduct(lineDirection,lineStartToRayOriginDirection);

        float D = a*c - b*b;	// always >= 0
        float sc, sN, sD = D;	// sc = sN / sD, default sD = D >= 0
        float tc, tN, tD = D;	// tc = tN / tD, default tD = D >= 0

        // compute the line parameters of the two closest points
        if (D < epsilon)
        {
            // the lines are almost parallel
            sN = 0.0;			// force using point P0 on segment S1
            sD = 1.0;			// to prevent possible division by 0.0 later
            tN = e;
            tD = c;
        }
        else
        {
            // get the closest points on the infinite lines
            sN = (b*e - c*d);
            tN = (a*e - b*d);
            if (sN < 0.0)
            {	// sc < 0 => the s=0 edge is visible
                sN = 0.0;
                tN = e;
                tD = c;
            }
        }

        if (tN < 0.0)
        {		// tc < 0 => the t=0 edge is visible
            tN = 0.0;
            // recompute sc for this edge
            if (-d < 0.0)
                sN = 0.0;
            else
            {
                sN = -d;
                sD = a;
            }
        }
        else if (tN > tD)
        {	  // tc > 1 => the t=1 edge is visible
            tN = tD;
            // recompute sc for this edge
            if ((-d + b) < 0.0)
                sN = 0;
            else
            {
                sN = (-d + b);
                sD = a;
            }
        }
        // finally do the division to get sc and tc
        sc = (abs(sN) < epsilon ? 0.0f : sN / sD);
        tc = (abs(tN) < epsilon ? 0.0f : tN / tD);

        // get the difference of the two closest points
        //QVector3D dP = lineStartToRayOriginDirection + (sc * rayDirection) - (tc * lineDirection);

        //info.iFracRay  = sc;
        //info.iFracLine = tc;

        //return dP.length();
        // return the closest point

        //QVector3D scp  = rayDirection *sc;

        //QVector3D cp  = (tc * lineDirection);

        QVector3D closedPointOnRay  = rayOrigin+rayDirection.normalized() *sc;




        return closedPointOnRay;
    }


    static QList<QVector3D> getTwoClosetPointsRayToLineSegment(const QVector3D& rayOrigin,const QVector3D& rayVec,const QVector3D& lineStart,const QVector3D& lineEnd)
    {

        //-----------------------------------------------
        //              /
        //    u   P(sc)/
        //P0------#---/------->
        //        |  /
        //     Wc | /
        //        |/
        //        #
        //       /Q(tc)
        //      /
        //     /
        //    /
        //   /v
        //  /
        // Q0
        //
        //line 1 P(s) = P0 + s*(P1-P0) = P0 +s*U
        //line 2 Q(t) = Q0 + t(Q1-Q0) = Q0+t*v
        //line 3 W(t) = W0 + t(u-v) with W0 = P0 - Q0;
        //----------------------------------------------
        //We can solve these two equations by substituting
        //  WC = p(sc)-Q(t)=w0 +sc*u -tc*v, where w0=P0-Q0,
        //into each one to get two simultaneous linear equations:
        //-------------------------------------------------------

        //the smallest distance possible
        float epsilon = 8.854187817f * pow(10,-12);

        QVector3D rayDirection = rayVec;
        QVector3D lineDirection = lineEnd - lineStart;
        QVector3D lineStartToRayOriginDirection = rayOrigin - lineStart;

        float a = QVector3D::dotProduct(rayDirection,rayDirection);	// always >= 0
        float b = QVector3D::dotProduct(rayDirection,lineDirection);
        float c = QVector3D::dotProduct(lineDirection,lineDirection);	// always >= 0
        float d = QVector3D::dotProduct(rayDirection,lineStartToRayOriginDirection);
        float e = QVector3D::dotProduct(lineDirection,lineStartToRayOriginDirection);

        float D = a*c - b*b;	// always >= 0
        float sc, sN, sD = D;	// sc = sN / sD, default sD = D >= 0
        float tc, tN, tD = D;	// tc = tN / tD, default tD = D >= 0

        // compute the line parameters of the two closest points
        if (D < epsilon)
        {
            // the lines are almost parallel
            sN = 0.0;			// force using point P0 on segment S1
            sD = 1.0;			// to prevent possible division by 0.0 later
            tN = e;
            tD = c;
        }
        else
        {
            // get the closest points on the infinite lines
            sN = (b*e - c*d);
            tN = (a*e - b*d);
            if (sN < 0.0)
            {	// sc < 0 => the s=0 edge is visible
                sN = 0.0;
                tN = e;
                tD = c;
            }
        }

        if (tN < 0.0)
        {		// tc < 0 => the t=0 edge is visible
            tN = 0.0;
            // recompute sc for this edge
            if (-d < 0.0)
                sN = 0.0;
            else
            {
                sN = -d;
                sD = a;
            }
        }
        else if (tN > tD)
        {	  // tc > 1 => the t=1 edge is visible
            tN = tD;
            // recompute sc for this edge
            if ((-d + b) < 0.0)
                sN = 0;
            else
            {
                sN = (-d + b);
                sD = a;
            }
        }
        // finally do the division to get sc and tc
        sc = (abs(sN) < epsilon ? 0.0f : sN / sD);
        tc = (abs(tN) < epsilon ? 0.0f : tN / tD);

        // get the difference of the two closest points
        //QVector3D dP = lineStartToRayOriginDirection + (sc * rayDirection) - (tc * lineDirection);

        //info.iFracRay  = sc;
        //info.iFracLine = tc;

        //return dP.length();
        // return the closest point
        QVector3D closedPointOnRay  = rayOrigin+rayDirection.normalized() *sc;

        QVector3D closedPointOnLine  = lineStart + lineDirection.normalized() * tc;

        QList<QVector3D> list;

        list.append(closedPointOnRay);
        list.append(closedPointOnLine);

        return list;
    }

    static QList<QVector3D> getTwoClosetPointsRayToLineSegment(QRay ray,const QVector3D& lineStart,const QVector3D& lineEnd)
    {
        //-----------------------------------------------
        //              /
        //    u   P(sc)/
        //P0------#---/------->
        //        |  /
        //     Wc | /
        //        |/
        //        #
        //       /Q(tc)
        //      /
        //     /
        //    /
        //   /v
        //  /
        // Q0
        //
        //line 1 P(s) = P0 + s*(P1-P0) = P0 +s*U
        //line 2 Q(t) = Q0 + t(Q1-Q0) = Q0+t*v
        //line 3 W(t) = W0 + t(u-v) with W0 = P0 - Q0;
        //----------------------------------------------
        //We can solve these two equations by substituting
        //  WC = p(sc)-Q(t)=w0 +sc*u -tc*v, where w0=P0-Q0,
        //into each one to get two simultaneous linear equations:
        //-------------------------------------------------------

        //the smallest distance possible
        float epsilon = 8.854187817f * pow(10,-12);

        QVector3D rayDirection = ray.direction;
        QVector3D lineDirection = lineEnd - lineStart;
        QVector3D lineStartToRayOriginDirection = ray.p0 - lineStart;

        float a = QVector3D::dotProduct(rayDirection,rayDirection);	// always >= 0
        float b = QVector3D::dotProduct(rayDirection,lineDirection);
        float c = QVector3D::dotProduct(lineDirection,lineDirection);	// always >= 0
        float d = QVector3D::dotProduct(rayDirection,lineStartToRayOriginDirection);
        float e = QVector3D::dotProduct(lineDirection,lineStartToRayOriginDirection);

        float D = a*c - b*b;	// always >= 0
        float sc, sN, sD = D;	// sc = sN / sD, default sD = D >= 0
        float tc, tN, tD = D;	// tc = tN / tD, default tD = D >= 0

        // compute the line parameters of the two closest points
        if (D < epsilon)
        {
            // the lines are almost parallel
            sN = 0.0;			// force using point P0 on segment S1
            sD = 1.0;			// to prevent possible division by 0.0 later
            tN = e;
            tD = c;
        }
        else
        {
            // get the closest points on the infinite lines
            sN = (b*e - c*d);
            tN = (a*e - b*d);
            if (sN < 0.0)
            {	// sc < 0 => the s=0 edge is visible
                sN = 0.0;
                tN = e;
                tD = c;
            }
        }

        if (tN < 0.0)
        {		// tc < 0 => the t=0 edge is visible
            tN = 0.0;
            // recompute sc for this edge
            if (-d < 0.0)
                sN = 0.0;
            else
            {
                sN = -d;
                sD = a;
            }
        }
        else if (tN > tD)
        {	  // tc > 1 => the t=1 edge is visible
            tN = tD;
            // recompute sc for this edge
            if ((-d + b) < 0.0)
                sN = 0;
            else
            {
                sN = (-d + b);
                sD = a;
            }
        }
        // finally do the division to get sc and tc
        sc = (abs(sN) < epsilon ? 0.0f : sN / sD);
        tc = (abs(tN) < epsilon ? 0.0f : tN / tD);

        // get the difference of the two closest points
        //QVector3D dP = lineStartToRayOriginDirection + (sc * rayDirection) - (tc * lineDirection);

        //info.iFracRay  = sc;
        //info.iFracLine = tc;



        //return dP.length();
        // return the closest point
        QVector3D closedPointOnRay  = ray.p0+rayDirection *sc;

        QVector3D closedPointOnLine  = lineStart +(tc * lineDirection);

        QList<QVector3D> list;

        list.append(closedPointOnRay);
        list.append(closedPointOnLine);


        return list;
    }


    bool pointInSphere(QBoundSphere a,QVector3D p)
    {
        QVector3D v =  a.center - p;
        float dist = v.length();
        return  (dist < a.radius);
    }
};



/*
    // Assume that classes are already given for the objects:
    //    Point and Vector with
    //        coordinates {float x, y, z;}
    //        operators for:
    //            Point   = Point ± Vector
    //            Vector =  Point - Point
    //            Vector =  Vector ± Vector
    //            Vector =  Scalar * Vector
    //    Line and Segment with defining points {Point  P0, P1;}
    //    Track with initial position and velocity vector
    //            {Point P0;  Vector v;}
    //===================================================================


    #define SMALL_NUM   0.00000001 // anything that avoids division overflow
    // dot product (3D) which allows vector operations in arguments
    #define dot(u,v)   ((u).x * (v).x + (u).y * (v).y + (u).z * (v).z)
    #define norm(v)    sqrt(dot(v,v))  // norm = length of  vector
    #define d(u,v)     norm(u-v)        // distance = norm of difference
    #define abs(x)     ((x) >= 0 ? (x) : -(x))   //  absolute value



    // dist3D_Line_to_Line(): get the 3D minimum distance between 2 lines
    //    Input:  two 3D lines L1 and L2
    //    Return: the shortest distance between L1 and L2
    float
    dist3D_Line_to_Line( Line L1, Line L2)
    {
        Vector   u = L1.P1 - L1.P0;
        Vector   v = L2.P1 - L2.P0;
        Vector   w = L1.P0 - L2.P0;
        float    a = dot(u,u);         // always >= 0
        float    b = dot(u,v);
        float    c = dot(v,v);         // always >= 0
        float    d = dot(u,w);
        float    e = dot(v,w);
        float    D = a*c - b*b;        // always >= 0
        float    sc, tc;

        // compute the line parameters of the two closest points
        if (D < SMALL_NUM)
        {
         // the lines are almost parallel
            sc = 0.0;
            tc = (b>c ? d/b : e/c);    // use the largest denominator
        }
        else
        {
            sc = (b*e - c*d) / D;
            tc = (a*e - b*d) / D;
        }

        // get the difference of the two closest points
        Vector   dP = w + (sc * u) - (tc * v);  // =  L1(sc) - L2(tc)

        return norm(dP);   // return the closest distance
    }
    //===================================================================


    // dist3D_Segment_to_Segment(): get the 3D minimum distance between 2 segments
    //    Input:  two 3D line segments S1 and S2
    //    Return: the shortest distance between S1 and S2
    float
    dist3D_Segment_to_Segment( Segment S1, Segment S2)
    {
        Vector   u = S1.P1 - S1.P0;
        Vector   v = S2.P1 - S2.P0;
        Vector   w = S1.P0 - S2.P0;
        float    a = dot(u,u);         // always >= 0
        float    b = dot(u,v);
        float    c = dot(v,v);         // always >= 0
        float    d = dot(u,w);
        float    e = dot(v,w);
        float    D = a*c - b*b;        // always >= 0
        float    sc, sN, sD = D;       // sc = sN / sD, default sD = D >= 0
        float    tc, tN, tD = D;       // tc = tN / tD, default tD = D >= 0

        // compute the line parameters of the two closest points
        if (D < SMALL_NUM) { // the lines are almost parallel
            sN = 0.0;         // force using point P0 on segment S1
            sD = 1.0;         // to prevent possible division by 0.0 later
            tN = e;
            tD = c;
        }
        else {                 // get the closest points on the infinite lines
            sN = (b*e - c*d);
            tN = (a*e - b*d);
            if (sN < 0.0) {        // sc < 0 => the s=0 edge is visible
                sN = 0.0;
                tN = e;
                tD = c;
            }
            else if (sN > sD) {  // sc > 1  => the s=1 edge is visible
                sN = sD;
                tN = e + b;
                tD = c;
            }
        }

        if (tN < 0.0) {            // tc < 0 => the t=0 edge is visible
            tN = 0.0;
            // recompute sc for this edge
            if (-d < 0.0)
                sN = 0.0;
            else if (-d > a)
                sN = sD;
            else {
                sN = -d;
                sD = a;
            }
        }
        else if (tN > tD) {      // tc > 1  => the t=1 edge is visible
            tN = tD;
            // recompute sc for this edge
            if ((-d + b) < 0.0)
                sN = 0;
            else if ((-d + b) > a)
                sN = sD;
            else {
                sN = (-d +  b);
                sD = a;
            }
        }
        // finally do the division to get sc and tc
        sc = (abs(sN) < SMALL_NUM ? 0.0 : sN / sD);
        tc = (abs(tN) < SMALL_NUM ? 0.0 : tN / tD);

        // get the difference of the two closest points
        Vector   dP = w + (sc * u) - (tc * v);  // =  S1(sc) - S2(tc)

        return norm(dP);   // return the closest distance
    }
    //===================================================================


    // cpa_time(): compute the time of CPA for two tracks
    //    Input:  two tracks Tr1 and Tr2
    //    Return: the time at which the two tracks are closest
    float
    cpa_time( Track Tr1, Track Tr2 )
    {
        Vector   dv = Tr1.v - Tr2.v;

        float    dv2 = dot(dv,dv);
        if (dv2 < SMALL_NUM)      // the  tracks are almost parallel
            return 0.0;             // any time is ok.  Use time 0.

        Vector   w0 = Tr1.P0 - Tr2.P0;
        float    cpatime = -dot(w0,dv) / dv2;

        return cpatime;             // time of CPA
    }
    //===================================================================


    // cpa_distance(): compute the distance at CPA for two tracks
    //    Input:  two tracks Tr1 and Tr2
    //    Return: the distance for which the two tracks are closest
    float
    cpa_distance( Track Tr1, Track Tr2 )
    {
        float    ctime = cpa_time( Tr1, Tr2);
        Point    P1 = Tr1.P0 + (ctime * Tr1.v);
        Point    P2 = Tr2.P0 + (ctime * Tr2.v);

        return d(P1,P2);            // distance at CPA
    }
    //===================================================================

*/








#endif // GEOMETRY_HPP

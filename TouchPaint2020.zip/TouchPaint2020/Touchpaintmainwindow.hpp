#ifndef METROPOLISMAINWINDOW_HPP
#define METROPOLISMAINWINDOW_HPP

#include<QtWidgets>

#include<about.hpp>
#include<view3d.h>
#include<widgets.hpp>

class TouchPaintMainWindow : public QMainWindow
{
    Q_OBJECT

    //QDockWidget *TimeLineEditorDoc;
    //QDockWidget *nodeEditorDoc;
    QDockWidget *propertiesEditorDoc;
    //QDockWidget *ToolBoxEditorDock;
    QDockWidget *scenegraphDock;
    QDockWidget *materialEditorDock;
    //QDockWidget *curveEditorDock;

    QAction *exitAction;
    bool hidedocks = false;
    About *about;

public:

    QWidget *CentralWidget;

    //nodeTreeEditor *nodetree;

    QMainView *view3d;

    //QView3D *view3d;

    //QToolBar * mainToolBar;

    //explicit MetropolisMainWindow(QWidget *parent = 0);
    TouchPaintMainWindow(QWidget * parent=0)
    {
        about = new About;

        CentralWidget =  new QWidget;

        //CubeLayoutWidget *CubeWidget = new CubeLayoutWidget;

        this->setCentralWidget(CentralWidget);
        this->iniUI();
        //add some dock widgets;

        //this->centralWidget()->releaseKeyboard();
        //this->resize(768,458);


        this->showMaximized();
    }

    ~TouchPaintMainWindow()
    {
        //delete TimeLineEditorDoc;
        //delete nodeEditorDoc;
        delete propertiesEditorDoc;
        //delete ToolBoxEditorDock;
        delete scenegraphDock;
        delete materialEditorDock;
        //delete curveEditorDock;
        //delete nodetree;
        delete CentralWidget;
        delete exitAction;
    }

    void iniUI()
    {
        setTheme();
        setTitleDetails();
        CreateMenue();

        CreateDockWindows();
        CreateStatusBar();

        CreateToolBar();

        about->hide();


    }
    void setTheme()
    {
        //using menu to switch styles
        //qDebug()<<"Loading Styles";

        QFile file(":/icons/glowBlue.stylesheet");

       // QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            this->setStyleSheet(file.readAll());

            file.close();
        }


        qDebug()<<"Styles Loaded";
    }

    void setTitleDetails()
    {
        setWindowTitle(QString("Touch Paint"));

        setWindowIcon(QIcon(":/icons/metropolis.svg"));

        qDebug()<<"Title Details Loaded";

    }
    void CreateMenue()
    {

        QKeySequence shortcut;

        QIcon icon(":/icons/metropolis.svg");

        exitAction = new QAction(icon, QString("Exit"), this);
        //exitAction->setShortcut('Ctrl+Q');
        exitAction->setShortcut(shortcut.New);
        exitAction->setStatusTip(QString("Exit application"));
        //self.exitAction.triggered.connect(self.close);

        QMenuBar *menubar = this->menuBar();
        //this->menuBar()->addMenu(QString("&File"));

        QMenu  * fileMenu = menubar->addMenu(QString("&File"));
        QAction *openaction = fileMenu->addAction(icon, QString("Open"));
        fileMenu->addAction(icon, QString("Save"));
        fileMenu->addAction(icon, QString("Save As"));
        QAction *importaction= fileMenu->addAction(icon, QString("Import"));


         fileMenu->addAction(icon, QString("Export"));
         QAction *quitaction= fileMenu->addAction(icon, QString("Quit"));

         /*

         QMenu  * EditMenu = menubar->addMenu(QString("&"));//chinese format use QString('&Edit')
         EditMenu->addAction(exitAction);

         QMenu  * CreateMenu = menubar->addMenu(QString("&Create"));
         CreateMenu->addAction(exitAction);

         QMenu  * AnimationMenu = menubar->addMenu(QString("&Animation"));
         AnimationMenu->addAction(exitAction);

         QMenu  *CurvesMenu = menubar->addMenu(QString("&Curves"));
         CurvesMenu->addAction(exitAction);

         QMenu  *SurfacesMenu = menubar->addMenu(QString("&Surfaces"));
         SurfacesMenu->addAction(exitAction);

         QMenu  *RenderingMenu = menubar->addMenu(QString("&Rendering"));
         RenderingMenu->addAction(exitAction);

         QMenu  *WindowsMenu = menubar->addMenu(QString("&Windows"));
         WindowsMenu->addAction(exitAction);

         */

         QMenu  *HelpMenu = menubar->addMenu(QString("&Help"));

         QAction *aboutaction = HelpMenu->addAction(icon,QString("&About"));
         //QAction *quitaction  = HelpMenu->addAction(icon,QString("&Quit"));
         HelpMenu->addAction(quitaction);

         connect(aboutaction,SIGNAL(triggered(bool)),this,SLOT(closeAbout()));
         connect(quitaction,SIGNAL(triggered(bool)),this,SLOT(close()));
         connect(importaction,SIGNAL(triggered(bool)),this,SLOT(importDialog()));
         connect(openaction,SIGNAL(triggered(bool)),this,SLOT(importDialog()));

         qDebug()<<"main menues created";
    }

public slots:

    void closeAbout()
    {
        about->showNormal();
    }

    void importDialog()
    {
        QStringList stringlist;
        stringlist.append(QString("TouchPaint File (*.touch)"));
        stringlist.append(QString("Mesh File (*.cube *.obj *.md5 *.md2)"));
        stringlist.append(QString("Images (*.png *.xpm *.jpg)"));
        stringlist.append(QString("Vectors Images (*.svg *.pdf *.eps)"));
        stringlist.append(QString("Text files (*.txt)"));
        stringlist.append(QString("XML files (*.xml)"));

        QFileDialog dialog;

        QDir dir;
        dir.setNameFilters(stringlist);

        dialog.setFilter(dir.filter());
        dialog.show();

        QStringList fileNames;

        if (dialog.exec())
        {
            fileNames = dialog.selectedFiles();

            qDebug()<<fileNames;

            statusBar()->showMessage(fileNames[0]);
        }

    }

public:

    void CreateToolBar()
    {
        this->addToolBar(Qt::LeftToolBarArea,view3d->view->controlsToolBar);

        this->addToolBar(Qt::RightToolBarArea,view3d->view->mainToolBar);

        this->addToolBar(Qt::BottomToolBarArea,view3d->view->brushestoolBar);

        view3d->view->mainToolBar->hide();

        //this->addToolBar(view3d->mainToolBar);

        //view3d->search->showMaximized();

        //ToolBoxEditorDock->setWidget(view3d->search->listviewWidget   );

    }



    void keyPressEvent(QKeyEvent * event)
    {
        if(event->key() == Qt::Key_H)
        {
            hide_show_dock();
        }
    }

    void hide_show_dock()
    {
        if(hidedocks)
        {
            this->hidedocks = false;
        }
        else
        {
            this->hidedocks = true;
        }

        //this->ToolBoxEditorDock->setVisible(this->hidedocks);
        this->propertiesEditorDoc->setVisible(this->hidedocks);
        //this->nodeEditorDoc->setVisible(this->hidedocks);

    }

    void CreateStatusBar()
    {
       this->statusBar()->showMessage("Ready");
    }

    void CreateDockWindows()
    {
        propertiesEditorDoc  = new QDockWidget(QString("Properties Editor"));
        //ToolBoxEditorDock    = new QDockWidget(QString("Tool Box"));
        //nodeEditorDoc        = new QDockWidget(QString("Node Editor"));
        //TimeLineEditorDoc    = new QDockWidget(QString("Time Line"));
        scenegraphDock       = new QDockWidget(QString("Scene Graph"));
        materialEditorDock   = new QDockWidget(QString("Material Editor"));
        //curveEditorDock      = new QDockWidget(QString("Curve Editor"));

        //curveEditorDock->hide();
        materialEditorDock->hide();
        scenegraphDock->hide();
        //ToolBoxEditorDock->hide();
        propertiesEditorDoc->hide();
        //nodeEditorDoc->hide();

        propertiesEditorDoc->setWindowFlags(Qt::WindowTitleHint );
        //ToolBoxEditorDock->setWindowFlags(Qt::WindowTitleHint );
       // nodeEditorDoc->setWindowFlags(Qt::WindowTitleHint );
       // TimeLineEditorDoc->setWindowFlags(Qt::WindowTitleHint );
        scenegraphDock->setWindowFlags(Qt::WindowTitleHint );
        materialEditorDock->setWindowFlags(Qt::WindowTitleHint );
        //curveEditorDock->setWindowFlags(Qt::WindowTitleHint );


        QWidget * toolbox  = new QWidget;
        toolbox->showMaximized();

        QWidget * props = new QWidget;
        props->showMaximized();

        QWidget * nodeEditor = new QWidget;
        nodeEditor->showMaximized();

        QWidget * timelinewidget = new QWidget;
        timelinewidget->showMaximized();

        QWidget * scenegraphWidget = new QWidget;
        scenegraphWidget->showMaximized();


        propertiesEditorDoc->setWidget(props);
        //ToolBoxEditorDock->setWidget(toolbox);
        //nodeEditorDoc->setWidget(nodeEditor);
        //TimeLineEditorDoc->setWidget(timelinewidget);
        scenegraphDock->setWidget(scenegraphWidget);

        //TimeLineEditorDoc->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea );
        //this->addDockWidget(Qt::BottomDockWidgetArea, TimeLineEditorDoc);


        propertiesEditorDoc->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, propertiesEditorDoc);

        //ToolBoxEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        //this->addDockWidget(Qt::RightDockWidgetArea, ToolBoxEditorDock);

        //nodeEditorDoc->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        //this->addDockWidget(Qt::RightDockWidgetArea, nodeEditorDoc);

        scenegraphDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, scenegraphDock);

        materialEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        this->addDockWidget(Qt::RightDockWidgetArea, materialEditorDock);

        //curveEditorDock->setAllowedAreas(Qt::BottomDockWidgetArea | Qt::TopDockWidgetArea | Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
        //this->addDockWidget(Qt::RightDockWidgetArea, curveEditorDock);


        this->tabifyDockWidget(propertiesEditorDoc,scenegraphDock);
        this->tabifyDockWidget(scenegraphDock,materialEditorDock);


        //this->tabifyDockWidget(ToolBoxEditorDock,propertiesEditorDoc);
        //this->tabifyDockWidget(propertiesEditorDoc,nodeEditorDoc);
        //this->tabifyDockWidget(nodeEditorDoc,scenegraphDock);
        //this->tabifyDockWidget(scenegraphDock,materialEditorDock);
        //this->tabifyDockWidget(materialEditorDock,curveEditorDock);
        //nodeEditorDock->raise();
        //ToolBoxEditorDock->raise();
        this->setDockOptions(QMainWindow::VerticalTabs);
        this->setTabPosition(Qt::TopDockWidgetArea,QTabWidget::North);

        /*
        nodetree = new nodeTreeEditor;
        propertiesEditorDoc->setWidget(nodetree->propertiesWidget);
        TimeLineEditorDoc->setWidget(nodetree->timeline);
        nodeEditorDoc->setWidget(nodetree);

        */



        view3d = new QMainView;
        this->setCentralWidget(view3d);

        //ToolBoxEditorDock->setWidget(  view3d->search );


        //view3d = new QView3D;


        this->setCentralWidget(view3d);
    }
};





#endif // METROPOLISMAINWINDOW_HPP

#include<QtWidgets>

#include<Touchpaint.hpp>
#include<Touchpaintmainwindow.hpp>

int main(int argc, char *argv[])
{

    QApplication app(argc, argv);

    app.setAttribute( Qt::AA_UseDesktopOpenGL );

    //Metropolis * metroCity =  new Metropolis;

    TouchPaintMainWindow * mainwindow = new TouchPaintMainWindow;


    mainwindow->showMaximized();


    return app.exec();
}

#ifndef SCENE_HPP
#define SCENE_HPP


#include<geometry.hpp>
#include<models.hpp>
#include<handles.hpp>
#include<settings.hpp>


class QSceneGraph :public QObject
{
    Q_OBJECT

public:

    QList<QObject*> parameters;

    FloorGridSetting * floorSettings;

    QGLWidget * parentWidget;


    QMenu mainContextmenu;
    QMenu addModelsMenu;

    QStringList modelsList;
    QStringList allnodes;

    //QBaseModel * selectedModel;
    QCameraModel * camera;

    QIcon icon;

    QPoint lastPos;

    QTrans PlaneAXesMode;

    QTransformMode TransformMode;

    QHitInfo *currentHit;
    //QList<QHitInfo*> hits;

    QVector3D ray;
    QVector3D prevhitpoint;
    QVector3D lastRayOrigin;
    QVector3D rayscreenOffset;

    AxesTransformer * axesTransformer;

    //QList< QGroupModel *> groups;
    QList< QCameraModel* > cameras;

    //QList< QBaseModel* > models;
    //std::vector< QBaseModel*>models;

    QList< QSharedPointer<QBaseModel> > models1;

    //QHash<int,QBaseModel* > models;
    QList< QBaseModel* > models;




    ~ QSceneGraph()
    {
        delete currentHit;
        delete axesTransformer;
    }







    QSceneGraph(QGLWidget * parentWidget =0,QObject *parent =0):QObject(parent)
    {

        floorSettings = new FloorGridSetting;

        currentHit    = new QHitInfo;

        this->parentWidget =  parentWidget;

        axesTransformer = new AxesTransformer;

        icon = QIcon(QString(":/icons/cubeomniverse.svg"));

        modelsList.append(QString("Mesh"));
        modelsList.append(QString("Plane"));
        modelsList.append(QString("Sphere"));
        modelsList.append(QString("Quad"));
        modelsList.append(QString("Cylinder"));
        modelsList.append(QString("Cone"));
        modelsList.append(QString("Torus"));
        modelsList.append(QString("Cube"));
        //modelsList.append(QString("Ivy"));
        modelsList.append(QString("Light"));
        modelsList.append(QString("Camera"));
        //modelsList.append(QString("Particles"));

        modelsList.sort();


        addModelsMenu.setTitle(QString("Add Model"));
        addModelsMenu.setIcon(icon);


        foreach(QString nodename,modelsList)
        {
            allnodes.append(nodename);
        }

        setModalsMenues();


        QFile file(":/icons/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
           QByteArray  style = file.readAll();

           addModelsMenu.setStyleSheet(style);

           mainContextmenu.setStyleSheet(style);
        }

        //mainContextmenu.setParent(this);
        mainContextmenu.addMenu(&addModelsMenu);
        mainContextmenu.addMenu(&axesTransformer->transformsAxisMenu);
        mainContextmenu.addMenu(&axesTransformer->transformMenu);

        mainContextmenu.hide();

        camera = new QCameraModel;

        camera->PerspectiveMode = QCameraModel::PERSPECTIVE;

        //cameras.append(camera);
        //models.append(camera);
        //models.insert(camera->ID,camera);

        qDebug()<<"Camera:"<<camera->ID;
    }


    QVector3D getScreenToWorldCoordinate( int x, int y)
    {
        double modelview[16], projection[16];
        int viewport[4];
        float z = 0.9;

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewport );

        GLdouble hx = 0, hy = 0, hz = 0;

        gluUnProject( x, viewport[3]-y, z, modelview, projection, viewport, &hx, &hy, &hz );

        QVector3D worldPos(hx,hy,hz);

        //printf("start x:%f,y:%f,z:%f\n\n",start.x,start.y,start.z);

        return worldPos;
    }

    QVector3D getWorldToScreenCoordinate(QVector3D p)
    {
        double modelview[16], projection[16];

        int viewports[4];

        //Read the projection, modelview and viewport matrices
        //using the glGet functions.
        glGetDoublev(GL_PROJECTION_MATRIX, projection );
        glGetDoublev(GL_MODELVIEW_MATRIX, modelview );
        glGetIntegerv(GL_VIEWPORT, viewports );

        GLdouble x,y,z;

        gluProject( p.x(), p.y(), p.z(), modelview, projection, viewports, &x, &y, &z );
        //printf("object x:%f,y:%f,z:%f\n\n",hitx,hity,hitz);
        QVector3D hitpoint(x,y,z);

        return hitpoint;

    }


    void addModel(QString modelname)
    {
        QBaseModel  * model;

        if(modelname.contains("Sphere",Qt::CaseInsensitive))
        {
            model = new QSphereModel;
            //models.append(model);
            models.append(model);

        }
        else if(modelname.contains("Mesh",Qt::CaseInsensitive))
        {
            model = new QMeshModel;
            models.append(model);

        }
        else if(modelname.contains("Quad",Qt::CaseInsensitive))
        {
           model = new  QQuadModel;
           models.append(model);
        }
        else if(modelname.contains("Plane",Qt::CaseInsensitive))
        {
            model = new QPlaneModel;
            models.append(model);

        }
        else if(modelname.contains("Cone",Qt::CaseInsensitive))
        {
            model = new QConeModel;
            models.append(model);
        }
        else if(modelname.contains("Cylinder",Qt::CaseInsensitive))
        {
            model = new QCylinderModel;
            models.append(model);
        }
        else if(modelname.contains("Torus",Qt::CaseInsensitive))
        {
            model = new QTorusModel;
            models.append(model);
        }
        else if(modelname.contains("Cube",Qt::CaseInsensitive))
        {
            model = new QCubeModel;
            models.append(model);
        }
        else if(modelname.contains("Light",Qt::CaseInsensitive))
        {
            model = new QLightModel;
            models.append(model);

        }
        else if(modelname.contains("Ivy",Qt::CaseInsensitive))
        {
            //model = new QIvyModel ;
            //models.append(model);

        }
        else if(modelname.contains("Camera",Qt::CaseInsensitive))
        {
            model = new QCameraModel;
            models.append(model);
            //cameras.append(model);

        }

        //if(model)
        {
            //model->position =  QVector3D(Globals::frandom(1000),Globals::frandom(1000),Globals::frandom(1000));

            //model->Selected =  false;

            //models.append(model);
        }
    }

    void duplicateModel()
    {
       if(models.size()>0 && currentHit->Selected)
       {
           if(models[currentHit->modelID]->Selected)
           {
               QBaseModel *selectedModel = models[currentHit->modelID];

               if(selectedModel)
               {
                   if(models[currentHit->modelID]->type()==MODEL_MESH)
                   {
                      QMeshModel *model=  new QMeshModel;
                      model->position = selectedModel->position;
                      models.append(model);

                   }
                   if(models[currentHit->modelID]->type()==MODEL_QUAD)
                   {
                      QQuadModel *model =  new QQuadModel;
                      model->position = selectedModel->position;
                      models.append(model);

                   }
                   else if(models[currentHit->modelID]->type()==MODEL_CYLINDER)
                   {
                      QCylinderModel *model =  new QCylinderModel;
                      model->position = selectedModel->position;
                      models.append(model);
                   }
                   else if(models[currentHit->modelID]->type()==MODEL_SPHERE)
                   {
                      QSphereModel *model =  new QSphereModel;
                      model->position = selectedModel->position;
                      models.append(model);

                   }
                   else if(models[currentHit->modelID]->type()==MODEL_CUBE)
                   {
                      QCubeModel *model=  new QCubeModel;
                      model->position = selectedModel->position;
                      models.append(model);
                   }
                   else if(models[currentHit->modelID]->type()==MODEL_DONUT)
                   {
                      QTorusModel *model =  new QTorusModel;
                      model->position = selectedModel->position;
                      models.append(model);
                   }
                   else if(models[currentHit->modelID]->type()==MODEL_PLANE)
                   {
                       QPlaneModel *model=  new QPlaneModel;
                       model->position = selectedModel->position;
                       models.append(model);
                   }
                   else if(models[currentHit->modelID]->type()==MODEL_CAMERA)
                   {
                       QCameraModel *model =  new QCameraModel;
                       model->position = selectedModel->position;
                       models.append(model);
                   }
                   else if(models[currentHit->modelID]->type()==MODEL_CONE)
                   {
                      QConeModel *model =  new QConeModel;
                      model->position = selectedModel->position;
                      models.append(model);
                   }
                   else if(models[currentHit->modelID]->type()==MODEL_LIGHT)
                   {
                      QLightModel *model =  new QLightModel;
                      model->position = selectedModel->position;
                      models.append(model);
                   }
                   else if(models[currentHit->modelID]->type()==MODEL_IVY)
                   {
                      //QIvyModel *model =  new QIvyModel;
                      //model->position = selectedModel->position;
                      //models.append(model);
                   }
                   else if(models[currentHit->modelID]->type()==MODEL_PARTICLES)
                   {
                      QParticlesModel *model =  new QParticlesModel;
                      model->position = selectedModel->position;
                      models.append(model);
                   }
               }
           }
       }
    }

    void drawOutlineSelected(QOutlineMode outlineMode = OUTLINE)
    {
        if(models.size()>0 )
        {
            //if(models.size()>0 && models[currentHit->modelID]->Selected)
            if(models.size()>0 && currentHit->Selected)
            {
                switch (outlineMode)
                {
                case OUTLINE:
                {
                    glPushAttrib (GL_POLYGON_BIT);
                    glEnable (GL_CULL_FACE);
                    //Draw front-facing polygons as filled

                    glPolygonMode (GL_FRONT, GL_FILL);
                    glCullFace (GL_BACK);

                    // Draw solid object
                    glColor3f (1.0f, 1.0f, 1.0f);

                    drawSelectedModel();

                    //Draw back-facing polygons as red lines


                    //Disable lighting for outlining
                    glPushAttrib (GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT);
                    glDisable (GL_LIGHTING);

                    glPolygonMode (GL_BACK, GL_LINE);
                    glCullFace (GL_FRONT);

                    glDepthFunc (GL_LEQUAL);
                    glLineWidth (5.0f);

                    //Draw wire object
                    glColor3f (1.0f, 0.0f, 0.0f);
                    drawSelectedModel();

                    //GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT
                    glPopAttrib ();
                    // GL_POLYGON_BIT
                    glPopAttrib ();
                    break;
                }

                case SILHOUETTE:
                {
                    glPushAttrib (GL_POLYGON_BIT);
                    glEnable (GL_CULL_FACE);

                    // Draw back-facing polygons as red lines


                    //Disable lighting for outlining
                    glPushAttrib (GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT);
                    glDisable (GL_LIGHTING);

                    glPolygonMode (GL_BACK, GL_LINE);
                    glCullFace (GL_FRONT);

                    glDisable (GL_DEPTH_TEST);
                    glLineWidth (5.0f);

                    // Draw wire object
                    glColor3f (1.0f, 0.0f, 0.0f);
                    drawSelectedModel();

                    // GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT
                    glPopAttrib ();

                    // Draw front-facing polygons as filled


                    glPolygonMode (GL_FRONT, GL_FILL);
                    glCullFace (GL_BACK);

                    //Draw solid object
                    glColor3f (1.0f, 1.0f, 1.0f);
                    drawSelectedModel();

                    //GL_POLYGON_BIT
                    glPopAttrib ();
                  break;
                }

                case OUTLINE_ONLY:
                {
                    glPushAttrib (GL_POLYGON_BIT);
                    glEnable (GL_CULL_FACE);

                    // Draw front-facing polygons as filled


                    // Disable color buffer
                    glColorMask (GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);

                    glPolygonMode (GL_FRONT, GL_FILL);
                    glCullFace (GL_BACK);

                    //Draw solid object
                    glColor3f (1.0f, 1.0f, 1.0f);
                    drawSelectedModel();

                    //Draw back-facing polygons as red lines


                    // Enable color buffer
                    glColorMask (GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);

                    // Disable lighting for outlining
                    glPushAttrib (GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT);
                    glDisable (GL_LIGHTING);

                    glPolygonMode (GL_BACK, GL_LINE);
                    glCullFace (GL_FRONT);

                    glDepthFunc (GL_LEQUAL);
                    glLineWidth (5.0f);

                    //Draw wire object
                    glColor3f (1.0f, 0.0f, 0.0f);
                    drawSelectedModel();

                    // GL_LIGHTING_BIT | GL_LINE_BIT | GL_DEPTH_BUFFER_BIT
                    glPopAttrib ();

                    // GL_POLYGON_BIT
                    glPopAttrib ();
                    break;
                      }

                case SILHOUETTE_ONLY:
                {
                    // Clear stencil buffer
                    glClearStencil (0);
                    glClear (GL_STENCIL_BUFFER_BIT);

                    // Draw front-facing polygons as filled


                    // Disable color and depth buffers
                    glColorMask (GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
                    glDepthMask (GL_FALSE);

                    // Setup stencil buffer. Draw always in it
                    glEnable (GL_STENCIL_TEST);
                    glStencilFunc (GL_ALWAYS, 1, 0xFFFFFFFF);
                    glStencilOp (GL_REPLACE, GL_REPLACE, GL_REPLACE);

                    // Draw solid object to create a mask
                    glColor3f (1.0f, 1.0f, 1.0f);
                    drawSelectedModel();

                    //Draw back-facing polygons as red lines


                    //Enable color and depth buffers
                    glColorMask (GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
                    glDepthMask (GL_TRUE);

                    //Setup stencil buffer. We don't draw inside the mask
                    glStencilFunc (GL_NOTEQUAL, 1, 0xFFFFFFFF);

                    // Disable lighting for outlining
                    glPushAttrib (GL_LIGHTING_BIT | GL_LINE_BIT | GL_POLYGON_BIT);
                    glDisable (GL_LIGHTING);

                    glEnable (GL_CULL_FACE);

                    glPolygonMode (GL_BACK, GL_LINE);
                    glCullFace (GL_FRONT);

                    glLineWidth (5.0f);

                    // Draw wire object
                    glColor3f (1.0f, 0.0f, 0.0f);
                    drawSelectedModel();

                    // GL_LIGHTING_BIT | GL_LINE_BIT | GL_POLYGON_BIT
                    glPopAttrib ();

                    glDisable (GL_STENCIL_TEST);
                    break;
                }

                case NO_OUTLINE:
                {

                    break;
                }



                default:


                    glEnable(GL_POLYGON_OFFSET_FILL);

                    float line_offset_slope = -1.0f;
                    float line_offset_unit = 0.0f;

                    glPolygonOffset( line_offset_slope, line_offset_unit );
                    glColor3f (1.0f, 1.0f, 1.0f);
                    drawSelectedModel();

                    glDisable( GL_POLYGON_OFFSET_FILL );
                    glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
                    glColor3f (1.0f, 0.0f, 0.0f);
                    drawSelectedModel();




                   break;

                }

            }
        }
    }

    void drawGrid( )
    {
        float divisions = floorSettings->divisions;
        float step      = floorSettings->step;

        if(floorSettings->hideGrid)
        {
            //glDisable(GL_DEPTH_TEST);
            glDisable(GL_LIGHTING);

            glPushMatrix( );

            glColor3f( .3, .3, .3 );

            glLineWidth(1);
            glBegin( GL_LINES );

            for (float i=0;i<divisions+1;i+= 1)
            {
                if(i==0)
                    glColor3f( 0, 0, 1 );
                else
                    glColor3f( .1, .1, .1 );


               float x =  i * step;
               float y =  0;
               float z =  0;


                glVertex3f( x, y,  z  );

                x =  i * step;
                y =  0;
                z =  divisions * step;

                glVertex3f( x, y, z  );
            }

            for (float i=0;i<divisions+1;i+= 1)
            {
                if(i==0)
                    glColor3f( 1, 0, 0 );
                else
                    glColor3f( .1, .1, .1 );


               float x =  0;
               float y =  0;
               float z =  i * step;


                glVertex3f( x, y,  z  );

                x =  divisions * step;
                y =  0;
                z =  i * step;

                glVertex3f( x, y, z  );
            }


            glEnd( );

            glPopMatrix( );

            //glEnable(GL_DEPTH_TEST);
            glEnable(GL_LIGHTING);

        }
    }

    void drawScreenQuad()
    {
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glOrtho(0.0, camera->viewport.width(), 0.0, camera->viewport.height(), -1.0, 1.0);

        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glDisable(GL_LIGHTING);

        glTranslatef(150.0f,0,0);

        glColor3f(1,1,1);
        //glEnable(GL_TEXTURE_2D);
        //glBindTexture(GL_TEXTURE_2D, mark_textures[0].id);


        // Draw a textured quad
        glBegin(GL_QUADS);
        glTexCoord2f(0, 0); glVertex3f(0, 0, 0);
        glTexCoord2f(0, 1); glVertex3f(0, 100, 0);
        glTexCoord2f(1, 1); glVertex3f(100, 100, 0);
        glTexCoord2f(1, 0); glVertex3f(100, 0, 0);
        glEnd();


        //glDisable(GL_TEXTURE_2D);
        glPopMatrix();


        glMatrixMode(GL_PROJECTION);
        glPopMatrix();

        glMatrixMode(GL_MODELVIEW);

    }

    void drawScreenCircle(float radius = 100.0f)
    {
        if(models.size()>0 && currentHit->Selected)
        {
            QVector3D p = models[currentHit->modelID]->position;

            QVector3D sc =  getWorldToScreenCoordinate(p);

            qDebug()<<"QVector3D:"<<sc;

            glPushMatrix();

            glColor3f(0.8f,0.8f,0.0f);

            QSizeF size = camera->viewport;

            glDisable(GL_LIGHTING);

            glPushMatrix();
            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            glOrtho(0.0, size.width(), 0.0, size.height(), -1.0, 1.0);

            glPushMatrix();
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();

            //glTranslatef(250.0f,0.0f,0.0f);
            //glTranslatef(sc.x(),sc.y(),0);


            //glColor3f(0.8f,0.8f,0.0f);

            //glEnable(GL_TEXTURE_2D);
            //glBindTexture(GL_TEXTURE_2D, mark_textures[0].id);

            // Draw a textured quad
            glBegin(GL_LINE_LOOP);

            for(int i =0;i< 90.0f;i++)
            {
                float angle = 2.0f * M_PI * (float)i/90.0f;

                float x = radius*sin(angle);

                float y = radius*cos(angle);

                float z = 0.0f;

                QVector3D p = QVector3D(x,y,z);

                glVertex3f(p.x(),p.y(),p.z());

                //YAxisCircle.append(p);
            }

            glEnd();

            //glDisable(GL_TEXTURE_2D);
            glPopMatrix();
            glMatrixMode(GL_PROJECTION);
            glPopMatrix();
            glMatrixMode(GL_MODELVIEW);

        }

        glEnable(GL_LIGHTING);
    }


    void drawAxis()
    {
        float x = 0,y =0;

        glDisable(GL_LIGHTING);
        glPushMatrix();
        glPushAttrib(GL_SCISSOR_BIT);
        glViewport(x, y, 100,100);
        glScissor(x, y, 100, 100);
        glEnable(GL_SCISSOR_TEST);


        //glClearColor(0.0f,.0f,.0f,1.0f);
        //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
                // Draw a chosen part of ListView here

        glClear(GL_DEPTH_BUFFER_BIT);


        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(camera->fov, 1.0f, 0.1f, 50.0f);

        //glMatrixMode(GL_PROJECTION);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        //QVector3D pos = camera.viewRay.direction*-5.0f;

        //This really has to come from your camera....
        //gluLookAt(pos.x(), pos.y(), pos.z(), 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
        //gluLookAt(0, 0, 5, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

        //camera.orbitView();

        QVector3D dir = camera->position - camera->target;
        dir.normalize();
        QVector3D pos =  dir * -5.0f;

        gluLookAt(pos.x(), pos.y(), pos.z(), 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);



        glRotatef( camera->rotation.x(), 1, 0, 0 );
        glRotatef( camera->rotation.y(), 0, 1, 0 );
        glRotatef( camera->rotation.z(), 0, 0, 1 );

        glScalef(2.5,2.5,2.5);
        //glTranslatef(0,0,0);
        //glTranslatef(camera.position.x(),camera.position.y(),camera.position.x());


        //glColor3f(1.0f, 0.0f, 0.0f);
        //glEnable( GL_LINE_SMOOTH );
        glLineWidth( 1.5 );


        //glColor3ub(255,255,0);
        //glLineWidth(2.0f);
        const float len = 0.5f;

        QVector3D axesOrigin(0.0f,0.0f,0.0f);

        glBegin(GL_LINES);
        glColor3f(1.0f,0.0f,0.0f);
        glVertex3f(axesOrigin.x(),axesOrigin.y(),axesOrigin.z());
        glVertex3f(axesOrigin.x() + len,axesOrigin.y(),axesOrigin.z());

        glColor3f(0.0f,1.0f,0.0f);
        glVertex3f(axesOrigin.x(),axesOrigin.y(),axesOrigin.z());
        glVertex3f(axesOrigin.x(),axesOrigin.y() + len,axesOrigin.z());

        glColor3f(0.0f,0.0f,1.0f);
        glVertex3f(axesOrigin.x(),axesOrigin.y(),axesOrigin.z());
        glVertex3f(axesOrigin.x(),axesOrigin.y(),axesOrigin.z() + len);
        glEnd();

        QFont font;
        font.setBold(true);
        font.setPointSize(11);
        font.setUnderline(true);

        float offset = .05f;

        glColor3f(1.0f,0.0f,0.0f);
        parentWidget->renderText(axesOrigin.x() + len+offset,axesOrigin.y(),axesOrigin.z(),QString("X"),font);
        glColor3f(0.0f,1.0f,0.0f);
        parentWidget->renderText(axesOrigin.x(),axesOrigin.y() + len+offset,axesOrigin.z(),QString("Y"),font);
        glColor3f(0.0f,0.0f,1.0f);
        parentWidget->renderText(axesOrigin.x(),axesOrigin.y(),axesOrigin.z() + len+offset,QString("Z"),font);


        glDisable(GL_SCISSOR_TEST);
        glPopAttrib();

        glPopMatrix();

        glEnable(GL_LIGHTING);


        glViewport(0,0,camera->viewport.width(),camera->viewport.height());
    }

    void drawCornerAxes()
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);

        QVector3D cornerAxesPos = getScreenToWorldCoordinate(75,camera->viewport.height()-75);

        glPushMatrix();

        //gluPerspective(45.0f, 1.0f, 0.1f, 20.0f);


        glTranslatef(cornerAxesPos.x(), cornerAxesPos.y(), cornerAxesPos.z());   // Place axes between clipping planes.

        //glRotatef (camera.rotation.z(), 0,0,1);
        //glRotatef (camera.rotation.y(), 0,1,0);
        //glRotatef (camera.rotation.x(), 1,0,0);

        glScalef(.0005,.0005,.0005);

        drawTranslationGizmo(false);

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

        glPopMatrix();
    }

    void drawSelectedModel()
    {
        if(models.size()>0 && models.isEmpty() == false && currentHit->Selected)
        {
            currentHit->selectedModel->drawModel();

            //*
            //if(models[currentHit->modelID]->Selected)
            //{
              // models[currentHit->modelID]->draw();
            //}
            //*/
        }
    }

    void raySelectModel()
    {
        QPoint  p = QCursor::pos();

        if(parentWidget)
        {
            p = parentWidget->mapFromGlobal(QCursor::pos());
        }

        QRay ray;

        ray.rayCastScene(p.x(),p.y());

        if( models.size()>0 )
        {
            //hits.clear();

            for(int i =0;i<models.size();i++)
            {
                QAabb box    =  models[i]->boundingAabbox;

                QVector3D v  =  models[i]->position;

                QVector3D r  =  models[i]->rotation;

                //QVector3D s  =  models[i]->scale;

                //box.reScale(1.0f);

                box.translate(v);

                box.rotate(r);


                if(box.intersectRay(ray.p0,ray.direction))
                {
                    models[i]->Selected =  true;

                    QHitInfo *hit = new QHitInfo;

                    hit->modelID =  models[i]->ID;

                    hit->Selected = true;

                    hit->selectedModel = models[i];

                    currentHit = hit;

                    break;
                }
            }
        }
    }


    void drawModels()
    {
        if(models.isEmpty()==false)
        {
            for(int i =0;i<models.size();i++)
            {
                models[i]->drawModel();
            }
        }
    }

    void drawTranslationGizmo(bool drawarrows = true)
    {
        if(drawarrows)
        {
            QArrow arrow;

            arrow.drawArrow(XY);
            arrow.drawArrow(ZX);
            arrow.drawArrow(YZ);
        }

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);

        glLineWidth(2);

        glBegin(GL_LINES);

        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(1.0f, 0.0f, 0.0f);

        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 1.0f, 0.0f);

        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 1.0f);

        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr("X");
        QString ystr("Y");
        QString zstr("Z");

        QFont font;
        font.setBold(true);
        font.setPointSize(11);
        font.setUnderline(true);

        glColor3f(1.0f, 0.0f, 0.0f);
        parentWidget->renderText(1.3f, 0.0f, 0.0f,xstr,font);

        glColor3f(0.0f, 1.0f, 0.0f);
        parentWidget->renderText(0.0f, 1.3f, 0.0f,ystr,font);

        glColor3f(0.0f, 0.0f, 1.0f);
        parentWidget->renderText(0.0f, 0.0f, 1.3f,zstr,font);

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }



    void drawToolTip( QString tipstr,QPoint p = QCursor::pos())
    {
        if(tipstr.size()==0)
        {
            tipstr = QString("<b>QToolTip</b> Example:\n"
                    "Create N points on a sphere\n "
                    "aproximately equi-distant from each other\n"
                    "Basically, N points are randomly\n "
                    "placed on the sphere and then moved\n"
                    "around until then moved around \n"
                    "until the minimal distance between the\n"
                    "closed two points is minimaised.\n");
        }

        if(QRect(QPoint(0,0),camera->viewport.toSize()).contains(p,true))
        {
            QToolTip::showText(p,tipstr,parentWidget,QRect(p,QSize(100,120)));
        }
    }


    qreal c  = (qreal)76/255;
    qreal c1 = (qreal)199/255;

    void drawScene()
    {
#ifndef GL_MULTISAMPLE
#define GL_MULTISAMPLE  0x809D
#endif
        glEnable(GL_MULTISAMPLE);


        QColor m_backgroundColor(102, 102, 102);

        glViewport (0, 0, (GLsizei) camera->viewport.width(), (GLsizei) camera->viewport.height());

        //glClearColor(0.5f, 0.6f, 0.7f, 1.0f);
        //glClearColor(0.7f, 0.7f, 0.7f, 1.0f);
        //glClearColor(m_backgroundColor.redF(), m_backgroundColor.greenF(), m_backgroundColor.blueF(), 1.0f);

        glClearColor(c1,c1,c1,1.0f);

        //glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);


        camera->orbitView();

        drawGrid();

        drawOutlineSelected();

        drawModels();

        axesTransformer->drawGizmo(parentWidget);

        //drawToolTip(axesTransformer->feedBack);

        //drawCornerAxes();

        drawAxis();

        //drawScreenQuad();
        //drawScreenCircle();

        camera->orbitView();//restore camera transforms

    }

    //keyboard event

    virtual void processAddModelMenu(QKeyEvent * event)
    {
        if(event->modifiers()&Qt::ShiftModifier &&  event->key()==Qt::Key_A)
        {
            qDebug()<<"Main menu";

            QPoint p = QCursor::pos();

            //p += QPoint(-50,-10);

            mainContextmenu.move(p);

            mainContextmenu.show();

            QAction *selectedAction = mainContextmenu.exec();

            if ( selectedAction != 0)
            {
               //if(_debug)
               //printf("Clicked Action:\n");
               qDebug()<<"Clicked Action:\n"<<selectedAction->text();

               //allnodes.indexOf(selectedAction->text())

               addModel(selectedAction->text());

               printf(qPrintable(selectedAction->text()));


            }
        }
    }

    virtual void duplicateSelelctedModel(QKeyEvent * event)
    {
        if(event->modifiers() & Qt::ShiftModifier &&   event->key() == Qt::Key_D)
        {
            duplicateModel();
        }
    }

    virtual void selectModel(QMouseEvent *event)
    {
        if(event->buttons() & Qt::LeftButton )//&& event->modifiers() & Qt::ControlModifier )
        {
            raySelectModel();
        }
    }

    virtual void selectModel(QKeyEvent * event)
    {
        if(event->key()== Qt::Key_G)
        {
            raySelectModel();
        }
    }

    virtual void setPerspectiveMode(QKeyEvent * event)
    {
        if(event->key()==Qt::Key_P)
        {
            camera->PerspectiveMode = QCameraModel::PERSPECTIVE;

            printf("Perspective projection \n");
        }

        if(event->key()==Qt::Key_O)
        {
           camera->PerspectiveMode= QCameraModel::ORTHO;

            printf("Ortho projection \n");
        }

    }

    //--------------------------------------------------------

    virtual void mousePressEvents(QMouseEvent *event)
    {
        selectModel(event);

        lastPos = event->pos();

        //axesTransformer->computeGizimo(models,lastPos,currentHit);

    }

    virtual void mouseMoveEvents(QMouseEvent *event)
    {
        QPoint delta = event->pos() - lastPos;

        camera->cameraNavigation(event,delta);

        axesTransformer->getGizmoTransforms( event,delta);

    }

    virtual void mouseReleaseEvents(QMouseEvent *event)
    {
        lastPos = event->pos();

        axesTransformer->gizmoRelease();
    }

    virtual void keyPressEvents(QKeyEvent *event)
    {
        camera->switchCameraView(event);

        axesTransformer->setAxisTransformMode(event);

        axesTransformer->setTransformMode(event);

        setPerspectiveMode(event);
        processAddModelMenu(event);
        selectModel(event);
        deleteSelectedModel(event);
        duplicateSelelctedModel(event);

    }


public slots:

    virtual void deleteSelectedModel(QKeyEvent * event)
    {
        if(event->key()== Qt::Key_Delete)
        {
            /*
            QBaseModel  *a = new QSphereModel();
            QBaseModel  *b = new QSphereModel();
            QBaseModel  *c = new QSphereModel();

            QHash<int,QBaseModel* > hash;

            hash.insert(0,a);
            hash.insert(1,b);
            hash.insert(2,c);

            delete hash.take(1);

            //hash.remove(1);

            qDebug()<<"Model COunt:"<<hash.count();

            */
            if(currentHit->Selected )
            {
                qDebug()<<"Model Index"<<currentHit->modelID;
                //delete models.take(currentHit->modelID);

                //delete models.take(currentHit->modelID);



                //models.remove(currentHit->modelID);


                //currentHit->Selected =  false;


                qDebug()<<"Model Count:"<<models.count();

            }
        }
    }

private slots:

    void setModalsMenues()
    {
        foreach(QString nodename,modelsList)
        {
            if(nodename.contains("Sphere",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addSphereModel()));

            }
            else if(nodename.contains("Mesh",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addMeshModel()));

            }
            else if(nodename.contains("Quad",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addQuadModel()));

            }
            else if(nodename.contains("Plane",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addPlaneModel()));

            }
            else if(nodename.contains("Cone",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addConeModel()));

            }
            else if(nodename.contains("Cylinder",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addCylinderModel()));

            }
            else if(nodename.contains("Torus",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addTorusModel()));

            }
            else if(nodename.contains("Cube",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addCubeModel()));

            }
            else if(nodename.contains("Light",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addLightModel()));

            }
            else if(nodename.contains("Ivy",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addIvyModel()));

            }
            else if(nodename.contains("Camera",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addCameraModel()));


            }
            else if(nodename.contains("Particles",Qt::CaseInsensitive))
            {
                addModelsMenu.addAction(icon,nodename,this,SLOT(addParticlesModel()));
            }

            allnodes.append(nodename);
        }
    }

    void addMeshModel()
    {
       QMeshModel *model=  new QMeshModel;

       models.append(model);
    }

    void addQuadModel()
    {
       QQuadModel * model =  new QQuadModel;

       models.append(model);
    }

    void addCylinderModel()
    {
       QCylinderModel *model =  new QCylinderModel;

       models.append(model);
    }

    void addSphereModel()
    {
       QSphereModel* model =  new QSphereModel;

       models.append(model);
    }

    void addCubeModel()
    {
       QCubeModel *model=  new QCubeModel;

       models.append(model);
    }

    void addTorusModel()
    {
       QTorusModel* model =  new QTorusModel;

       models.append(model);
    }

    void addPlaneModel()
    {
       QPlaneModel *model =  new QPlaneModel;

       models.append(model);
    }

    void addCameraModel()
    {
       QCameraModel *model=  new QCameraModel;

       models.append(model);
    }

    void addConeModel()
    {
       QConeModel *model =  new QConeModel;

       models.append(model);
    }

    void addLightModel()
    {
       QLightModel *model =  new QLightModel;

       models.append(model);
    }

    void addIvyModel()
    {
       //QIvyModel *model =  new QIvyModel;

       //models.append(model);
    }

    void addParticlesModel()
    {
       QParticlesModel* model =  new QParticlesModel;

       models.append(model);
    }






};




#endif // SCENE_HPP


#ifndef HANDLES_HPP
#define HANDLES_HPP

#include<QtWidgets>
#include<geometry.hpp>
#include<models.hpp>

class QHitInfo
{
public:

    bool Selected;

    QBaseModel * selectedModel;

    int modelID;

    QHitInfo()
    {
        modelID = 0;
        Selected = false;
    }


};


class HandleController : public QObject
{
    Q_OBJECT

public:
    HandleController() { }

    enum SCREEN_SPACE
    {
        LOCATE_VIEW,
        LOCATE_WORLD,
        LOCATE_LOCAL,
    };

    QTransformMode TransformMode;

    QTrans PlaneAXesMode;


    bool mousePressed;


    QAabb Xbox;
    QAabb Ybox;
    QAabb Zbox;

    QAabb XZbox;
    QAabb YZbox;
    QAabb XYbox;

    QAabb SCREENbox;

    QList<QBaseModel *> models;
    //QHash<int ,QBaseModel*>models;

    QHitInfo * currentHit;

    QVector3D prevhitpoint;
    QVector3D alternateCenter;

    QVector3D position;
    QVector3D rotation;
    QVector3D scale;



    virtual void setTransformMode( QTransformMode & TransformMode)
    {
        this->TransformMode =  TransformMode;
    }

    virtual void setTransPlaneAxes( QTrans & PlaneAXesMode)
    {
        this->PlaneAXesMode =  PlaneAXesMode;
    }

    virtual void setModelsList( QList<QBaseModel *> & models)
    {
        this->models = models;
    }

    virtual void setHitInfo( QHitInfo * currentHit)
    {
        this->currentHit = currentHit;
    }

    virtual void rayPlaneIntersection(int x, int y)
    {

    }

    virtual void rayBoxAXesIntersection(int x, int y)
    {

    }

    virtual void rayPlaneIntersection(QPoint delta)
    {

    }

    virtual void drawSelectionQAaBB()
    {

    }

    virtual void screenfactorScale()
    {

    }

    virtual void drawGizmo(QGLWidget* widget)
    {

        if(models.size()>0 && currentHit)
        {
            if(models.size()>0 && models[currentHit->modelID]->Selected)
            {
                QVector3D v = models[currentHit->modelID]->position;
                QVector3D s = models[currentHit->modelID]->scale;
                QVector3D r = models[currentHit->modelID]->rotation;

                glDisable(GL_DEPTH_TEST);
                glDisable(GL_LIGHTING);

                glPushMatrix( );

                glTranslatef( v.x(), v.y(), v.z() );

                glRotatef(r.x(),1,0,0);
                glRotatef(r.y(),0,1,0);
                glRotatef(r.z(),0,0,1);

                //glScalef( s.x, s.y, s.z );
                glScalef( 1, 1, 1 );

                glBegin(GL_POINTS);

                glVertex3f(0,0,0);

                glEnd();

                glPopMatrix();

                glColor3f( .3, .3, .3 );
                QString str("Pos:(");

                str += QString::number(v.x());str +=QString(",");
                str += QString::number(v.y());str +=QString(",");
                str += QString::number(v.z());str +=QString(")");

                widget->renderText(v.x()-1,v.y(),v.z(),str);

                glEnable(GL_DEPTH_TEST);
                glEnable(GL_LIGHTING);
            }
        }
    }
};

class HandleMoveController : public HandleController
{
public:

    QList<QPlane> axesplanes;

    QList<QVector3D> vertices;


    QPlane XPlane;
    QPlane YPlane;
    QPlane ZPlane;

    QPlane XZPlane;
    QPlane YZPlane;
    QPlane XYPlane;

    QPlane SCREENPlane;

    HandleMoveController()
    {

        //----------------------------
        //
        //           Y v2(0,1,0)
        //           |
        //           |   plane-XY
        // plane-YZ  |
        //           v0 --------  X v1(1,0,0)
        //          /
        //         /    plane-ZX
        //        /
        //       Z  v3(0,1,0)
        //
        //----------------------------


        QVector3D v0 = QVector3D(0,0,0);

        QVector3D v1 = QVector3D(1,0,0);
        QVector3D v2 = QVector3D(0,1,0);
        QVector3D v3 = QVector3D(0,0,1);

        vertices.append(v0);
        vertices.append(v1);
        vertices.append(v2);
        vertices.append(v3);



        //-----------------------------
        XPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v1,v1+QVector3D(0.05,.05,0.05));
        XPlane.axesAlignment = X;

        //-----------------------------
        YPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v2,v2+QVector3D(0.05,.05,0.05));
        YPlane.axesAlignment = Y;

        //-----------------------------
        ZPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v3,v3+QVector3D(0.05,0.05,0.05));
        ZPlane.axesAlignment = Z;

        v0 = QVector3D(0,0,0);

        v1 = QVector3D(0.7,0,0);
        v2 = QVector3D(0,0.7,0);
        v3 = QVector3D(0,0,0.7);


        //-----------------------------
        XZPlane = QPlane(v0,v1,v3);
        XZPlane.axesAlignment = ZX;

        //-----------------------------
        YZPlane = QPlane(v0,v2,v3);
        YZPlane.axesAlignment = YZ;

        //-----------------------------
        XYPlane = QPlane(v0,v1,v2);
        XYPlane.axesAlignment = XY;

        //-----------------------------
        SCREENPlane = QPlane(v0,v1,v2);
        SCREENPlane.axesAlignment  = SCREEN;

        //-----------------------------


        axesplanes.append(XZPlane);
        axesplanes.append(YZPlane);
        axesplanes.append(XYPlane);

        axesplanes.append(SCREENPlane);

        //--------------------------------------


        foreach(QVector3D v,XPlane.vertices)
        {
            Xbox.expand(v);
        }

        //--------------------------------------


        foreach(QVector3D v,YPlane.vertices)
        {
            Ybox.expand(v);
        }

        //--------------------------------------


        foreach(QVector3D v,ZPlane.vertices)
        {
            Zbox.expand(v);
        }

        //--------------------------------------



        foreach(QVector3D v,XZPlane.vertices)
        {
            XZbox.expand(v);
        }
        XZbox.expand(v0+QVector3D(0,0.005,0));

        //--------------------------------------


        foreach(QVector3D v,YZPlane.vertices)
        {
            YZbox.expand(v);
        }
        YZbox.expand(v0+QVector3D(0.005,0,0));

        //--------------------------------------



        foreach(QVector3D v,XYPlane.vertices)
        {
            XYbox.expand(v);
        }
        XYbox.expand(v0+QVector3D(0,0,0.005));


        //--------------------------------------

        //foreach(QVector3D v,SCREENPlane.vertices)
        //{
            //SCREENbox.expand(v);
        //}

        SCREENbox =  QAabb(QVector3D(-0.5,-0.5,-0.5),QVector3D(0.5,0.5,0.5));



        XZbox.reScale();
        XYbox.reScale();
        YZbox.reScale();
    }

    void drawTranslationGizmo(QGLWidget* widget, bool drawarrows = true)
    {
        QArrow arrow;

        if(drawarrows)
        {
            arrow.drawArrow(XY);
            arrow.drawArrow(ZX);
            arrow.drawArrow(YZ);
        }

        if(axesplanes.size() >0)
        {
            for(int i =0;i<axesplanes.size();i++)
            {
                //axesplanes[i].drawPlane();
            }
        }

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);

        glLineWidth(2);

        glBegin(GL_LINES);
        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3f(vertices[0].x(),vertices[0].y(),vertices[0].z());
        glVertex3f(vertices[1].x(),vertices[1].y(),vertices[1].z());

        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3f(vertices[0].x(),vertices[0].y(),vertices[0].z());
        glVertex3f(vertices[2].x(),vertices[2].y(),vertices[2].z());

        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3f(vertices[0].x(),vertices[0].y(),vertices[0].z());
        glVertex3f(vertices[3].x(),vertices[3].y(),vertices[3].z());
        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr("X");
        QString ystr("Y");
        QString zstr("Z");

        QFont font;
        font.setBold(true);
        font.setPointSize(11);
        font.setUnderline(true);

        glColor3f(1.0f, 0.0f, 0.0f);
        widget->renderText(1.3f, 0.0f, 0.0f,xstr,font);

        glColor3f(0.0f, 1.0f, 0.0f);
        widget->renderText(0.0f, 1.3f, 0.0f,ystr,font);

        glColor3f(0.0f, 0.0f, 1.0f);
        widget->renderText(0.0f, 0.0f, 1.3f,zstr,font);

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }


    //----- Ray plane intersection--------------------------
    void rayPlaneIntersection(int x,int y)
    {
        if(models.size()>0 && models[currentHit->modelID]->Selected)
        {
            QVector3D v = models[currentHit->modelID]->position;

            QRay view;
            QPlane plane;

            QVector3D hitPoint;

            view.rayCastScene(x,y);

            plane.center = v;

            plane.axesAlignment = PlaneAXesMode;

            if(PlaneAXesMode==X)
            {
                plane.normal = QVector3D(0,0,1);
            }

            if(PlaneAXesMode==Y)
            {
                plane.normal = QVector3D(0,0,1);
            }

            if(PlaneAXesMode==Z)
            {
                plane.normal = QVector3D(0,1,0);
            }


            if(PlaneAXesMode==ZX)
            {
                plane.normal = QVector3D(0,1,0);
            }

            if(PlaneAXesMode==XY)
            {
                plane.normal = QVector3D(0,0,1);
            }

            if(PlaneAXesMode==YZ)
            {
                plane.normal = QVector3D(1,0,0);
            }

            if(PlaneAXesMode==SCREEN)
            {
                plane.normal = (-1.0f * view.direction);
            }

            hitPoint = view.getRayPlaneIntersection(plane);

            if(view.hitStatus == 1)
            {
                //printf("Plane Intersection x:%f,y:%f,z:%f \n",hitPoint.x,hitPoint.y,hitPoint.z);

                QVector3D prev = models[currentHit->modelID]->position;


                //prev = alternateCenter - prev;

                if(PlaneAXesMode==X)
                {
                    models[currentHit->modelID]->position = QVector3D(hitPoint.x(),prev.y(),prev.z());
                }

                if(PlaneAXesMode==Y)
                {
                    models[currentHit->modelID]->position = QVector3D(prev.x(),hitPoint.y(),prev.z());
                }

                if(PlaneAXesMode==Z)
                {
                    models[currentHit->modelID]->position = QVector3D(prev.x(),prev.y(),hitPoint.z());
                }

                if(PlaneAXesMode==ZX||PlaneAXesMode==XY||PlaneAXesMode==YZ||PlaneAXesMode ==SCREEN)
                {
                    models[currentHit->modelID]->position = hitPoint;
                }
            }
        }
    }


    void rayBoxAXesIntersection(int x, int y)
    {
        if(models.size()>0 && models[currentHit->modelID]->Selected)
        {
            QVector3D v = models[currentHit->modelID]->position;
            QVector3D r = models[currentHit->modelID]->rotation;

            QRay view;

            QAabb box;

            view.rayCastScene(x,y);

            // intersect X-axis
            box = Xbox;
            box.translate(v);
            box.rotate(r);


            bool  intersected = box.intersectRay(view.p0,view.direction);

            if(intersected)
            {
                //Xbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = X;
                qDebug()<<"Axes: X"<<intersected;

                alternateCenter = box.center;
                return;
            }

            // intersect Y-axis
            box = Ybox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Ybox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Y;
                qDebug()<<"Axes: Y"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect Z-axis
            box =  Zbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Zbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Z;
                qDebug()<<"Axes: Z"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect XZ-plane
            box = XZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = ZX;
                qDebug()<<"Axes: ZX"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect YZ-plane
            box = YZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //YZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = YZ;
                qDebug()<<"Axes: YZ"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect XY-plane
            box = XYbox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XYbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = XY;
                qDebug()<<"Axes: XY"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect SCREEN-plane
            box = SCREENbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //SCREENbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = SCREEN;
                qDebug()<<"Axes: SCREEN"<<intersected;
                alternateCenter = box.center;
                return;
            }


            if(intersected)
            {

            }
            else
            {
                 //PlaneAXesMode = XYZ_NONE;
            }
        }
    }


    void drawGizmo(QGLWidget* widget)
    {
        if(models.size()>0)
        {
            if(models.size()>0 && models[currentHit->modelID]->Selected)
            {
                QVector3D v = models[currentHit->modelID]->position;
                QVector3D s = models[currentHit->modelID]->scale;
                QVector3D r = models[currentHit->modelID]->rotation;

                glDisable(GL_DEPTH_TEST);
                glDisable(GL_LIGHTING);

                glPushMatrix( );

                glTranslatef( v.x(), v.y(), v.z() );

                glRotatef(r.x(),1,0,0);
                glRotatef(r.y(),0,1,0);
                glRotatef(r.z(),0,0,1);

                //glScalef( s.x, s.y, s.z );
                glScalef( 1, 1, 1 );

                glBegin(GL_POINTS);

                glVertex3f(0,0,0);

                glEnd();

                if( TransformMode ==MOVE)
                {
                    drawTranslationGizmo(widget);

                    drawSelectionQAaBB();
                }

                glPopMatrix();



                glColor3f( .1, .1, .1 );
                QString str("Pos:(");

                str += QString::number(v.x());str +=QString(",");
                str += QString::number(v.y());str +=QString(",");
                str += QString::number(v.z());str +=QString(")");

                widget->renderText(v.x()-1,v.y(),v.z(),str);

                glEnable(GL_DEPTH_TEST);
                glEnable(GL_LIGHTING);
            }
        }

    }


    void drawSelectionQAaBB()
    {
        glDisable(GL_DEPTH_TEST);
        if(mousePressed)
        {
            if(PlaneAXesMode ==X)
            {
                this->Xbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==Z)
            {
                this->Zbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==Y)
            {
                this->Ybox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==XY)
            {
                this->XYbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==ZX)
            {
                this->XZbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==YZ)
            {
                this->YZbox.draw(Qt::cyan);
            }
            else if(PlaneAXesMode ==SCREEN)
            {
                this->SCREENbox.draw(Qt::cyan);
            }
        }
        else
        {
            this->Xbox.draw(Qt::cyan);
            this->Zbox.draw(Qt::cyan);
            this->Ybox.draw(Qt::cyan);

            this->XYbox.draw(Qt::cyan);
            this->XZbox.draw(Qt::cyan);
            this->YZbox.draw(Qt::cyan);

            this->SCREENbox.draw(Qt::cyan);
        }

        glEnable(GL_DEPTH_TEST);
    }


};

class HandleScaleController : public HandleController
{
public:

    QList<QPlane> axesplanes;

    QList<QVector3D> vertices;


    QPlane XPlane;
    QPlane YPlane;
    QPlane ZPlane;

    QPlane XZPlane;
    QPlane YZPlane;
    QPlane XYPlane;

    QPlane SCREENPlane;

    HandleScaleController()
    {

        //----------------------------
        //
        //           Y v2(0,1,0)
        //           |
        //           |   plane-XY
        // plane-YZ  |
        //           v0 --------  X v1(1,0,0)
        //          /
        //         /    plane-ZX
        //        /
        //       Z  v3(0,1,0)
        //
        //----------------------------


        QVector3D v0 = QVector3D(0,0,0);

        QVector3D v1 = QVector3D(1,0,0);
        QVector3D v2 = QVector3D(0,1,0);
        QVector3D v3 = QVector3D(0,0,1);

        vertices.append(v0);
        vertices.append(v1);
        vertices.append(v2);
        vertices.append(v3);



        //-----------------------------
        XPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v1,v1+QVector3D(0.05,.05,0.05));
        XPlane.axesAlignment = X;

        //-----------------------------
        YPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v2,v2+QVector3D(0.05,.05,0.05));
        YPlane.axesAlignment = Y;

        //-----------------------------
        ZPlane = QPlane(v0+QVector3D(-0.05,-0.05,-0.05),v3,v3+QVector3D(0.05,0.05,0.05));
        ZPlane.axesAlignment = Z;

        v0 = QVector3D(0,0,0);

        v1 = QVector3D(0.7,0,0);
        v2 = QVector3D(0,0.7,0);
        v3 = QVector3D(0,0,0.7);


        //-----------------------------
        XZPlane = QPlane(v0,v1,v3);
        XZPlane.axesAlignment = ZX;

        //-----------------------------
        YZPlane = QPlane(v0,v2,v3);
        YZPlane.axesAlignment = YZ;

        //-----------------------------
        XYPlane = QPlane(v0,v1,v2);
        XYPlane.axesAlignment = XY;

        //-----------------------------
        SCREENPlane = QPlane(v0,v1,v2);
        SCREENPlane.axesAlignment  = SCREEN;

        //-----------------------------


        axesplanes.append(XZPlane);
        axesplanes.append(YZPlane);
        axesplanes.append(XYPlane);

        axesplanes.append(SCREENPlane);

        //--------------------------------------


        foreach(QVector3D v,XPlane.vertices)
        {
            Xbox.expand(v);
        }

        //--------------------------------------


        foreach(QVector3D v,YPlane.vertices)
        {
            Ybox.expand(v);
        }

        //--------------------------------------


        foreach(QVector3D v,ZPlane.vertices)
        {
            Zbox.expand(v);
        }

        //--------------------------------------



        foreach(QVector3D v,XZPlane.vertices)
        {
            XZbox.expand(v);
        }
        XZbox.expand(v0+QVector3D(0,0.005,0));

        //--------------------------------------


        foreach(QVector3D v,YZPlane.vertices)
        {
            YZbox.expand(v);
        }
        YZbox.expand(v0+QVector3D(0.005,0,0));

        //--------------------------------------



        foreach(QVector3D v,XYPlane.vertices)
        {
            XYbox.expand(v);
        }
        XYbox.expand(v0+QVector3D(0,0,0.005));


        //--------------------------------------

        //foreach(QVector3D v,SCREENPlane.vertices)
        //{
            //SCREENbox.expand(v);
        //}

        SCREENbox =  QAabb(QVector3D(-.5,-.5,-.5),QVector3D(0.5,0.5,0.5));



        XZbox.reScale();
        XYbox.reScale();
        YZbox.reScale();

    }

    void drawScaleGizmo(QGLWidget* widget)
    {
        //sdisk.drawDisk(true,ZX);
        //sdisk.drawDisk(true,XY);
        //sdisk.drawDisk(true,YZ);

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glLineWidth(2);


        glBegin(GL_LINES);
            glColor3f(1.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(1.0f, 0.0f, 0.0f);

            glColor3f(0.0f, 1.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 1.0f, 0.0f);

            glColor3f(0.0f, 0.0f, 1.0f);
            glVertex3f(0.0f, 0.0f, 0.0f);
            glVertex3f(0.0f, 0.0f, 1.0f);
        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr(" X");
        QString ystr(" Y");
        QString zstr(" Z");

        QFont font;
        font.setPointSize(15);

        glColor3f(1.0f, 0.0f, 0.0f);
        widget->renderText(1.0f, 0.0f, 0.0f,xstr,font);
        glColor3f(0.0f, 1.0f, 0.0f);
        widget->renderText(0.0f, 1.0f, 0.0f,ystr,font);
        glColor3f(0.0f, 0.0f, 1.0f);
        widget->renderText(0.0f, 0.0f, 1.0f,zstr,font);


        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }




    //----- Ray plane intersection--------------------------

    void rayPlaneIntersection(QPoint delta)
    {
        if(models.size()>0 && models[currentHit->modelID]->Selected)
        {

            QVector3D v = models[currentHit->modelID]->position;

            QPoint p = QCursor::pos();
            QRay view;
            view.rayCastScene(p.x(),p.y());

            QPlane plane;
            plane.center = v;
            plane.axesAlignment = PlaneAXesMode;


            if(PlaneAXesMode==X)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = X;
            }

            if(PlaneAXesMode==Y)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = Y;
            }

            if(PlaneAXesMode==Z)
            {
                plane.normal = QVector3D(0,1,0);
                plane.axesAlignment = Z;
            }


            if(PlaneAXesMode==ZX)
            {
                plane.normal = QVector3D(0,1,0);
                plane.axesAlignment = ZX;
            }

            if(PlaneAXesMode==XY)
            {
                plane.normal = QVector3D(0,0,1);
                plane.axesAlignment = XY;
            }

            if(PlaneAXesMode==YZ)
            {
                plane.normal = QVector3D(1,0,0);
                plane.axesAlignment = YZ;
            }

            if(PlaneAXesMode==SCREEN || PlaneAXesMode==UNIFORM)
            {
                plane.normal = (-1.0f*view.direction);
                plane.axesAlignment = SCREEN;
            }

            QVector3D pScale = models[currentHit->modelID]->scale;

            float scale  = QVector2D(delta.x(),delta.y()).length();

            float sign;

            if(delta.x() ==0)
            {
            }
            else
            {
                sign =  (float)delta.x()/fabs((float)delta.x());
            }

            scale *= 0.01f;
            scale *= sign;

            qDebug()<<"Delta Scale:"<<scale<<"sign:"<<sign;

            if(PlaneAXesMode==X)
            {
                models[currentHit->modelID]->scale = pScale + QVector3D(1,0,0) *scale;
            }

            if(PlaneAXesMode==Y)
            {
                models[currentHit->modelID]->scale = pScale + QVector3D(0,1,0)  *scale;
            }

            if(PlaneAXesMode==Z)
            {
                models[currentHit->modelID]->scale = pScale + QVector3D(0,0,1)  *scale;
            }

            if(PlaneAXesMode==ZX)
            {
                models[currentHit->modelID]->scale = pScale + QVector3D(1,0,1)  *scale;
            }

            if(PlaneAXesMode==XY)
            {
                models[currentHit->modelID]->scale = pScale + QVector3D(1,1,0)  *scale;
            }

            if(PlaneAXesMode==YZ)
            {
                models[currentHit->modelID]->scale = pScale + QVector3D(0,1,1)  *scale;
            }

            if(PlaneAXesMode ==SCREEN)
            {
                QVector3D viewDirection = (-1.0f*view.direction);

                models[currentHit->modelID]->scale = pScale + viewDirection *scale;
            }

            if(PlaneAXesMode ==UNIFORM)
            {
               models[currentHit->modelID]->scale =  pScale + QVector3D(1,1,1)  *scale;

            }

            models[currentHit->modelID]->computeBounds();
        }
    }

    void rayBoxAXesIntersection(int x, int y)
    {
        if(models.size()>0 && models[currentHit->modelID]->Selected)
        {
            QVector3D v = models[currentHit->modelID]->position;
            QVector3D r = models[currentHit->modelID]->rotation;

            QRay view;

            QAabb box;

            view.rayCastScene(x,y);

            // intersect X-axis
            box = Xbox;
            box.translate(v);
            box.rotate(r);
            bool  intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Xbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = X;
                qDebug()<<"Axes: X"<<intersected;

                alternateCenter = box.center;
                return;
            }

            // intersect Y-axis
            box = Ybox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Ybox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Y;
                qDebug()<<"Axes: Y"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect Z-axis
            box =  Zbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //Zbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = Z;
                qDebug()<<"Axes: Z"<<intersected;
                alternateCenter = box.center;
                return;
            }


            // intersect XZ-plane
            box = XZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = ZX;
                qDebug()<<"Axes: ZX"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect YZ-plane
            box = YZbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //YZbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = YZ;
                qDebug()<<"Axes: YZ"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect XY-plane
            box = XYbox;

            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //XYbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = XY;
                qDebug()<<"Axes: XY"<<intersected;
                alternateCenter = box.center;
                return;
            }

            // intersect SCREEN-plane
            box = SCREENbox;
            box.translate(v);
            box.rotate(r);
            intersected = box.intersectRay(view.p0,view.direction);
            if(intersected)
            {
                //SCREENbox.draw(QColor(.2,.5,.7));
                PlaneAXesMode = SCREEN;
                qDebug()<<"Axes: SCREEN"<<intersected;
                alternateCenter = box.center;
                return;
            }


            if(intersected)
            {

            }
            else
            {
                 //PlaneAXesMode = XYZ_NONE;
            }
        }
    }



    void drawGizmo(QGLWidget* widget)
    {
        if(models.size()>0)
        {
            if(models.size()>0 && models[currentHit->modelID]->Selected)
            {
                QVector3D v = models[currentHit->modelID]->position;
                QVector3D s = models[currentHit->modelID]->scale;
                QVector3D r = models[currentHit->modelID]->rotation;

                glDisable(GL_DEPTH_TEST);
                glDisable(GL_LIGHTING);

                glPushMatrix( );

                glTranslatef( v.x(), v.y(), v.z() );

                glRotatef(r.x(),1,0,0);
                glRotatef(r.y(),0,1,0);
                glRotatef(r.z(),0,0,1);

                //glScalef( s.x, s.y, s.z );
                glScalef( 1, 1, 1 );

                glBegin(GL_POINTS);

                glVertex3f(0,0,0);

                glEnd();

                if( TransformMode ==SCALE)
                {
                    drawScaleGizmo(widget);
                    drawSelectionQAaBB();
                }

                glPopMatrix();

                glColor3f( .3, .3, .3 );
                QString str("Pos:(");

                str += QString::number(v.x());str +=QString(",");
                str += QString::number(v.y());str +=QString(",");
                str += QString::number(v.z());str +=QString(")");

                widget->renderText(v.x()-1,v.y(),v.z(),str);

                glEnable(GL_DEPTH_TEST);
                glEnable(GL_LIGHTING);
            }
        }
    }

    void drawSelectionQAaBB()
    {
        glDisable(GL_DEPTH_TEST);
        if(mousePressed)
        {
            if(PlaneAXesMode ==X)
            {
                this->Xbox.draw(Qt::green);
            }
            else if(PlaneAXesMode ==Z)
            {
                this->Zbox.draw(Qt::green);
            }
            else if(PlaneAXesMode ==Y)
            {
                this->Ybox.draw(Qt::green);
            }
            else if(PlaneAXesMode ==XY)
            {
                this->XYbox.draw(Qt::green);
            }
            else if(PlaneAXesMode ==ZX)
            {
                this->XZbox.draw(Qt::green);
            }
            else if(PlaneAXesMode ==YZ)
            {
                this->YZbox.draw(Qt::green);
            }
            else if(PlaneAXesMode ==SCREEN)
            {
                this->SCREENbox.draw(Qt::green);
            }
        }
        else
        {
            this->Xbox.draw(Qt::green);
            this->Zbox.draw(Qt::green);
            this->Ybox.draw(Qt::green);

            this->XYbox.draw(Qt::green);
            this->XZbox.draw(Qt::green);
            this->YZbox.draw(Qt::green);

            this->SCREENbox.draw(Qt::green);
        }

        glEnable(GL_DEPTH_TEST);
    }


};

class HandleRotationController : public HandleController
{
public:

    QList<QVector3D>YAxisCircle;
    QList<QVector3D>XAxisCircle;
    QList<QVector3D>ZAxisCircle;

    //QList<QVector3D>SCREENCircle;

    HandleRotationController()
    {
        mousePressed = false;

        float Count = 90.0f;

        float radius = 1.0f;

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f* M_PI* (float)i/Count;

            float x = radius*sin(angle);
            float y = 0;
            float z = radius*cos(angle);

            QVector3D p = QVector3D(x,y,z);

            YAxisCircle.append(p);
        }

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f * M_PI* (float)i/Count;

            float x = 0;
            float y = radius*sin(angle);
            float z = radius*cos(angle);

            QVector3D p = QVector3D(x,y,z);

            XAxisCircle.append(p);
        }

        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f * M_PI* (float)i/Count;

            float x = radius*cos(angle);
            float y = radius*sin(angle);
            float z = 0;

            QVector3D p = QVector3D(x,y,z);

            ZAxisCircle.append(p);
        }

        /*



        for(int i =0;i< Count;i++)
        {
            float angle = 2.0f* M_PI* (float)i/Count;

            float x = radius*sin(angle);
            float y = 0;
            float z = radius*cos(angle);

            QVector3D p = QVector3D(x,y,z);

            SCREENCircle.append(p);
        }

        */



        printf("ZAxisCircle vertices Count: %i",ZAxisCircle.size());

    }




    void drawCirle( QList<QVector3D> &points,QVector3D center = QVector3D(0,0,0),QColor color = QColor(1,1,1),bool selected = false,bool drawPoints = false)
    {
        if(selected)
        {
            glColor3f(1.0f,1.0f,1.0f);

        }
        else
        {
            glColor3f(color.red(),color.green(),color.blue());
        }


        //glEnable(GL_CULL_FACE);



        glBegin(GL_LINE_LOOP);

       for(int i=0;i<points.size();i++)
       {
           QVector3D p = points[i]+center;

           glVertex3f(p.x(),p.y(),p.z());

       }

       glEnd();
       //glDisable(GL_CULL_FACE);





       if(drawPoints)
       {
           glPointSize(2.0f);

           glBegin(GL_POINTS);

           for(int i=0;i<points.size();i++)
           {
               QVector3D p = points[i]+center;

               glVertex3f(p.x(),p.y(),p.z());
           }

           glEnd();
       }


    }
    /*

    void generateScreenCircle()
    {
        SCREENCircle.clear();

        float Count = 90.0f;
        float radius = 1.0f;

        QRay CamView;

        CamView.rayCastScene(100.0f,100.0f);

        QVector3D normal =  QVector3D::crossProduct(QVector3D(0,1,0),CamView.direction);

        for(float i=0;i<Count;i+=1)
        {
            //float angle      = 2.0f* M_PI* (float)i/Count;

            float angle      = 360.0f*i/Count;

            //QVector3D v      = normal *radius;

            QQuaternion quat = QQuaternion::fromAxisAndAngle(CamView.direction,angle);

            QVector3D p    = quat.rotatedVector(normal);




            SCREENCircle.append(p);
        }
    }

    */

    void drawScreen( QList<QVector3D> &points,QVector3D center = QVector3D(0,0,0),QColor color = QColor(1,1,1),bool selected = false,bool drawPoints = false)
    {
        if(selected)
        {
            glColor3f(1.0f,1.0f,1.0f);
        }
        else
        {
            glColor3f(color.red(),color.green(),color.blue());
        }

        glBegin(GL_LINE_LOOP);

        for(int i=0;i<points.size();i++)
        {
           QVector3D p =  points[i] + center;

           glVertex3f(p.x(),p.y(),p.z());
        }

        glEnd();
    }

    void drawRotationGizmo(QGLWidget* widget)
    {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glLineWidth(1);

        if(PlaneAXesMode==Y)
        {
            drawCirle(XAxisCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {
            drawCirle(XAxisCircle,QVector3D(0,0,0),QColor(1,0,0),false);
        }


        if(PlaneAXesMode==X)
        {
            drawCirle(YAxisCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {
            drawCirle(YAxisCircle,QVector3D(0,0,0),QColor(0,1,0),false);

        }


        if(PlaneAXesMode==Z)
        {

            drawCirle(ZAxisCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {
            drawCirle(ZAxisCircle,QVector3D(0,0,0),QColor(0,0,1),false);

        }


        /*

        if(PlaneAXesMode==SCREEN)
        {

            generateScreenCircle();


            drawScreen(SCREENCircle,QVector3D(0,0,0),QColor(1,1,1),mousePressed);
        }
        else
        {

            generateScreenCircle();

            drawScreen(SCREENCircle,QVector3D(0,0,0),QColor(0,1,1),false);

        }

        */


        glLineWidth(2);

        glBegin(GL_LINES);
        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.5f, 0.0f, 0.0f);

        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.5f, 0.0f);

        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.5f);
        glEnd();

        //glColor3f( .3, .3, .3 );
        QString xstr(" X");
        QString ystr(" Y");
        QString zstr(" Z");

        QFont font;
        font.setPointSize(15);

        glColor3f(1.0f, 0.0f, 0.0f);
        widget->renderText(0.5f, 0.0f, 0.0f,xstr,font);
        glColor3f(0.0f, 1.0f, 0.0f);
        widget->renderText(0.0f, 0.5f, 0.0f,ystr,font);
        glColor3f(0.0f, 0.0f, 1.0f);
        widget->renderText(0.0f, 0.0f, 0.5f,zstr,font);

        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHTING);

    }







    /*
    void rayPlaneIntersection(int x,int y)
    {
        if(models.size()>0 && models[currentHit->modelID]->Selected)
        {
            QVector3D v = models[currentHit->modelID]->position;

            QRay view;
            QPlane plane;
            QVector3D hitPoint;

            view.rayCastScene(x,y);

            plane.center = v;
            plane.axesAlignment = PlaneAXesMode;

            if(PlaneAXesMode==X)
            {
                plane.normal = QVector3D(0,0,1);
            }

            if(PlaneAXesMode==Y)
            {
                plane.normal = QVector3D(0,0,1);
            }

            if(PlaneAXesMode==Z)
            {
                plane.normal = QVector3D(0,1,0);
            }



            if(PlaneAXesMode==ZX)
            {
                plane.normal = QVector3D(0,1,0);
            }

            if(PlaneAXesMode==XY)
            {
                plane.normal = QVector3D(0,0,1);
            }

            if(PlaneAXesMode==YZ)
            {
                plane.normal = QVector3D(1,0,0);
            }


            if(PlaneAXesMode==SCREEN)
            {
                plane.normal = (-1.0f*view.direction);
            }

            if(PlaneAXesMode==TRACKBALL)
            {
                plane.normal = (-1.0f*view.direction);
            }

            hitPoint = view.getRayPlaneIntersection(plane);

            if(view.hitStatus ==1)
            {
                //printf("Plane Intersection x:%f,y:%f,z:%f \n",hitPoint.x,hitPoint.y,hitPoint.z);

                //QVector3D prev = models[currentHit->modelID]->position;
                QVector3D pos   = models[currentHit->modelID]->position;
                QVector3D prevr = models[currentHit->modelID]->rotation;


                QVector3D r1 = hitPoint - pos;
                QVector3D r2 = prevhitpoint - pos;

                float radius1 = r1.length();//glm::length(r1);
                float radius2 = r2.length();//glm::length(r2);

                float length = radius1-radius2;

                //length *= 10;

                prevhitpoint =  hitPoint;

                if(PlaneAXesMode==X||PlaneAXesMode==YZ)
                {
                    float xv = prevr.x() + length;
                    models[currentHit->modelID]->rotation = QVector3D(xv,prevr.y(),prevr.z());
                }

                if(PlaneAXesMode==Y||PlaneAXesMode==ZX)
                {
                    models[currentHit->modelID]->rotation = QVector3D(prevr.x(),prevr.y()+length,prevr.z());
                }

                if(PlaneAXesMode==Z||PlaneAXesMode==XY)
                {
                    models[currentHit->modelID]->rotation = QVector3D(prevr.x(),prevr.y(),prevr.z()+length);
                }

                if(PlaneAXesMode ==SCREEN)
                {
                    models[currentHit->modelID]->rotation = QVector3D(prevr.x(),prevr.y(),prevr.z()+length);
                }

                if(PlaneAXesMode == TRACKBALL)
                {
                    models[currentHit->modelID]->rotation = QVector3D(prevr.x(),prevr.y(),prevr.z()+length);

                }
            }
        }
    }

    */


    //----- Ray plane intersection--------------------------

    void rayPlaneIntersection(QPoint delta)
    {

        if(models.size()>0 && models[currentHit->modelID]->Selected)
        {

           QVector3D prevRotation = models[currentHit->modelID]->rotation;

           QVector3D pScale = models[currentHit->modelID]->scale;

           float rot  = QVector2D(delta.x(),delta.y()).length();

           float sign;

           if(delta.x() ==0)
           {
           }
           else
           {
               sign =  (float)delta.x()/fabs((float)delta.x());
           }

           rot *= 0.5f;
           rot *= sign;


           //float length = sqrt(delta.x()*delta.x()+delta.y()*delta.y());


           if(PlaneAXesMode==X)
           {

               models[currentHit->modelID]->rotation = prevRotation + QVector3D(0,rot,0);
           }

           if(PlaneAXesMode==Y)
           {
                models[currentHit->modelID]->rotation = prevRotation + QVector3D(rot,0,0);
           }

           if(PlaneAXesMode==Z)
           {
                models[currentHit->modelID]->rotation = prevRotation + QVector3D(0,0,rot);
           }

           if(PlaneAXesMode ==SCREEN)
           {
                //models[currentHit->modelID]->rotation = prevRotation + QVector3D(0,0,rot);
           }

           if(PlaneAXesMode == TRACKBALL)
           {
                models[currentHit->modelID]->rotation = prevRotation + QVector3D(delta.y(),delta.x(),0);

           }
        }
    }






    void rayBoxAXesIntersection(int x,int y)
    {
        float cursorselectionRadius = 0.2f;

        if(models.size()>0 && models[currentHit->modelID]->Selected)
        {
            QVector3D p= models[currentHit->modelID]->position;

            QRay view;

            view.rayCastScene(x,y);

            QVector3D r= models[currentHit->modelID]->rotation;


            QMatrix4x4 rotMat;
            rotMat.setToIdentity();
            rotMat.rotate(r.x(),QVector3D(1,0,0));
            rotMat.rotate(r.y(),QVector3D(0,1,0));
            rotMat.rotate(r.z(),QVector3D(0,0,1));


            foreach( QVector3D v, YAxisCircle)
            {
               QVector3D vert = rotMat*v+p;

               if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
               {
                   PlaneAXesMode = X;

                   mousePressed = true;

                   qDebug()<<"Y-Axis Rotation";

                   return;
               }
            }

            foreach( QVector3D v, XAxisCircle)
            {
                QVector3D vert = rotMat*v+p;

                if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
                {
                    PlaneAXesMode = Y;
                    qDebug()<<"X-Axis Rotation";
                    mousePressed = true;
                    return;
                }
            }

            foreach( QVector3D v, ZAxisCircle)
            {
                QVector3D vert = rotMat*v+p;

                if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
                {
                    PlaneAXesMode = Z;
                    qDebug()<<"Z-Axis Rotation";
                    mousePressed = true;
                    return;
                }

            }

            /*



            foreach( QVector3D v, SCREENCircle)
            {
                QRay CamView;

                CamView.rayCastScene(x,y);



                QMatrix4x4 m;

                m.setToIdentity();

                m.rotate(QQuaternion(,CamView.direction));

                QVector3D vert = m*v+p;

                if(QCollision::RaySphereCollision(vert,cursorselectionRadius,view.p0,view.p1))
                {
                    PlaneAXesMode = SCREEN;

                    mousePressed = true;

                    qDebug()<<"SCREEN-Axis Rotation";

                    return;
                }

            }

            */
        }
    }

    void drawGizmo(QGLWidget* widget)
    {
        if(models.size()>0)
        {
            if(models.size()>0 && models[currentHit->modelID]->Selected)
            {
                QVector3D v = models[currentHit->modelID]->position;
                QVector3D s = models[currentHit->modelID]->scale;
                QVector3D r = models[currentHit->modelID]->rotation;

                glDisable(GL_DEPTH_TEST);
                glDisable(GL_LIGHTING);

                glPushMatrix( );

                glTranslatef( v.x(), v.y(), v.z() );

                glRotatef(r.x(),1,0,0);
                glRotatef(r.y(),0,1,0);
                glRotatef(r.z(),0,0,1);

                //glScalef( s.x, s.y, s.z );
                glScalef( 1, 1, 1 );

                glBegin(GL_POINTS);

                glVertex3f(0,0,0);

                glEnd();

                if( TransformMode ==ROTATION)
                {
                    drawRotationGizmo(widget);
                }

                glPopMatrix();

                glColor3f( .3, .3, .3 );
                QString str("Pos:(");

                str += QString::number(v.x());str +=QString(",");
                str += QString::number(v.y());str +=QString(",");
                str += QString::number(v.z());str +=QString(")");

                widget->renderText(v.x()-1,v.y(),v.z(),str);

                glEnable(GL_DEPTH_TEST);
                glEnable(GL_LIGHTING);
            }
        }
    }
};


class AxesTransformer : public QObject
{
    Q_OBJECT

public:

    QString feedBack;

    QIcon icon;

    QStringList transformAxisList;
    QStringList transformList;

    QMenu transformsAxisMenu;
    QMenu transformMenu;


    QTrans PlaneAXesMode;

    QTransformMode TransformMode;

    HandleController *gizmo,*gizmoMove,*gizmoScale,*gizmoRotation;

    AxesTransformer(QObject *parent=0):QObject(parent)
    {
        icon = QIcon(QString(":/icons/cubeomniverse.svg"));

        TransformMode = MOVE;
        PlaneAXesMode = ZX;

        feedBack.append("Move:");

        gizmoMove     = new HandleMoveController;
        gizmoScale    = new HandleScaleController;
        gizmoRotation = new HandleRotationController;

        gizmoMove->TransformMode      = TransformMode;
        gizmoScale->TransformMode     = TransformMode;
        gizmoRotation->TransformMode  = TransformMode;

        gizmo = gizmoMove;

        transformAxisList.append(QString("X"));
        transformAxisList.append(QString("Y"));
        transformAxisList.append(QString("Z"));

        transformAxisList.append(QString("XY"));
        transformAxisList.append(QString("XZ"));
        transformAxisList.append(QString("YZ"));

        transformAxisList.append(QString("Screen"));
        transformAxisList.append(QString("UNIFORM"));
        //transfromsList.sort();

        transformList.append(QString("Move"));
        transformList.append(QString("Rotation"));
        transformList.append(QString("Scale"));
        transformList.sort();

        transformMenu.setTitle(QString("Set Transform Mode"));
        transformMenu.setIcon(icon);

        transformsAxisMenu.setTitle(QString("Set Axis Transform Mode"));
        transformsAxisMenu.setIcon(icon);

        QFile file(":/icons/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
           QByteArray  style = file.readAll();

           transformsAxisMenu.setStyleSheet(style);

           transformMenu.setStyleSheet(style);
        }

        setAxisTransformMenues();

        setTransformMenues();

        setFeedBack();
    }


    void setFeedBack()
    {
        QString str;

        switch(TransformMode)
        {
        case MOVE:

            str.append("Move:");

            break;
        case ROTATION:
            str.append("Rotation:");
            break;
        case SCALE:
            str.append("Scale:");
            break;
        case XYZ_NONE:

            str.append("None:");
            break;

        }

        switch(PlaneAXesMode)
        {
        case X:
            str.append("X-Axis");
            break;
        case Y:
            str.append("Y-Axis");
            break;
        case Z:
            str.append("Z-Axis");
            break;

        case ZX:
            str.append("ZX-plane");
            break;
        case YZ:
            str.append("YZ-plane");
            break;
        case XY:
            str.append("XY-plane");
            break;

        case SCREEN:
            str.append("Screen-plane");
            break;
        case TRACKBALL:
            str.append("Track Ball");
            break;
        }

        feedBack = str;
    }


    virtual void drawGizmo(QGLWidget * parentWidget)
    {
        gizmo->drawGizmo(parentWidget);

        setFeedBack();
    }

    virtual void computeGizimo( QList<QBaseModel*> &models,QPoint lastPos,QHitInfo * currentHit)
    {
        if(gizmo)
        {
            gizmo->mousePressed =  true;

            gizmo->setTransPlaneAxes(PlaneAXesMode);
            gizmo->setHitInfo(currentHit);
            gizmo->setModelsList(models);
            gizmo->rayBoxAXesIntersection(lastPos.x(),lastPos.y());
        }

        setFeedBack();
    }

    virtual void gizmoRelease()
    {
        if(gizmo)
        {
            gizmo->mousePressed =  false;
        }

        gizmo->mousePressed =  false;
    }

    virtual void getGizmoTransforms(QMouseEvent* event,QPoint delta)
    {
        QPoint c = event->pos();

        if(event->buttons() & Qt::LeftButton  && event->modifiers() & Qt::ShiftModifier)
        {
            QApplication::desktop()->setCursor(Qt::SizeAllCursor);

            if(gizmo)
            {
                if(TransformMode==MOVE||TransformMode==ROTATION)
                {
                    gizmo->rayPlaneIntersection(c.x(),c.y());
                }
                else if(TransformMode ==SCALE)
                {
                    qDebug()<<"Scaling";

                    gizmo->rayPlaneIntersection(delta);
                }
            }
        }
        else if(event->buttons() & Qt::LeftButton )
        {
            if(gizmo)
            {
                if(PlaneAXesMode==SCREEN || PlaneAXesMode == UNIFORM)
                {
                    QApplication::desktop()->setCursor(Qt::SizeAllCursor);
                }
                else if(PlaneAXesMode==XYZ_NONE)
                {

                    QApplication::desktop()->setCursor(Qt::ArrowCursor);
                }
                else
                {
                    QApplication::desktop()->setCursor(Qt::BlankCursor);
                }

                //QTextCursor cursor(editor->textCursor());
                //gizmo->rayPlaneIntersection(c.x(),c.y());

                if(TransformMode==MOVE)
                {
                    gizmo->rayPlaneIntersection(c.x(),c.y());
                }
                else if(TransformMode ==SCALE||TransformMode==ROTATION)
                {
                    qDebug()<<"Scaling";

                    gizmo->rayPlaneIntersection(delta);
                }
            }
        }

        setFeedBack();
    }

    virtual void setTransformMode(QKeyEvent * event)
    {
        feedBack.clear();
        if(event->key()==Qt::Key_Q||event->key()==Qt::Key_4)
        {
            TransformMode = NONE;

            gizmo->setTransformMode(TransformMode);

            printf("Transfrom mode:None ");

            feedBack.append("None:");
        }
        else if(event->key()==Qt::Key_R||event->key()==Qt::Key_2)
        {
            TransformMode = ROTATION;

            gizmoRotation->setTransformMode(TransformMode);

            gizmo = gizmoRotation;

            printf("Transfrom mode:ROTATION \n");

            feedBack.append("Rotation:");
        }
        else if(event->key()==Qt::Key_T||event->key()==Qt::Key_1)
        {
            TransformMode = MOVE;

            gizmoMove->setTransformMode(TransformMode);

            gizmo = gizmoMove;

            printf("Transfrom mode:MOVE \n");

            feedBack.append("Move:");
        }
        else if(event->key()==Qt::Key_E||event->key()==Qt::Key_3)
        {
            TransformMode = SCALE;

            gizmoScale->setTransformMode(TransformMode);

            gizmo = gizmoScale;

            printf("Transfrom mode:SCALE \n");
            feedBack.append("Scale:\n");
        }


        setFeedBack();
    }

    virtual void setAxisTransformMode(QKeyEvent * event)
    {
        if(event->key()==Qt::Key_X)
        {
           setAxisX();
        }
        if(event->key()==Qt::Key_Y)
        {
            setAxisY();

        }
        if(event->key()==Qt::Key_Z)
        {
            setAxisZ();
        }

        if(event->key()==Qt::Key_S)
        {
            setAxisScreen();

        }
        if(event->key()==Qt::Key_X &&  event->modifiers() & Qt::ShiftModifier)
        {
            setAxisYZ();
        }
        if(event->key()==Qt::Key_Y &&  event->modifiers() & Qt::ShiftModifier)
        {
            setAxisXZ();
        }
        if(event->key()==Qt::Key_Z &&  event->modifiers() & Qt::ShiftModifier)
        {
            setAxisXY();
        }
        if(event->key()==Qt::Key_W)
        {

            PlaneAXesMode = UNIFORM;

            printf("Perform selection UNIFORM-Plane \n");
        }

        if(gizmo)
        {
            gizmo->setTransPlaneAxes(PlaneAXesMode);
        }

        setFeedBack();
    }


public slots:

    void setTransformMenues()
    {
        //foreach(QString nodename,transfromsList)
        for(int i=0;i<transformList.size();i++)
        {
            QString nodename = transformList[i];

            if(nodename.contains("Move",Qt::CaseSensitive)&&nodename.length() == QString("Move").length())
            {
                transformMenu.addAction(icon,nodename,this,SLOT(setMove()),QKeySequence(Qt::Key_T));
            }
            else if(nodename.contains("Rotation",Qt::CaseSensitive)&&nodename.length() == QString("Rotation").length())
            {
                transformMenu.addAction(icon,nodename,this,SLOT(setRotation()),QKeySequence(Qt::Key_R));
            }
            else if(nodename.contains("Scale",Qt::CaseSensitive)&&nodename.length() == QString("Scale").length())
            {
                transformMenu.addAction(icon,nodename,this,SLOT(setScale()),QKeySequence(Qt::Key_E));
            }
            else if(nodename.contains("Freeze",Qt::CaseSensitive)&&nodename.length() == QString("Freeze").length())
            {
                transformMenu.addAction(icon,nodename,this,SLOT(setFreeze()),QKeySequence(Qt::Key_Q));
            }
        }
    }
    void setAxisTransformMenues()
    {
        //foreach(QString nodename,transfromsList)
        for(int i=0;i<transformAxisList.size();i++)
        {
            QString nodename = transformAxisList[i];

            if(nodename.contains("X",Qt::CaseSensitive)&&nodename.length()==QString("X").length())
            {
                transformsAxisMenu.addAction(icon,nodename,this,SLOT(setAxisX()));
            }
            else if(nodename.contains("Y",Qt::CaseSensitive)&&nodename.length()==QString("Y").length())
            {
                transformsAxisMenu.addAction(icon,nodename,this,SLOT(setAxisY()));
            }
            else if(nodename.contains("Z",Qt::CaseSensitive)&&nodename.length()==QString("Z").length())
            {
                transformsAxisMenu.addAction(icon,nodename,this,SLOT(setAxisZ()));
            }
            else if(nodename.contains("XY",Qt::CaseSensitive)&&nodename.length()==QString("XY").length())
            {
                transformsAxisMenu.addAction(icon,nodename,this,SLOT(setAxisXY()));
            }
            else if(nodename.contains("XZ",Qt::CaseSensitive)&&nodename.length()==QString("XZ").length())
            {
                transformsAxisMenu.addAction(icon,nodename,this,SLOT(setAxisXZ()));
            }
            else if(nodename.contains("YZ",Qt::CaseSensitive)&&nodename.length()==QString("YZ").length())
            {
                transformsAxisMenu.addAction(icon,nodename,this,SLOT(setAxisYZ()));
            }
            else if(nodename.contains("Screen",Qt::CaseSensitive))
            {
                transformsAxisMenu.addAction(icon,nodename,this,SLOT(setAxisScreen()));
            }
            else if(nodename.contains("UNIFORM",Qt::CaseSensitive))
            {
                transformsAxisMenu.addAction(icon,nodename,this,SLOT(setAxisUniform()));
            }
            //allnodes.append(nodename);
        }

    }

    void setMove()
    {
        TransformMode = MOVE;

        gizmoMove->setTransformMode(TransformMode);

        gizmo = gizmoMove;

        setFeedBack();
    }
    void setRotation()
    {
        TransformMode = ROTATION;

        gizmoRotation->setTransformMode(TransformMode);

        gizmo = gizmoRotation;
        setFeedBack();
    }

    void setScale()
    {
        TransformMode = SCALE;

        gizmoScale->setTransformMode(TransformMode);

        gizmo = gizmoScale;
        setFeedBack();
    }

    void setFreeze()
    {
        TransformMode = NONE;

        gizmo->setTransformMode(TransformMode);

        setFeedBack();
    }


    void setAxisX()
    {
        PlaneAXesMode = X;
        printf("Perform selection X-Axis \n");
        setFeedBack();

    }

    void setAxisY()
    {
        PlaneAXesMode = Y;
        printf("Perform selection Y-Axis \n");
        setFeedBack();
    }

    void setAxisZ()
    {
        PlaneAXesMode = Z;

        printf("Perform selection Z-Axis \n");
        setFeedBack();
    }

    void setAxisYZ()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = YZ;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = X;
        }

        printf("Perform selection YZ-plane \n");
        setFeedBack();
    }

    void setAxisXZ()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = ZX;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = Y;
        }
        printf("Perform selection ZX-plane \n");
        setFeedBack();
    }

    void setAxisXY()
    {
        if(TransformMode == MOVE)
        {
            PlaneAXesMode  = XY;
        }
        else if(TransformMode ==ROTATION)
        {
            PlaneAXesMode = Z;
        }

        printf("Perform selection XY-plane \n");
        setFeedBack();

    }

    void setAxisUniform()
    {
         PlaneAXesMode = UNIFORM;

         printf("Perform selection SCREEN-Plane \n");
         setFeedBack();

    }

    void setAxisScreen()
    {
         PlaneAXesMode = SCREEN;

         printf("Perform selection SCREEN-Plane \n");

         setFeedBack();
    }

};















#endif // HANDLES_HPP

#ifndef ABOUT_HPP
#define ABOUT_HPP

#include<QtWidgets>

class About : public QWidget
{
    Q_OBJECT
public:
    About(QWidget *parent = 0)
    {
        setFixedSize(900,200);

        setWindowTitle(QString("About Metropolis"));

        setWindowIcon(QIcon(":/icons/metropolis.svg"));

        QVBoxLayout * l = new QVBoxLayout;

       // QLineEdit * w = new QLineEdit(this);

        //w->setFocus();

        //w->setFocus(Qt::OtherFocusReason);

        //l->addWidget(w);

        setLayout(l);

        //setContentsMargins(50,50,50,50);

        QFile file(":/icons/glowBlue.stylesheet");

       // QString s ="darkorange.stylesheet"


        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            this->setStyleSheet(file.readAll());

            file.close();
        }

    }

    void paintEvent(QPaintEvent *event)
    {
        QPainter *painter = new QPainter;
        painter->begin(this);
        drawSplash();
        painter->end();
    }

    void mousePressEvent(QMouseEvent * event)
    {
        if(event->buttons()&Qt::RightButton)
        {
            this->hide();
        }
    }

    void drawSplash()
    {
        QPainter p(this);
        QFont f( "Courier", 10, QFont::Normal );
        p.setFont(f);

       //p.setBrush(QBrush(QColor(Qt::black)));
        p.drawRect(rect());

        QPoint co(50,50);

        //p.setPen(Qt::cyan);
        p.setPen(QColor(128,128,128));

        QString fstr = QString("Developer: Agapi Simon");
        p.drawText(co,fstr);
        co += QPoint(0,20);

        QString appstr = QString("Application: Metropolis");
        p.drawText(co,appstr);
        co += QPoint(0,20);

        QString strVersion = QString("Version: 0.5");
        p.drawText(co,strVersion);
        co += QPoint(0,20);

        QString copystr = QString("Copyright � Agapi Simon:")+QString::number(2016);
        p.drawText(co,copystr);
        co += QPoint(0,20);

        QString emailstr = QString("Email: mittisimone@gmail.com");
        p.drawText(co,emailstr);
        co += QPoint(0,20);

        //QPixmap map(":/metroplis.svg");
        //QPixmap map(":/icons/metroplis.png");
        //p.drawPixmap(co,map);

        /*

        QString disclaimer = " COPYRIGHT NOTICE \n\

         "Copyright © 2015  AGAPI SIMON COMPANY INC\n\")

         "Email: mittisimone@gmail.com"

          co += QPoint(0,50);
          p.drawText(co,disclaimer);

        */


    }


public slots:

    void closeAbout()
    {
        this->showNormal();
    }
};






#endif // ABOUT_HPP

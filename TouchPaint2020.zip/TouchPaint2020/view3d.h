


#ifndef VIEW3D_H
#define VIEW3D_H

#include<QtWidgets>
#include<QtOpenGL>
#include<QGLWidget>

#include<GL/gl.h>
#include<GL/glu.h>
#include<scene.hpp>



/*
class QView3D :  public QGLWidget
{
    Q_OBJECT

public:

    QToolBar * mainToolBar;

    void createView3DToolbar()
    {
        qDebug()<<"main toolbar created";
        //mainToolBar = addToolBar(QString("UndoRedo"));


        QLabel *viewLabel = new QLabel( QString("  View Mode:") );

        QComboBox * combobox = new QComboBox;
        QStringList comboboxlist;

        comboboxlist.append(QString("Top"));
        comboboxlist.append(QString("Bottom"));
        comboboxlist.append(QString("Front"));
        comboboxlist.append(QString("Back"));
        comboboxlist.append(QString("Right"));
        comboboxlist.append(QString("Left"));
        comboboxlist.append(QString("Perspective"));
        comboboxlist.append(QString("Ortho"));
        comboboxlist.append(QString("Camera"));
        combobox->addItems(comboboxlist);

        mainToolBar->addSeparator();
        mainToolBar->addWidget(viewLabel);
        mainToolBar->addWidget(combobox);

        //-------------------------------------------------------------


        QLabel *controlsLabel = new QLabel(QString("   Camera:"));
        QPushButton *button  = new QPushButton(QString("Move"));
        QPushButton *button1 = new QPushButton(QString("Scale"));
        QPushButton *button2 = new QPushButton(QString("Rotate"));
        //QPushButton *button3 = new QPushButton(QString("Zoom"));

        mainToolBar->addSeparator();
        mainToolBar->addWidget(controlsLabel);
        mainToolBar->addWidget(button);
        mainToolBar->addWidget(button1);
        mainToolBar->addWidget(button2);


        //-------------------------------------------------------------


        QLabel *rcontrolsLabel2 = new QLabel(QString("Shade:"));

        QRadioButton *rbutton  = new QRadioButton(QString("Edges"));
        QRadioButton *rbutton1 = new QRadioButton(QString("Flat"));
        QRadioButton *rbutton2 = new QRadioButton(QString("Smooth"));
        QRadioButton *rbutton3 = new QRadioButton(QString("Edge+Faces"));
        QRadioButton *rbutton4 = new QRadioButton(QString("Vertices"));
        //QPushButton *button3 = new QPushButton(QString("Zoom"));

        mainToolBar->addSeparator();
        mainToolBar->addWidget(rcontrolsLabel2);
        mainToolBar->addWidget(rbutton);
        mainToolBar->addWidget(rbutton1);
        mainToolBar->addWidget(rbutton2);
        mainToolBar->addWidget(rbutton3);
        mainToolBar->addWidget(rbutton4);


        //-------------------------------------------------------------



        QLabel *shadeLabel = new QLabel(QString("  Shade Mode"));
        QComboBox * shadeCombobox = new QComboBox;
        QStringList scomboboxlist;
        scomboboxlist.append(QString("Wireframe"));
        scomboboxlist.append(QString("Flat"));
        scomboboxlist.append(QString("Smooth"));
        scomboboxlist.append(QString("Edged"));
        scomboboxlist.append(QString("Xray"));
        scomboboxlist.append(QString("Points"));

        shadeCombobox->addItems(scomboboxlist);

        mainToolBar->addSeparator();
        mainToolBar->addWidget(shadeLabel);
        mainToolBar->addWidget(shadeCombobox);

        //-------------------------------------------------------------



        QLabel *objectLabel   = new QLabel(QString("   Object:"));

        QPushButton *Obutton  = new QPushButton(QString("Select"));
        QPushButton *Obutton1 = new QPushButton(QString("Move"));
        QPushButton *Obutton2 = new QPushButton(QString("Scale"));
        QPushButton *Obutton3 = new QPushButton(QString("Rotate"));


        mainToolBar->addSeparator();
        mainToolBar->addWidget(objectLabel);
        mainToolBar->addWidget(Obutton);
        mainToolBar->addWidget(Obutton1);
        mainToolBar->addWidget(Obutton2);
        mainToolBar->addWidget(Obutton3);

        //-------------------------------------------------------------



        QLabel *PlaneTransformLabel = new QLabel(QString("   Plane Transforms:"));
        QComboBox * planexCombobox  = new QComboBox;

        QStringList planexcomboboxlist;

        planexcomboboxlist.append(QString("plane XY  "));
        planexcomboboxlist.append(QString("plane ZX  "));
        planexcomboboxlist.append(QString("plane YZ  "));

        planexCombobox->addItems(planexcomboboxlist);


        mainToolBar->addSeparator();
        mainToolBar->addWidget(PlaneTransformLabel);
        mainToolBar->addWidget(planexCombobox);

        //-------------------------------------------------------------


    }

    //QSceneGraph *scenegraph;

    QSize minimumSizeHint() const
    {
        return QSize(250, 100);
    }

    QSize sizeHint() const
    {
        return QSize(width(), height());
         //return QSize(QApplication::desktop()->width(), QApplication::desktop()->height());
    }

    void initializeGL()
    {
       //scenegraph->camera->setViewPort(width(),height());

       glShadeModel(GL_SMOOTH);
       glClearColor(0.5f,0.5f,0.5f,1.0f);
       glClearDepth(1.0f);
       glEnable(GL_DEPTH_TEST);
       glDepthFunc(GL_LEQUAL);

       glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

    }

    void resizeGL(int width, int height)
    {
        //scenegraph->camera->setViewPort(width,height);

        if(height == 0)
        {
            height = 1;
        }

        glViewport(0, 0, width, height);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();

        gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,100.0f);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

    }

    QView3D(QWidget * parent=0) : QGLWidget(parent)
    {
        mainToolBar = new QToolBar(QString("View3D Tool bar"));

        createView3DToolbar();

        //setToolTip("Metropolis:");
        setWindowTitle(QString("Metropolis:"));

        setFormat(QGLFormat(QGL::SampleBuffers));
        //setFormat(QGLFormat(QGL::DoubleBuffer));

        //scenegraph = new QSceneGraph(this,0);

        setAcceptDrops(true);
        //this->grabKeyboard();


        //QSceneTreeView *v;
        //v = new QSceneTreeView;


        //p->show();
        //QPropertiesWidget * properties = new QPropertiesWidget;

         //showMaximized();
    }



    void paintGL()
    {
        //scenegraph->drawScene();
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glLoadIdentity();





        update();
    }


    void wheelEvent(QWheelEvent *event)
    {
        float zoomfactor = event->delta();

        //scenegraph->camera->zoom(zoomfactor);

        qDebug()<<"zoom:"<<zoomfactor;

    }

    void keyPressEvent(QKeyEvent * event)
    {
        //scenegraph->keyPressEvents(event);
    }

    void mousePressEvent(QMouseEvent *event)
    {
        //scenegraph->mousePressEvents(event);
    }

    void mouseMoveEvent(QMouseEvent * event)
    {
        //scenegraph->mouseMoveEvents(event);
    }

    void mouseReleaseEvent(QMouseEvent * event)
    {
        //scenegraph->mouseReleaseEvents(event);

        setCursor(Qt::ArrowCursor);
    }

    void dragEnterEvent(QDragEnterEvent * event)
    {
        event->acceptProposedAction();

        QGLWidget::dragEnterEvent(event);
    }

    void dragMoveEvent(QDragMoveEvent *event)
    {
        event->accept(); //very important

        QGLWidget::dragMoveEvent(event);
    }

    void dropEvent(QDropEvent *event)
    {
        event->acceptProposedAction();

        if(event->mimeData()->hasText())
        {
            //addNode(event->mimeData()->text(),QCursor::pos());

            //scene()->update();

            qDebug()<<"Objects"<<event->mimeData()->text();
        }

        QGLWidget::dropEvent(event);
    }

    void contextMenuEvent(QContextMenuEvent *event)
    {
        qDebug()<<"Main menu";

        QPoint p = QCursor::pos();

        //scenegraph->mainContextmenu.move(p);
        //scenegraph->mainContextmenu.show();


        //QAction *selectedAction = mainContextmenu.exec();

        //if (selectedAction)
        {
           //if(_debug)
           //printf("Clicked Action:\n");
           //qDebug()<<"Clicked Action:\n"<<selectedAction->text();

           //addModel(selectedAction->text());
           //printf(qPrintable(selectedAction->text()));
       }

    }
};

*/


class QNodesListView1 : public QListWidget
{
    Q_OBJECT


    bool _debug = false;

public:
    void setDebugging(bool print = false)
    {
      _debug = print;
    }

    QNodesListView1(QWidget* parent =0):QListWidget(parent)
    {
        setIconSize(QSize(15,15));

        //setAcceptDrops(true);

        //setDragDropMode(DropOnly);

        connect(this,SIGNAL(itemSelectionChanged()),this,SLOT(printselection()));


    }

    void resizeEvent(QResizeEvent *event)
    {
        //setGeometry(this->rect());
        showMaximized();

        QListWidget::resizeEvent(event);
    }




    void mouseReleaseEvent(QMouseEvent *event)
    {
        setCursor(Qt::OpenHandCursor);
        QListWidget::mouseReleaseEvent(event);
    }


    void selectionChanged(const QItemSelection &selected, const QItemSelection &deselected)
    {
        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        if(_debug)qDebug()<<"Selection Change:"<<index;
        if(_debug)qDebug()<<"Selection Text:"<<selectedText;

        QListWidget::selectionChanged(selected,deselected);
    }



    void mousePressEvent(QMouseEvent *event)
    {
        setCursor(Qt::ClosedHandCursor);
        QListWidget::mousePressEvent(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        QDrag * drag = new QDrag(this);

        QMimeData * mime = new QMimeData;

        drag->setMimeData(mime);

        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        if(_debug)qDebug()<<"Selection Change:"<<index;
        if(_debug)qDebug()<<"Selection Text:"<<selectedText;

        //QString str("Node/name");
        mime->setText(selectedText);

        drag->exec();
        setCursor(Qt::OpenHandCursor);

        QListWidget::mouseMoveEvent(event);
    }


    /*
    void dragEnterEvent(QDragEnterEvent *event)
    {
        QDrag * drag = new QDrag(this);

        QMimeData * mime = new QMimeData;

        drag->setMimeData(mime);

        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        if(_debug)qDebug()<<"Selection Change:"<<index;
        if(_debug)qDebug()<<"Selection Text:"<<selectedText;

        //QString str("Node/name");
        mime->setText(selectedText);

        drag->exec();
        setCursor(Qt::OpenHandCursor);

        QListWidget::dragEnterEvent(event);
    }
    */

private slots:
    void printselection()
    {
        qDebug()<<"Selection change";

    }
};

class QSearchEx1 : public QFrame
{
    Q_OBJECT

    QIcon  icon;

    QString selectedText;

    QStringList nodeslists;

    QStringList hitslist;

    QStringListModel * model;

    QLineEdit * lineEdit;

    QListView * listview;


public:


    QWidget * metropolisToolBox;



    QNodesListView1 * listviewWidget;


    QString getSelectedText()
    {
        return selectedText;
    }


    void _search(QString filter)
    {
        hitslist.clear();

        foreach( QString str, nodeslists)
        {
            if (str.contains(filter,Qt::CaseInsensitive))
            {
                hitslist.append(str);
            }
        }
    }

    QSearchEx1(QStringList list,QWidget *parent = 0) : QFrame(parent)
    {
        icon = QIcon(QString(":/icons/cubeomniverse.svg"));

        nodeslists =  list;

        init();

        //setWindowFlags(Qt::FramelessWindowHint);

        //setAttribute(Qt::WA_NoSystemBackground);
    }

    void init()
    {
        setMaximumHeight(150);
        //list.removeDuplicates();
        nodeslists.sort();


        lineEdit = new QLineEdit;
        listview = new QListView;
        listviewWidget = new QNodesListView1;


        QPushButton * button =  new QPushButton;
        button->setIcon(QIcon(QString(":/icons/search_icon.svg")));
        button->setDisabled(true);

        QHBoxLayout *slayout = new QHBoxLayout;
        slayout->addWidget(button);
        slayout->addWidget(lineEdit);
        QWidget * sframe  = new QWidget;
        sframe->setLayout(slayout);


        QHBoxLayout * hlayout =  new QHBoxLayout;

        QWidget * frame  = new QWidget;

        QVBoxLayout * layout =  new QVBoxLayout;

        //layout->addWidget(lineEdit);
        layout->addWidget(sframe);
        layout->addWidget(listview);

        frame->setLayout(layout);

        QSplitter * splitter = new QSplitter(Qt::Horizontal);

        splitter->addWidget(frame);
        splitter->addWidget(listviewWidget);
        //hlayout->addLayout(layout);
        //hlayout->addWidget(listviewWidget);

        hlayout->addWidget(splitter);
        //setLayout(hlayout);
        setLayout(hlayout);


        //--------------->

        //metropolisToolBox = new QWidget;
        //QVBoxLayout * metro_hlayout =  new QVBoxLayout;
        //metro_hlayout->addWidget(sframe);
        //metro_hlayout->addWidget(listviewWidget);
        //metropolisToolBox->setLayout(metro_hlayout);

        //------------------->






        connect(lineEdit,SIGNAL(textChanged(QString)),this,SLOT(populateListView()));
        connect(listview,SIGNAL(clicked(QModelIndex)),this,SLOT(getSearchResults()));
        connect(lineEdit,SIGNAL(returnPressed()),this,SLOT(getSearchResults()));

        model = new QStringListModel;
        model->setStringList(nodeslists);
        listview->setModel(model);

        listviewWidget->clear();

        foreach(QString nodename,nodeslists)
        {
            listviewWidget->addItem(new QListWidgetItem(icon,nodename));
        }

        listviewWidget->setViewMode(QListView::IconMode);

    }

    void setFocus()
    {
        lineEdit->setFocus();
        lineEdit->setCursorPosition(0);
    }


private slots:

    void populateListView()
    {
        if(lineEdit->text().size()==0)
        {
            delete model;
            model = new QStringListModel;
            model->setStringList(nodeslists);


            foreach(QString nodename,nodeslists)
            {
                listviewWidget->addItem(new QListWidgetItem(icon,nodename));
            }
        }
        else
        {
            _search(lineEdit->text());

            delete model;

            model = new QStringListModel;
            model->setStringList(hitslist);

            listviewWidget->clear();

            foreach(QString nodename,hitslist)
            {
                listviewWidget->addItem(new QListWidgetItem(icon,nodename));
            }
        }

        listviewWidget->setViewMode(QListView::IconMode);
        //listviewWidget->setMaximumHeight(150);

        listview->setModel(model);

    }

    void getSearchResults()
    {
        QModelIndex index = listview->currentIndex();

        qDebug()<< index.data().toString();

        lineEdit->setText(index.data().toString());

        selectedText = index.data().toString();

        //hide();

        emit valueChanged(selectedText);

        //lineEdit->setText(QString(""));
        //listview->reset();
        //listview->clearSelection();
    }



signals:
    void valueChanged(QString filter);
};

class QSceneTreeView : QTreeView//QTreeWidget
{
    Q_OBJECT

    QStringListModel * model;
    QStandardItemModel * m;


public:
    QSceneTreeView(QWidget * parent =0) : QTreeView(parent)
    {

        model = new QStringListModel;
        m     = new QStandardItemModel(0, 2);

       //setColumnCount(4);

       //column 1 = nameOfobject;
       //column 2 = hideFromView;
       //column 3 = freezeSelection;
       //column 4 = hideFromRender

       QStringList headerLabels;
       headerLabels.append(QString("Name:"));
       headerLabels.append(QString("Visibility:"));
       headerLabels.append(QString("Freeze:"));
       headerLabels.append(QString("Renderable:"));


       //setHeaderLabels(headerLabels);
       setAlternatingRowColors(true);

       //model->setStringList(headerLabels);
       this->setModel(m);

       m->setColumnCount(4);

       for(int i=0;i<20;i++)
       {
           addItems(i);
       }



       /*


       for(int i=0;i<20;i++)
       {

           QStringList labels;
           labels.append(QString("Cone"));
           QTreeWidgetItem * item1 = new QTreeWidgetItem(labels);


           item1->setText(0,QString("Cone"));
           item1->setIcon(0,QIcon(QString(":/icons/cubeomniverse.svg")));


           setItemWidget(item1, 1, new QRadioButton());
           setItemWidget(item1, 2, new QRadioButton());
           setItemWidget(item1, 3, new QRadioButton());


           //item1->setText(0,QString("Cone"));
           addTopLevelItem(item1);



       }
       */

       //addTopLevelItems();
       //addTopLevelItem();

       show();

    }

    void addItems(int n)
    {

        QString str = QString("Cone")+QString::number(n);

        QStandardItem *item = new QStandardItem(str);

        item->setIcon(QIcon(QString(":/icons/cubeomniverse.svg")));

        //QPushButton * itemWidget = new QPushButton(QString("Cone")+QString::number(n));
        //QModelIndex modelIndex = m->index(n, 2);

        //setIndexWidget(modelIndex, itemWidget);
        //m->setItem(n, 0, item);

        m->appendRow(item);

        setIndexWidget(m->index(n, 1),new QRadioButton("A",this));

     /*

               if n == 2:
                   std_item_child = QStandardItem('child');
                   std_item.appendRow(std_item_child);

                   node_widget_child = QPushButton('petit button');
                   qindex_widget_child = self._datamodel.index(n, 1, QModelIndex());
                   self.setIndexWidget(qindex_widget_child, node_widget_child);

                   */
    }





    void resizeEvent(QResizeEvent *event)
    {
        //setGeometry(this->rect());
        showMaximized();

        QTreeView::resizeEvent(event);
    }
    /*



    void mouseReleaseEvent(QMouseEvent *event)
    {
        setCursor(Qt::OpenHandCursor);
        QTreeWidget::mouseReleaseEvent(event);
    }


    void selectionChanged(const QItemSelection &selected, const QItemSelection &deselected)
    {
        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        qDebug()<<"Selection Change:"<<index;
        qDebug()<<"Selection Text:"<<selectedText;

        QTreeWidget::selectionChanged(selected,deselected);
    }

    void mousePressEvent(QMouseEvent *event)
    {
        setCursor(Qt::ClosedHandCursor);
        QTreeWidget::mousePressEvent(event);
    }

    void mouseMoveEvent(QMouseEvent *event)
    {
        QDrag * drag = new QDrag(this);

        QMimeData * mime = new QMimeData;

        drag->setMimeData(mime);

        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        qDebug()<<"Selection Change:"<<index;
        qDebug()<<"Selection Text:"<<selectedText;

        //QString str("Node/name");
        mime->setText(selectedText);

        drag->exec();
        setCursor(Qt::OpenHandCursor);

        QTreeWidget::mouseMoveEvent(event);
    }



    void dragEnterEvent(QDragEnterEvent *event)
    {
        QDrag * drag = new QDrag(this);

        QMimeData * mime = new QMimeData;

        drag->setMimeData(mime);

        const QModelIndex index = this->selectionModel()->currentIndex();

        QString selectedText = index.data(Qt::DisplayRole).toString();

        if(_debug)qDebug()<<"Selection Change:"<<index;
        if(_debug)qDebug()<<"Selection Text:"<<selectedText;

        //QString str("Node/name");
        mime->setText(selectedText);

        drag->exec();
        setCursor(Qt::OpenHandCursor);

        QTreeWidget::dragEnterEvent(event);
    }
    */

};

class QView3D :  public QGLWidget
{
    Q_OBJECT

public:

    QSceneGraph *scenegraph;

    QToolBar * mainToolBar;
    QToolBar * controlsToolBar;
    QToolBar * brushestoolBar;

     QList<QAction*> brushesActions;

    QList<QAction*> penActions;
    //QActionGroup *penActionGroup;
    QList<QAction*> transformActions;
    //QActionGroup *transformActionGroup;
    QList<QAction*> selectionActions;
    //QActionGroup *selectionActionGroup;

    QActionGroup *actiongroups;
    QActionGroup *bactiongroups;

    void createView3DToolbar()
    {
        qDebug()<<"main toolbar created";


        QLabel *viewLabel = new QLabel(QString("  View Mode:"));

        QRadioButton *vbutton0 = new QRadioButton(QString("Top"));
        QRadioButton *vbutton1 = new QRadioButton(QString("Bottom"));
        QRadioButton *vbutton2 = new QRadioButton(QString("Front"));
        QRadioButton *vbutton3 = new QRadioButton(QString("Back"));
        QRadioButton *vbutton4 = new QRadioButton(QString("Left"));
        QRadioButton *vbutton5 = new QRadioButton(QString("Perspective"));
        QRadioButton *vbutton6 = new QRadioButton(QString("Ortho"));
        QRadioButton *vbutton7 = new QRadioButton(QString("Camera"));

        mainToolBar->addSeparator();


        mainToolBar->addWidget(viewLabel);
        mainToolBar->addWidget(vbutton0);
        mainToolBar->addWidget(vbutton1);
        mainToolBar->addWidget(vbutton2);
        mainToolBar->addWidget(vbutton3);
        mainToolBar->addWidget(vbutton4);
        mainToolBar->addWidget(vbutton5);
        mainToolBar->addWidget(vbutton6);
        mainToolBar->addWidget(vbutton7);

        mainToolBar->addSeparator();


        //-------------------------------------------------------------


        QLabel *rcontrolsLabel2 = new QLabel(QString("Shade:  "));

        QRadioButton *rbutton  = new QRadioButton(QString("Edges"));
        QRadioButton *rbutton1 = new QRadioButton(QString("Flat"));
        QRadioButton *rbutton2 = new QRadioButton(QString("Smooth"));
        QRadioButton *rbutton3 = new QRadioButton(QString("Edge+Faces"));
        QRadioButton *rbutton4 = new QRadioButton(QString("Vertices"));

        mainToolBar->addSeparator();


        mainToolBar->addWidget(rcontrolsLabel2);
        mainToolBar->addWidget(rbutton);
        mainToolBar->addWidget(rbutton1);
        mainToolBar->addWidget(rbutton2);
        mainToolBar->addWidget(rbutton3);
        mainToolBar->addWidget(rbutton4);



        //-------------------------------------------------------------

        actiongroups = new QActionGroup(this);

        qDebug()<<"controls toolbar created";

        controlsToolBar->addSeparator();

        //transformActionGroup = new QActionGroup(this);


        QAction * b1 = new QAction(QIcon(":/Tools Icons/select.svg"),QString("Select: Shift+G"),this);
        QAction * b2 = new QAction(QIcon(":/Tools Icons/Translate.svg"),QString("Move: Shift+T"),this);
        QAction * b3 = new QAction(QIcon(":/Tools Icons/Scale.svg"),QString("Scale: Shift+R"),this);
        QAction * b4 = new QAction(QIcon(":/Tools Icons/Rotate.svg"),QString("Rotate: Shift+S"),this);

        //transformActionGroup->addAction(b1);
        //transformActionGroup->addAction(b2);
        //transformActionGroup->addAction(b3);
        //transformActionGroup->addAction(b4);

        actiongroups->addAction(b1);
        actiongroups->addAction(b2);
        actiongroups->addAction(b3);
        actiongroups->addAction(b4);

        b1->setCheckable(true);b1->setShortcut(Qt::SHIFT|Qt::Key_G);
        b2->setCheckable(true);b2->setShortcut(Qt::SHIFT|Qt::Key_T);
        b3->setCheckable(true);b3->setShortcut(Qt::SHIFT|Qt::Key_R);
        b4->setCheckable(true);b4->setShortcut(Qt::SHIFT|Qt::Key_S);


        connect(b1, SIGNAL(triggered(bool)), this, SLOT(setTransformActions()));
        connect(b2, SIGNAL(triggered(bool)), this, SLOT(setTransformActions()));
        connect(b3, SIGNAL(triggered(bool)), this, SLOT(setTransformActions()));
        connect(b4, SIGNAL(triggered(bool)), this, SLOT(setTransformActions()));








        transformActions.append(b1);
        transformActions.append(b2);
        transformActions.append(b3);
        transformActions.append(b4);

        //selectionActionGroup = new QActionGroup(this);


        QAction * a1 = new QAction(QIcon(":/Tools Icons/Select Circle.svg"),QString("Circle Select: CTRL + 1"),this);
        QAction * a2 = new QAction(QIcon(":/Tools Icons/Select Curve.svg"),QString("Curve Select: CTRL + 2"),this);
        QAction * a3 = new QAction(QIcon(":/Tools Icons/Select Polygon.svg"),QString("Polygon Select: CTRL + 3"),this);
        QAction * a4 = new QAction(QIcon(":/Tools Icons/Select Rect.svg"),QString("Rect Select: CTRL + 4"),this);
        QAction * a5 = new QAction(QIcon(":/Tools Icons/Select Wand.svg"),QString("Wand Select: CTRL + 5"),this);

        //selectionActionGroup->addAction(a1);
        //selectionActionGroup->addAction(a2);
        //selectionActionGroup->addAction(a3);
        //selectionActionGroup->addAction(a4);
        //selectionActionGroup->addAction(a5);

        actiongroups->addAction(a1);
        actiongroups->addAction(a2);
        actiongroups->addAction(a3);
        actiongroups->addAction(a4);
        actiongroups->addAction(a5);


        a1->setCheckable(true);a1->setShortcut(Qt::CTRL|Qt::Key_1);
        a2->setCheckable(true);a2->setShortcut(Qt::CTRL|Qt::Key_2);
        a3->setCheckable(true);a3->setShortcut(Qt::CTRL|Qt::Key_3);
        a4->setCheckable(true);a4->setShortcut(Qt::CTRL|Qt::Key_4);
        a5->setCheckable(true);a5->setShortcut(Qt::CTRL|Qt::Key_5);

        connect(a1, SIGNAL(triggered(bool)), this, SLOT(setSelectionToolsAction()));
        connect(a2, SIGNAL(triggered(bool)), this, SLOT(setSelectionToolsAction()));
        connect(a3, SIGNAL(triggered(bool)), this, SLOT(setSelectionToolsAction()));
        connect(a4, SIGNAL(triggered(bool)), this, SLOT(setSelectionToolsAction()));
        connect(a4, SIGNAL(triggered(bool)), this, SLOT(setSelectionToolsAction()));

        selectionActions.append(a1);
        selectionActions.append(a2);
        selectionActions.append(a3);
        selectionActions.append(a4);
        selectionActions.append(a5);

        //A QActionGroup emits a triggered() signal when one
        //of its actions is chosen. Each action in an action
        //group emits its triggered() signal as usual.

        //As stated above, an action group is exclusive by default;
        //it ensures that only one checkable action is active at
        //any one time. If you want to group checkable actions
        //without making them exclusive, you can turn of exclusiveness
        //by calling setExclusive(false).

        //penActionGroup = new QActionGroup(this);//to handle toggoling

        QAction * c0 = new QAction(QIcon(":/Tools Icons/Text.svg"),QString("Text: SHIFT + 1"),this);
        QAction * c1 = new QAction(QIcon(":/Tools Icons/Brush.svg"),QString("Brush: SHIFT + 2"),this);
        QAction * c2 = new QAction(QIcon(":/Tools Icons/Pen.svg"),QString("Pen: SHIFT + 3"),this);
        QAction * c3 = new QAction(QIcon(":/Tools Icons/Line.svg"),QString("Line: SHIFT + 4"),this);
        QAction * c4 = new QAction(QIcon(":/Tools Icons/Polygon.svg"),QString("Polygon: SHIFT + 5"),this);
        QAction * c5 = new QAction(QIcon(":/Tools Icons/Spline.svg"),QString("Spline: SHIFT + 6"),this);
        QAction * c6 = new QAction(QIcon(":/Tools Icons/Curves.svg"),QString("Curves: SHIFT + 7"),this);

        c0->setCheckable(true);c0->setShortcut(Qt::SHIFT|Qt::Key_1);
        c1->setCheckable(true);c1->setShortcut(Qt::SHIFT|Qt::Key_2);
        c2->setCheckable(true);c2->setShortcut(Qt::SHIFT|Qt::Key_3);
        c3->setCheckable(true);c3->setShortcut(Qt::SHIFT|Qt::Key_4);
        c4->setCheckable(true);c4->setShortcut(Qt::SHIFT|Qt::Key_5);
        c5->setCheckable(true);c5->setShortcut(Qt::SHIFT|Qt::Key_6);
        c6->setCheckable(true);c6->setShortcut(Qt::SHIFT|Qt::Key_7);


        connect(c0, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c1, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c2, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c3, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c4, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c5, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));
        connect(c6, SIGNAL(triggered(bool)), this, SLOT(setToolsActions()));


        penActions.append(c0);
        penActions.append(c1);
        penActions.append(c2);
        penActions.append(c3);
        penActions.append(c4);
        penActions.append(c5);
        penActions.append(c6);

        //penActionGroup->addAction(c0);
        //penActionGroup->addAction(c1);
        //penActionGroup->addAction(c2);
        //penActionGroup->addAction(c3);
        //penActionGroup->addAction(c4);
        //penActionGroup->addAction(c5);
        //penActionGroup->addAction(c6);

        actiongroups->addAction(c0);
        actiongroups->addAction(c1);
        actiongroups->addAction(c2);
        actiongroups->addAction(c3);
        actiongroups->addAction(c4);
        actiongroups->addAction(c5);
        actiongroups->addAction(c6);

        controlsToolBar->addActions(actiongroups->actions());



        //controlsToolBar->addActions(transformActions);
        //controlsToolBar->addActions(selectionActions);
        //controlsToolBar->addActions(penActions);

        //controlsToolBar->addActions(transformActionGroup->actions());
        //controlsToolBar->addSeparator();

        //controlsToolBar->addActions(selectionActionGroup->actions());
        //controlsToolBar->addSeparator();

        //controlsToolBar->addActions(penActionGroup->actions());
        //controlsToolBar->addSeparator();

        bactiongroups =new QActionGroup(this);

        QAction * j = new QAction(QIcon(":/touchicons/Text.svg"),QString("Text: SHIFT + 6"),this);
        QAction * j1 = new QAction(QIcon(":/touchicons/Brush.svg"),QString("Brush: SHIFT + 1"),this);
        QAction * j2 = new QAction(QIcon(":/touchicons/multibrush.svg"),QString("multibrush: SHIFT + 4"),this);
        QAction * j3 = new QAction(QIcon(":/touchicons/masking.svg"),QString("masking: SHIFT + 2"),this);
        QAction * j4 = new QAction(QIcon(":/touchicons/Pen.svg"),QString("Pen: SHIFT + 6"),this);

        QAction * j5 = new QAction(QIcon(":/touchicons/bucket.svg"),QString("Bucket: SHIFT + 2"),this);
        QAction * j6 = new QAction(QIcon(":/touchicons/Circle.svg"),QString("Circle: SHIFT + 3"),this);
        QAction * j7 = new QAction(QIcon(":/touchicons/Curves.svg"),QString("Curve: SHIFT + 4"),this);
        QAction * j8 = new QAction(QIcon(":/touchicons/Lines.svg"),QString("Lines: SHIFT + 1"),this);
        QAction * j9 = new QAction(QIcon(":/touchicons/Line.svg"),QString("Line: SHIFT + 7"),this);

        QAction * j10 = new QAction(QIcon(":/touchicons/Spline.svg"),QString("Spline: SHIFT + 5"),this);
        QAction * j11 = new QAction(QIcon(":/touchicons/Polygon.svg"),QString("Polygon: SHIFT + 7"),this);
        QAction * j12 = new QAction(QIcon(":/touchicons/Rectangle.svg"),QString("Rectangle: SHIFT + 4"),this);

        QAction * j13 = new QAction(QIcon(":/touchicons/eyedrop.svg"),QString("Eye drop: SHIFT + 5"),this);
        QAction * j14 = new QAction(QIcon(":/touchicons/gradient.svg"),QString("Gradient: SHIFT + 6"),this);

        QAction * j15 = new QAction(QIcon(":/touchicons/measure.svg"),QString("measure: SHIFT + 3"),this);

        QAction * j16 = new QAction(QIcon(":/touchicons/Object.svg"),QString("Object: SHIFT + 5"),this);

        brushesActions.append(j);
        brushesActions.append(j1);
        brushesActions.append(j2);
        brushesActions.append(j3);
        brushesActions.append(j4);
        brushesActions.append(j5);
        brushesActions.append(j6);
        brushesActions.append(j7);
        brushesActions.append(j8);
        brushesActions.append(j9);
        brushesActions.append(j10);
        brushesActions.append(j11);
        brushesActions.append(j12);
        brushesActions.append(j13);
        brushesActions.append(j14);
        brushesActions.append(j15);
        brushesActions.append(j16);


        j->setCheckable(true);j->setShortcut(Qt::SHIFT|Qt::Key_1);
        j1->setCheckable(true);j1->setShortcut(Qt::SHIFT|Qt::Key_2);
        j2->setCheckable(true);j2->setShortcut(Qt::SHIFT|Qt::Key_3);
        j3->setCheckable(true);j3->setShortcut(Qt::SHIFT|Qt::Key_4);
        j4->setCheckable(true);j4->setShortcut(Qt::SHIFT|Qt::Key_5);
        j5->setCheckable(true);j5->setShortcut(Qt::SHIFT|Qt::Key_6);
        j6->setCheckable(true);j6->setShortcut(Qt::SHIFT|Qt::Key_7);
        j7->setCheckable(true);j7->setShortcut(Qt::SHIFT|Qt::Key_1);
        j8->setCheckable(true);j8->setShortcut(Qt::SHIFT|Qt::Key_2);
        j9->setCheckable(true);j9->setShortcut(Qt::SHIFT|Qt::Key_3);
        j10->setCheckable(true);j10->setShortcut(Qt::SHIFT|Qt::Key_4);
        j11->setCheckable(true);j11->setShortcut(Qt::SHIFT|Qt::Key_5);
        j12->setCheckable(true);j12->setShortcut(Qt::SHIFT|Qt::Key_6);
        j13->setCheckable(true);j13->setShortcut(Qt::SHIFT|Qt::Key_7);
        j14->setCheckable(true);j14->setShortcut(Qt::SHIFT|Qt::Key_1);
        j15->setCheckable(true);j15->setShortcut(Qt::SHIFT|Qt::Key_2);
        j16->setCheckable(true);j16->setShortcut(Qt::SHIFT|Qt::Key_3);




        connect(j, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j1, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j2, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j3, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j4, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j5, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j6, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j7, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j8, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j9, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j10, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j11, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j12, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j12, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j3, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j4, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j5, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));
        connect(j6, SIGNAL(triggered(bool)), this, SLOT(setBrushesToolsActions()));



        bactiongroups->addAction(j);
        bactiongroups->addAction(j1);
        bactiongroups->addAction(j2);

        bactiongroups->addAction(j3);
        bactiongroups->addAction(j4);
        bactiongroups->addAction(j5);


        bactiongroups->addAction(j6);
        bactiongroups->addAction(j7);



        bactiongroups->addAction(j8);
        bactiongroups->addAction(j9);
        bactiongroups->addAction(j10);

        bactiongroups->addAction(j11);
        bactiongroups->addAction(j12);

        bactiongroups->addAction(j13);
        bactiongroups->addAction(j14);


        bactiongroups->addAction(j15);
        bactiongroups->addAction(j16);

        brushestoolBar->addActions(bactiongroups->actions());
    }



    QSize minimumSizeHint() const
    {
        return QSize(250, 100);
    }

    QSize sizeHint() const
    {
        return QSize(width(), height());
         //return QSize(QApplication::desktop()->width(), QApplication::desktop()->height());
    }

    void initializeGL()
    {
        scenegraph->camera->setViewPort(width(),height());
    }

    void resizeGL(int width, int height)
    {
        scenegraph->camera->setViewPort(width,height);
    }

    QView3D(QWidget * parent=0) : QGLWidget(parent)
    {
        mainToolBar = new QToolBar(QString("View3D Tool bar"));

        controlsToolBar = new QToolBar(QString("Controls Tool Bar"));

         brushestoolBar =new QToolBar(QString("brushes Tool Bar"));

        createView3DToolbar();

        //setToolTip("Cube Omniverse:");
        setWindowTitle(QString("Cube Omniverse:"));

        setFormat(QGLFormat(QGL::SampleBuffers));
        //setFormat(QGLFormat(QGL::DoubleBuffer));

        scenegraph = new QSceneGraph(this,0);

        setAcceptDrops(true);
        //this->grabKeyboard();


        //QSceneTreeView *v;
        //v = new QSceneTreeView;

        //QNoisePreview *p = new QNoisePreview;
        //p->show();
        //QPropertiesWidget * properties = new QPropertiesWidget;

         //showMaximized();

        mainToolBar->addWidget(scenegraph->floorSettings->gridWidget);

    }



    void paintGL()
    {
        scenegraph->drawScene();

        update();
    }


    void wheelEvent(QWheelEvent *event)
    {
        float zoomfactor = event->delta();

        scenegraph->camera->zoom(zoomfactor);

        qDebug()<<"zoom:"<<zoomfactor;

    }

    void keyPressEvent(QKeyEvent * event)
    {
        scenegraph->keyPressEvents(event);
    }

    void mousePressEvent(QMouseEvent *event)
    {
        scenegraph->mousePressEvents(event);
    }

    void mouseMoveEvent(QMouseEvent * event)
    {
        scenegraph->mouseMoveEvents(event);
    }

    void mouseReleaseEvent(QMouseEvent * event)
    {
        scenegraph->mouseReleaseEvents(event);

        setCursor(Qt::ArrowCursor);
    }

    void dragEnterEvent(QDragEnterEvent * event)
    {
        event->acceptProposedAction();

        QGLWidget::dragEnterEvent(event);
    }

    void dragMoveEvent(QDragMoveEvent *event)
    {
        event->accept(); //very important

        QGLWidget::dragMoveEvent(event);
    }

    void dropEvent(QDropEvent *event)
    {
        event->acceptProposedAction();

        if(event->mimeData()->hasText())
        {
            //addNode(event->mimeData()->text(),QCursor::pos());

            //scene()->update();

            qDebug()<<"Objects"<<event->mimeData()->text();
        }

        QGLWidget::dropEvent(event);
    }

    void contextMenuEvent(QContextMenuEvent *event)
    {
        qDebug()<<"Main menu";

        QPoint p = QCursor::pos();

        scenegraph->mainContextmenu.move(p);

        scenegraph->mainContextmenu.show();



        //QAction *selectedAction = mainContextmenu.exec();

        //if (selectedAction)
        {
           //if(_debug)
           //printf("Clicked Action:\n");
           //qDebug()<<"Clicked Action:\n"<<selectedAction->text();

          // addModel(selectedAction->text());
           //printf(qPrintable(selectedAction->text()));
       }

    }


signals:


public slots:


    void setTransformActions()
    {
        if(transformActions[0]->isChecked())
        {
            qDebug()<<"Selection Action active";

            this->setCursor(QCursor(QPixmap(":/Tools Icons/select.svg")));

        }
        else
        {
            qDebug()<<"Selection Action inactive";
            //this->setCursor(QCursor(Qt::ArrowCursor));

        }

        if(transformActions[1]->isChecked())
        {
            this->setCursor(QCursor(QPixmap(":/Tools Icons/Translate.svg")));

           qDebug()<<"Selection Translation Action active";
        }
        else
        {
            qDebug()<<"Selection Translation Action inactive";
        }

        if(transformActions[2]->isChecked())
        {
            this->setCursor(QCursor(QPixmap(":/Tools Icons/Scale.svg")));

           qDebug()<<"Selection Scale Action active";
        }
        else
        {
            qDebug()<<"Selection Scale Action inactive";
        }

        if(transformActions[3]->isChecked())
        {
            this->setCursor(QCursor(QPixmap(":/Tools Icons/Rotate.svg")));

           qDebug()<<"Selection Rotation Action active";
        }
        else
        {
            qDebug()<<"Selection Rotation Action inactive";
        }

        qDebug()<<"/n";
    }

    void setSelectionToolsAction()
    {
        if(selectionActions[0]->isChecked())
        {
            qDebug()<<"Select Circle Action active";

            this->setCursor(QCursor(QPixmap(":/Tools Icons/Select Circle.svg")));


        }
        else
        {
            qDebug()<<"Select Circle Action inactive";
        }

        if(selectionActions[1]->isChecked())
        {
           qDebug()<<"Select Curve Action active";
           this->setCursor(QCursor(QPixmap(":/Tools Icons/Select Curve.svg")));

        }
        else
        {
            qDebug()<<"Select Curve Action inactive";
        }

        if(selectionActions[2]->isChecked())
        {
           qDebug()<<"Select Polygon Action active";
           this->setCursor(QCursor(QPixmap(":/Tools Icons/Select Polygon.svg")));

        }
        else
        {
            qDebug()<<"Select Polygon Action inactive";
        }

        if(selectionActions[3]->isChecked())
        {
           qDebug()<<"Select Rect Action active";
           this->setCursor(QCursor(QPixmap(":/Tools Icons/Select Rect.svg")));

        }
        else
        {
            qDebug()<<"Select Rect Action inactive";
        }

        if(selectionActions[4]->isChecked())
        {
           qDebug()<<"Select Wand Action active";
           this->setCursor(QCursor(QPixmap(":/Tools Icons/Select Wand.svg")));

        }
        else
        {
            qDebug()<<"Select Wand Action inactive";
        }


        qDebug()<<"/n";


    }

    void setToolsActions()
    {
        if(penActions[0]->isChecked())
        {
            qDebug()<<"Text Action active";
            this->setCursor(QCursor(QPixmap(":/Tools Icons/Text.svg")));


        }
        else
        {
            qDebug()<<"Text Action inactive";
        }

        if(penActions[1]->isChecked())
        {
           qDebug()<<"Brush Action active";
           this->setCursor(QCursor(QPixmap(":/Tools Icons/Brush.svg")));

        }
        else
        {
            qDebug()<<"Brush Action inactive";
        }

        if(penActions[2]->isChecked())
        {
           qDebug()<<"Pen Action active";
           this->setCursor(QCursor(QPixmap(":/Tools Icons/Pen.svg")));

        }
        else
        {
            qDebug()<<"Pen Action inactive";
        }

        if(penActions[3]->isChecked())
        {
           qDebug()<<"Line Action active";
           this->setCursor(QCursor(QPixmap(":/Tools Icons/Line.svg")));

        }
        else
        {
            qDebug()<<"Line Action inactive";
        }

        if(penActions[4]->isChecked())
        {
           qDebug()<<"Polygon Action active";
           this->setCursor(QCursor(QPixmap(":/Tools Icons/Polygon.svg")));

        }
        else
        {
            qDebug()<<"Polygon Action inactive";
        }

        if(penActions[5]->isChecked())
        {
           qDebug()<<"Spline Action active";
           this->setCursor(QCursor(QPixmap(":/Tools Icons/Spline.svg")));

        }
        else
        {
            qDebug()<<"Spline Action inactive";
        }

        if(penActions[6]->isChecked())
        {
           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/Tools Icons/Curves.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }


        qDebug()<<"/n";

    }


    void setBrushesToolsActions()
    {

        if(brushesActions[0]->isChecked())
        {
            qDebug()<<"Text Action active";
            this->setCursor(QCursor(QPixmap(":/touchicons/Text.svg")));


        }
        else
        {
            qDebug()<<"Text Action inactive";
        }

        if(brushesActions[1]->isChecked())
        {
           qDebug()<<"Brush Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/Brush.svg")));

        }
        else
        {
            qDebug()<<"Brush Action inactive";
        }

        if(brushesActions[2]->isChecked())
        {
           qDebug()<<"Pen Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/multibrush.svg")));

        }
        else
        {
            qDebug()<<"Pen Action inactive";
        }

        if(brushesActions[3]->isChecked())
        {
           qDebug()<<"Line Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/masking.svg")));

        }
        else
        {
            qDebug()<<"Line Action inactive";
        }

        if(brushesActions[4]->isChecked())
        {
           qDebug()<<"Polygon Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/Pen.svg")));

        }
        else
        {
            qDebug()<<"Polygon Action inactive";
        }

        if(brushesActions[5]->isChecked())
        {
           qDebug()<<"Spline Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/bucket.svg")));

        }
        else
        {
            qDebug()<<"Spline Action inactive";
        }

        if(brushesActions[6]->isChecked())
        {
           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/Circle.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }

        if(brushesActions[7]->isChecked())
        {
           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/Curves.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }


        if(brushesActions[8]->isChecked())
        {
           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/Lines.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }


        if(brushesActions[9]->isChecked())
        {
           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/Line.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }

        if(brushesActions[10]->isChecked())
        {
           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/Spline.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }

        if(brushesActions[11]->isChecked())
        {
           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/Polygon.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }

        if(brushesActions[12]->isChecked())
        {
           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/Rectangle.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }

        if(brushesActions[13]->isChecked())
        {

           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/eyedrop.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }

        if(brushesActions[14]->isChecked())
        {

           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/gradient.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }

        if(brushesActions[15]->isChecked())
        {

           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/measure.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }

        if(brushesActions[16]->isChecked())
        {

           qDebug()<<"Curves Action active";
           this->setCursor(QCursor(QPixmap(":/touchicons/Object.svg")));

        }
        else
        {
            qDebug()<<"Curves Action inactive";
        }







        qDebug()<<"/n";



    }



};


class QMainView : public QWidget
{
    Q_OBJECT

public:

    QStringList modelsList;

    QSearchEx1 * search;

    QView3D * view;

    QMainView(QWidget *parent =0):QWidget(parent)
    {
        modelsList.append(QString("Copper"));
        modelsList.append(QString("Gold"));
        modelsList.append(QString("Silver"));
        modelsList.append(QString("Bronze"));
        modelsList.append(QString("Rust"));
        modelsList.append(QString("Brushed Metal"));
        modelsList.append(QString("Glass"));
        modelsList.append(QString("ALminuium"));
        modelsList.append(QString("Chrome"));
        modelsList.append(QString("Skin"));
        modelsList.append(QString("Wood"));
        modelsList.append(QString("sand"));
        modelsList.append(QString("snow"));
        modelsList.append(QString("Volume"));
        modelsList.append(QString("rubber"));
        modelsList.append(QString("velvet"));
        modelsList.append(QString("cook torrance"));
        modelsList.append(QString("Plastic"));
        modelsList.append(QString("cotton"));
        modelsList.append(QString("standard"));
        modelsList.append(QString("Marbel"));
        modelsList.append(QString("Rocks"));
        modelsList.append(QString("concrete"));
        modelsList.append(QString("gravel"));
        modelsList.append(QString("pebbles"));
        modelsList.append(QString("Noise"));
        modelsList.append(QString("ANistropy"));
        modelsList.append(QString("Metal"));



        modelsList.sort();
        //modelsList.removeDuplicates();

        search = new QSearchEx1(modelsList,this);

        view   = new QView3D(this);

        if (!view->format().sampleBuffers())
        {
             QMessageBox::information(0, "OpenGL samplebuffers",
                     "This system does not have sample buffer support.");

        }

        QVBoxLayout * vlayout = new QVBoxLayout;


        QSplitter * splitter = new QSplitter(Qt::Vertical);

        splitter->addWidget(view);
        splitter->addWidget(search);

        vlayout->addWidget(splitter);

        setLayout(vlayout);

        setTheme();
        setTitleDetails();
    }

    void setTheme()
    {
        //QFile file(":/metro.stylesheet");
        //QFile file(":/test.stylesheet");
        //QFile file(":/darkorange.stylesheet");
        //QFile file(":/levefour.stylesheet");

        QFile file(":/icons/glowBlue.stylesheet");

        if(file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
           setStyleSheet(file.readAll());
           file.close();
        }

        setWindowIcon(QIcon(":icons/cubeomniverse.svg"));
    }

    void setTitleDetails()
    {
       setWindowTitle(QString("Touch Paint: View 3D"));
    }
};




#endif // VIEW3D_H

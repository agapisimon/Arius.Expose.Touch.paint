#ifndef SETTINGS_HPP
#define SETTINGS_HPP

#include<widgets.hpp>


class FloorGridSetting : public QObject
{
    Q_OBJECT

public:

    float divisions;
    float step;
    bool hideGrid;

    QWidget * gridWidget;

    QFloatWidget * divisionValue;
    QFloatWidget * stepValue;
    //QBoolWidget * hideGridValue;
    QRadioButton * hideGridValue;

    FloorGridSetting(QObject * parent =0)
    {
        gridWidget = new QWidget;

        QVBoxLayout * layout = new QVBoxLayout();

        divisionValue = new QFloatWidget;
        divisionValue->setText(QString("Grid width:"));
        divisionValue->setMinMaxValue(0,50,4,1);


        stepValue     = new QFloatWidget;
        stepValue->setText(QString("Step Value:"));
        stepValue->setMinMaxValue(0,100,1,1);




        hideGridValue = new QRadioButton;
        hideGridValue->setCheckable(true);
        hideGridValue->setChecked(true);
        hideGridValue->setText("Hide Floor");


        divisions = divisionValue->getValue();
        step      = stepValue->getValue();

        QButtonGroup * gr = new QButtonGroup;
        gr->addButton(hideGridValue);
        gr->setExclusive(false);

        layout->addWidget(divisionValue);
        layout->addWidget(stepValue);
        layout->addWidget(hideGridValue);

        gridWidget->setLayout(layout);

        connect( divisionValue,SIGNAL(valueChanged(double)),SLOT(setWidthValue()) );
        connect( stepValue,    SIGNAL(valueChanged(double)),SLOT(setStepValue())  );
        connect( hideGridValue,SIGNAL(toggled(bool)),SLOT(setHideFloorValue())  );
    }

signals:

public slots:

    void setWidthValue()
    {
        divisions = divisionValue->getValue();
    }

    void setStepValue()
    {
        step  = stepValue->getValue();
    }

    void setHideFloorValue()
    {
        hideGrid  = hideGridValue->isChecked();
    }
};





#endif // SETTINGS_HPP
